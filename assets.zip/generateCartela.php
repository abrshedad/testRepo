<?php
// Assuming you have a connection to the database
include_once('connection.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fifty Tables</title>

    <meta name="description" content="" />

    
<style>
	body{
		width: 100%;
        height: 100%;

		padding-left: 3px;
	}
/* General layout for the table container */
.table-container {
    display: flex;              /* Use Flexbox for layout */
    flex-wrap: wrap;            /* Allow tables to wrap into new rows */
    justify-content: flex-start; /* Align tables to the left */
    gap: 10px;                  /* Space between tables */
    width: 100%;   
    height: 100%             /* Ensure the container takes up full width */
    padding: 0px;               /* Optional padding for spacing */
}

/* Styling for each table */
/* Styling for each table */
table {
    width: calc(100% - 30px);     /* Set each table to 50% width of the container */
    height: 100%;                /* Table height to fill 100% of the container */
    border-collapse: collapse;  /* Collapse table borders */
    margin-bottom: 20px;        /* Space between tables vertically */
    margin-top: 10px;
    page-break-after: always;
    font-size: calc(10px + 2vw); /* Dynamically adjust font size based on viewport */
}

/* Styling for table cells */
td {
    font-weight: bold;          /* Make text bold */
    font-size: calc(30px + 2vw);            /* Increase the font size */
    padding: 30px;               /* Padding for better spacing */
    text-align: center;         /* Center align the content */
}

/* Table headers and cells */
th, td {
    border: 1px solid #333;
    padding: 16px;
    text-align: center;
    font-size: calc(40px + 2vw);
    width: 20%;
    box-shadow: inset 2px 2px 4px rgba(0, 0, 0, 0.2), inset -2px -2px 4px rgba(255, 255, 255, 0.5);
    border: 1px solid #bbb;
}
td{
    font-size: calc(50px + 2vw);
}
/* Table headers */
th {
    background: #333;
    color: blue;
    font-family: Cambria;
}




</style></head>
<?php
mysqli_query($conn, "DELETE FROM bingo"); // Clearing the bingo table for fresh insertion
$bingos = array();
$noOfBingos = 50;

// Function to generate unique random numbers for a column
function generate_unique_column_numbers($min, $max, $count) {
    $unique_numbers = [];
    while(count($unique_numbers) < $count) {
        $random_number = rand($min, $max);
        // Ensure the number isn't already used in the column
        if (!in_array($random_number, $unique_numbers)) {
            $unique_numbers[] = $random_number;
        }
    }
    return $unique_numbers;
}

// Generate Bingo cards and store them in the database
for ($nos = 0; $nos < $noOfBingos; $nos++) {
    // Generate unique random numbers for each column (B, I, N, G, O)
    $columnB = generate_unique_column_numbers(1, 15, 5);   // B: 1-15
    $columnI = generate_unique_column_numbers(16, 30, 5);  // I: 16-30
    $columnN = generate_unique_column_numbers(31, 45, 5);  // N: 31-45
    $columnG = generate_unique_column_numbers(46, 60, 5);  // G: 46-60
    $columnO = generate_unique_column_numbers(61, 75, 5);  // O: 61-75

    // Insert 'Free' in the middle of the 'N' column (index 2)
    $columnN[2] = 'Free';

    // Create strings for each column to store the Bingo data
    $B = '';
    $I = '';
    $N = '';
    $G = '';
    $O = '';

    // Assign values to each column and prepare strings
    for ($i = 0; $i < 5; $i++) {
        // Concatenate values for each column (B, I, N, G, O)
        $B .= str_pad($columnB[$i], 2, '0', STR_PAD_LEFT); // Format to two digits for 'B'
        $I .= str_pad($columnI[$i], 2, '0', STR_PAD_LEFT); // Format to two digits for 'I'
        
        // Handle 'Free' in the N column explicitly (don't pad 'Free')
        $N .= $columnN[$i] === 'Free' ? 'Free' : str_pad($columnN[$i], 2, '0', STR_PAD_LEFT); // Format to two digits for 'N' (except 'Free')
        
        $G .= str_pad($columnG[$i], 2, '0', STR_PAD_LEFT); // Format to two digits for 'G'
        $O .= str_pad($columnO[$i], 2, '0', STR_PAD_LEFT); // Format to two digits for 'O'
    }

    // Now insert the data into the 'bingo' table
    $table_code = $nos + 1; // Assuming the table code is just the index + 1
    $query = "INSERT INTO bingo (No, B, I, N, G, O) 
              VALUES ('$table_code', '$B', '$I', '$N', '$G', '$O')";

    if (!mysqli_query($conn, $query)) {
        echo "Error: " . mysqli_error($conn);
    }
}

// Fetch Bingo cards from the database to display them
$query = "SELECT * FROM bingo";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo "Error fetching Bingo data: " . mysqli_error($conn);
} else {
    $i = 0;?>
    <div class="table-container row" id="tables"><?php
    while ($row = mysqli_fetch_assoc($result)) {
        $table_code = $row['No'];
        if($table_code <= 9) $table_code = "00".$table_code;
        else if($table_code < 100) $table_code = "0".$table_code;
        $B = $row['B'];
        $I = $row['I'];
        $N = $row['N'];
        $G = $row['G'];
        $O = $row['O'];

        // Process the string values and split them into individual numbers (ignoring 'Free' for 'N' column)
        $bcol = preg_replace("/\s*/m", '', $row['B']);
        $icol = preg_replace("/\s*/m", '', $row['I']);
        $ncol = preg_replace("/\s*/m", '', $row['N']);
        $gcol = preg_replace("/\s*/m", '', $row['G']);
        $ocol = preg_replace("/\s*/m", '', $row['O']);
        
        // Display the Bingo card
        ?>
            <table class="table table-striped table-bordered bingoTables" style="border: 1px solid black;">
            	<thead style="background: #ed3939;">
                    <th colspan="3" style="color: gold;">AB-STAR BINGO <img src="bingo.png" style="transform: rotate(-45deg); margin-left: 20px;"  height="110%" width="100px"> </th>
                    <th colspan="2" style="color: greenyellow;"><?php echo $table_code; ?></th>
                </thead>
                <thead style="background: red; color: blue;">
                    <th>B</th>
                    <th>I</th>
                    <th>N</th>
                    <th>G</th>
                    <th>O</th>
                </thead>
                <tbody style="border: 1px solid gray;">
                <?php
                    for ($m = 0; $m < 10; $m += 2) {
                        $ncoldisp = substr($ncol, $m, 2);
                        if ($m > 3) {
                            if ($m == 4) {
                                $ncoldisp = substr($ncol, $m, 4); 
                            } else {
                                $ncoldisp = substr($ncol, $m + 2, 2); 
                            }
                        } else {
                            $ncoldisp = substr($ncol, $m, 2); 
                        }
                        ?>
                        <tr>
                        <?php
                            // Render the values and handle 'Free' for the N column
                            echo "<td contenteditable=true>" . intval(substr($bcol, $m, 2)) . "</td>"
                                . "<td contenteditable=true>" . substr($icol, $m, 2) . "</td>"
                                . "<td contenteditable=" . ($ncoldisp == 'Free' ? 'false' : 'true') . ">" . ($ncoldisp == 'Free' ? $ncoldisp : substr($ncoldisp, 0, 2)) . "</td>"
                                . "<td contenteditable=true>" . substr($gcol, $m, 2) . "</td>"
                                . "<td contenteditable=true>" . substr($ocol, $m, 2) . "</td>";
                        ?>
                        </tr>
                        <?php
                    }
                ?>
                </tbody>
            </table>
        
        <?php
        $i++;
    } ?> </div> <?php
}

// Close the database connection
mysqli_close($conn);
?>
</html>
<!-- Add CSS for print layout -->

