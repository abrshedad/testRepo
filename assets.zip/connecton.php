
<?php

$servername = "localhost";
$database = "test";
include_once("encryption.php");
$encrypt = new encryption();
$username = "root";
$password = "";
// Create connection using musqli_connect function
$conn = mysqli_connect($servername, $username, $password, $database);
// Connection Check
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}
else{
  // echo "Connected Successfully!";
}
?>
