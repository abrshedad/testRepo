<!DOCTYPE html>
<?php
    session_start();
    if(isset($_SESSION['UserName']) && $_SESSION['UserName'] != ""){
?>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Main Page</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
    <script src="../assets/sweet.js"></script>
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <style>
        .printDiv{
            display: inline-block;
        }
    </style>
    <script>
        $(document).ready(function(){
            loadData();
        });
        function au(i,diff){
            swal({
              title: "Accept "+diff+"Birr From Cashier ?",
              text: "Be sure before click procced.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((betCartela) => {
              if (betCartela) {
                 var success = document.getElementById("success_td");
                $.ajax({
                    url: "activities.php",
                    type:"post",
                    data:({Purpose:"Au",I:i,Am:diff}),
                    success: function(result){
                        var r = $.trim(result);
                         success.innerHTML = r;
                        if(r === "not admin"){
                            window.open("../","_self");
                        }
                        else if(r === "success"){
                            success.innerHTML = "Cashier Audited Successfully.";
                            //window.open("MainPage/","_self");
                            loadData();
                        }
                        else{
                            success.innerHTML="Error to Audit Cashier. "+result;
                        }
                    }
                });
              }
            });
            
        }
        function loadData(){
            $.ajax({
                url: "activities.php",
                type:"post",
                data:({Purpose:"Load"}),
                success: function(result){
                   document.getElementById("cashierData_div").innerHTML = result;
                }
            });
        }
        
    </script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
                
                
                <div class="row mb-4" id="cashierData_div">
                    
                </div>
                <center><div id="success_td"></div>
                <div class="" >
                    <a
                      href="../"
                      data-bs-toggle="modal"
                      class="btn btn-warning btn-buy-now"
                      >Logout</a>
                  </div>
                </center>
               
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  , made with ❤️ by
                  <a href="https://abstargames.com" target="_blank" class="footer-link fw-bolder">A+ Computers</a>
                </div>
                
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->

        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

<div class="modal fade" id="showReedemModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Redeem Win Amount</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body" id="advertsModal_div">
            <div class="row">
                <div class="nav-align-top mb-4">
                  <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <button
                        type="button"
                        class="nav-link active"
                        role="tab"
                        data-bs-toggle="tab"
                        data-bs-target="#dogRedeem_div"
                        aria-controls="dogRedeem_div"
                        aria-selected="true"
                      >
                        Dog Redeem
                      </button>
                    </li>
                    <li class="nav-item">
                      <button
                        type="button"
                        class="nav-link"
                        role="tab"
                        data-bs-toggle="tab"
                        data-bs-target="#horseRedeem_div"
                        aria-controls="horseRedeem_div"
                        aria-selected="false"
                      >
                        Horse Redeem
                      </button>
                    </li>
                  </ul>
                  <div class="tab-content" style="margin-left: -2%; width: 103%; ">
                      <div class="tab-pane fade show active" id="dogRedeem_div" role="tabpanel" >
                        <div style="display: flex;">
                            <input type="number" class="form-control" id="dogCardCodeToRedeem_txt" placeholder="Your Dog Card Code Here ...." min="0">
                            <button class="btn btn-outline-danger w-100" onclick="loadDogData()">Load Dog Data</button>
                        </div><hr>
                        <div id="dogDetail_div">
                            
                        </div>
                    </div>
                    <div class="tab-pane fade" id="horseRedeem_div" role="tabpanel" >
                        <div style="display: flex;">
                            <input type="number" class="form-control" id="horseCardCodeToRedeem_txt" placeholder="Your Horse Card Code Here ...." min="0">
                            <button class="btn btn-outline-danger w-100" onclick="loadHorseData()">Load Horse Data</button>
                        </div>
                        <hr>
                        <div id="horseDetail_div">
                            
                        </div>
                    </div>
                  </div>
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<script>
    function loadCashierDetail(){
        $.ajax({
            url: "activities.php",
            type:"post",
            data:({Purpose:"Cashier-Detail"}),
            success: function(result){
                document.getElementById("cashierDetailModalBody_div").innerHTML = result;
            }
        });
    }
</script>
<div class="modal fade" id="cashierOptionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Your Cashier Status</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body" id="cashierDetailModalBody_div">
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<?php
    }
    else{
        ?>
        <script>
        window.open("../","_self");</script>
        <?php
    }
    ?>
