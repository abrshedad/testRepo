<?php
    include_once("../connection.php");
    include_once("../encryption.php");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    date_default_timezone_set('Africa/Nairobi');

    $purpose = $_POST['Purpose'];
    session_start();
    $username = $_SESSION['UserName'];
    $encrypt = new encryption();
    if($purpose == "Au"){
       $i = $_POST['I'];
       $am = $_POST['Am'];
       $c = $_POST['C'];
       $p = $_POST['P'];
       $name = $encrypt->encrypt($_POST['N']);

       $check = mysqli_num_rows(mysqli_query($conn, "select *from admin where SuperCode='$username'"));
       if($check > 0){
          if(mysqli_query($conn, "update cashier set Collected=0,Paid=0 where Id='$i'")){
              mysqli_query($conn, "update admin set AmountTotal=AmountTotal+'$am' where SuperCode='$username'")or die(mysqli_error($conn));
              $d = date('Y-m-d H:i:s');
              mysqli_query($conn,"insert into repo(CashierName,Date,C,P,D) values('$name','$d','$c','$p','$am')") or die(mysqli_error($conn));
              mysqli_query($conn, "delete from horse") or die(mysqli_error($conn));
              mysqli_query($conn, "delete from dog") or die(mysqli_error($conn));
              mysqli_query($conn, "delete from winners") or die(mysqli_error($conn));
              mysqli_query($conn,"alter table winners AUTO_INCREMENT = 1") or die(mysqli_error($conn));
              echo "success";
          }
          else{
              echo "failed";
          }
       }
       else{
          // session_destroy();
           echo "not admin";
       }
    }
    else if($purpose == "Au-All"){
        $q = mysqli_query($conn,"select *from cashier");
        $check = mysqli_num_rows(mysqli_query($conn, "select *from admin where SuperCode='$username'"));
           if($check > 0){
            while ($row = mysqli_fetch_array($q)) {
                $i = $row['Id'];
                
                $c = $row['Collected'];
                $p = $row['Paid'];
                $name = $row['Name'];
                $am = $c-$p;
                if(mysqli_query($conn, "update cashier set Collected=0,Paid=0 where Id='$i'")){
                    mysqli_query($conn, "update admin set AmountTotal=AmountTotal+'$am' where SuperCode='$username'")or die(mysqli_error($conn));
                    $d = date('Y-m-d H:i:s');
                    mysqli_query($conn,"insert into repo(CashierName,Date,C,P,D) values('$name','$d','$c','$p','$am')") or die(mysqli_error($conn));
                    mysqli_query($conn, "delete from horse") or die(mysqli_error($conn));
                    mysqli_query($conn, "delete from dog") or die(mysqli_error($conn));
                    mysqli_query($conn, "delete from winners") or die(mysqli_error($conn));
                    mysqli_query($conn,"alter table winners AUTO_INCREMENT = 1") or die(mysqli_error($conn));
                    echo "success";
                }
                else{
                    echo "failed".mysqli_error($conn);
                }
            }
              
           }
           else{
              // session_destroy();
               echo "not admin";
           }
    }
    else if($purpose == "Delete-Cashier"){
       $i = $_POST['I'];
       $am = $_POST['Diff'];
       $check = mysqli_num_rows(mysqli_query($conn, "select *from admin where SuperCode='$username'"));

       if($check > 0){
          if(mysqli_query($conn, "update cashier set Collected=0,Paid=0 where Id='$i'")){
              mysqli_query($conn, "update admin set AmountTotal=AmountTotal+'$am' where SuperCode='$username'")or die(mysqli_error($conn));
              mysqli_query($conn,"delete from cashier where Id='$i'") or die(mysqli_error($conn));
              mysqli_query($conn,"delete from login where UserName='$i'") or die(mysqli_error($conn));
              mysqli_query($conn, "delete from plays") or die(mysqli_error($conn));
              mysqli_query($conn, "delete from winners") or die(mysqli_error($conn));
              echo "success";
          }
          else{
              echo "failed";
          }
       }
       else{
          // session_destroy();
           echo "not admin";
       }
    }
    else if($purpose == "Load"){
        ?>
        <table class="table table-striped table-bordered" style="text-align:center;">
            <thead><th>Cashier Name</th><th>Colle cted</th><th>Paid</th><th>In Hand</th></thead>
            <tbody>
                <?php
                include_once '../connection.php';
                include_once '../encryption.php';
                $encrypt = new encryption();
                $query = mysqli_query($conn, "select *from cashier") or die(mysqli_error($conn));
                while($row = mysqli_fetch_array($query)){
                    $id = $row['Id'];
                    $collected = $row['Collected'];
                    $paid = $row['Paid'];
                    $diff = $collected-$paid;
                    $name = $encrypt->decrypt($row['Name']);
                    ?>
                <tr>
                    <td style="text-transform: capitalize;"><?php echo $name;?></td>
                    <td><?php echo $collected;?></td>
                    <td><?php echo $paid;?></td>
                    <td><?php echo $diff;?></td>
                    <?php if($diff > 0){ 
                        ?><td><button class="btn btn-outline-success"
                         onclick="au('<?php echo $id ?>','<?php echo $collected; ?>','<?php echo $paid; ?>','<?php echo $diff; ?>','<?php echo $name; ?>')" type="button">Audit</button></td><?php } ?>
                    <?php if($id != $username ){ ?> <td><button class="btn btn-outline-danger" onclick="deleteCashier('<?php echo $id ?>','<?php echo $name; ?>','<?php echo $diff; ?>')" type="button">Delete</button></td><?php } ?>
                </tr>
                    <?php
                }
                ?>
                
            </tbody>
        </table>
        <?php
        $x = mysqli_query($conn, "select *from admin where SuperCode='$username'") or die(mysqli_error($conn));
        $rr = mysqli_fetch_array($x);
        ?>
            <center>Total Money Worked : <?php echo $rr['AmountTotal']; ?></center>
            <br>
            <center> 
                <a href="../MainPage/report.php" target="_blank" class="report_link footer-link fw-bolder">Check Winners Report</a>
                <style type="text/css">
                    .report_link{
                        text-decoration: underline;
                        text-transform: capitalize;
                    }
                    .report_link:hover{
                        font-size: 25px;
                        color: red;
                        text-transform: uppercase;
                    }
                </style>
                <hr>
                <button class="btn btn-outline-info rounded-pill" type="button" value="<?php echo $code; ?>" onclick="generateReport()">
                    Get Report
                </button>
            </center>
        <?php
    }
// === Generate-Report ===
else if ($purpose == "Generate-Report") {

    require '../assets/PHPMailer/src/PHPMailer.php';
    require '../assets/PHPMailer/src/SMTP.php';
    require '../assets/PHPMailer/src/Exception.php';

    $tableName = "report";
    $currentDateTime = date('F j, Y g:i A');

    // Desktop path (override optional)
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $desktopPath = getenv('HOMEDRIVE') . getenv('HOMEPATH') . "\\Desktop\\";
    } else {
        $desktopPath = getenv('HOME') . "/Desktop/";
    }
    $desktopPath = "F:\\";
    echo "Path : ".$desktopPath;
    // Fetch company password
    $q = mysqli_query($conn, "SELECT * FROM super") or die(mysqli_error($conn));
    $r = mysqli_fetch_array($q);
    $companySecret = $r['Cp'];

    $fileName = 'monthly_report.sql';
    $filePath = $desktopPath . $fileName;

    $handle = fopen($filePath, 'w') or die("Unable to open file for writing.");

    // Write companySecret encrypted once
    fwrite($handle, $encrypt->encrypt($companySecret) . "\n");

    // Write DROP TABLE encrypted twice
    $dropSQL = "DROP TABLE IF EXISTS `$tableName`;\n";
    fwrite($handle, $encrypt->encrypt($encrypt->encrypt($dropSQL)) . "\n");

    // Write CREATE TABLE encrypted twice
    $result = $conn->query("SHOW CREATE TABLE `$tableName`");
    if ($result) {
        $createRow = $result->fetch_array();
        $createSQL = $createRow[1] . ";\n";
        fwrite($handle, $encrypt->encrypt($encrypt->encrypt($createSQL)) . "\n");
    } else {
        die("❌ Failed to get CREATE TABLE: " . $conn->error);
    }

    // Write INSERT queries encrypted twice
    $rows = $conn->query("SELECT * FROM `$tableName`");
    if ($rows) {
        while ($data = $rows->fetch_assoc()) {
            $escapedValues = array_map([$conn, 'real_escape_string'], array_values($data));
            $quotedValues = "'" . implode("','", $escapedValues) . "'";
            $insertSQL = "INSERT INTO `$tableName` VALUES ($quotedValues);\n";
            fwrite($handle, $encrypt->encrypt($encrypt->encrypt($insertSQL)) . "\n");
        }
    } else {
        die("❌ Failed to get table rows: " . $conn->error);
    }

    fclose($handle);
    $conn->close();

    // PHPMailer code (unchanged)
    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 2;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'abrsheGodolyas999@gmail.com';
        $mail->Password   = 'ebbq zlzm rlsa jtpa';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom('abrsheGodolyas999@gmail.com', 'Bingo Reporter');
        $mail->addAddress('abrshedad@gmail.com', 'Admin');
        $mail->addAttachment($filePath);

        $mail->isHTML(true);
        $mail->Subject = 'Bingo Report Exported - '.$currentDateTime;
        $mail->Body    = 'Hi Boss,todays Bingo report has been generated and attached.';

        $mail->send();
        echo '✔ Report generated and emailed successfully.  - '.$currentDateTime.'<br>';
    } catch (Exception $e) {
        echo "❌ Email could not be sent. Mailer Error: {$mail->ErrorInfo}<br>";
    }

    echo "📁 File saved at: " . htmlspecialchars($filePath);
}
else if($purpose == "Submit-Report"){
    require '../assets/PHPMailer/src/PHPMailer.php';
    require '../assets/PHPMailer/src/SMTP.php';
    require '../assets/PHPMailer/src/Exception.php';

    $tableName = "report";
    $computerName = gethostbyaddr($_SERVER['REMOTE_ADDR']);
    $currentDateTime = date('F j, Y g:i A');

    // Desktop path (override optional)
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $desktopPath = getenv('HOMEDRIVE') . getenv('HOMEPATH') . "\\Desktop\\";
    } else {
        $desktopPath = getenv('HOME') . "/Desktop/";
    }
    $desktopPath = "F:\\";
    // Fetch company password
    $q = mysqli_query($conn, "SELECT * FROM super") or die(mysqli_error($conn));
    $r = mysqli_fetch_array($q);
    $companySecret = $r['Cp'];

    $fileName = 'monthly_report.sql';
    $filePath = $desktopPath . $fileName;

    $handle = fopen($filePath, 'w') or die("Unable to open file for writing.");

    // Write companySecret encrypted once
    fwrite($handle, $encrypt->encrypt($companySecret) . "\n");

    // Write DROP TABLE encrypted twice
    $dropSQL = "DROP TABLE IF EXISTS `$tableName`;\n";
    fwrite($handle, $encrypt->encrypt($encrypt->encrypt($dropSQL)) . "\n");

    // Write CREATE TABLE encrypted twice
    $result = $conn->query("SHOW CREATE TABLE `$tableName`");
    if ($result) {
        $createRow = $result->fetch_array();
        $createSQL = $createRow[1] . ";\n";
        fwrite($handle, $encrypt->encrypt($encrypt->encrypt($createSQL)) . "\n");
    } else {
        die("❌ Failed to get CREATE TABLE: " . $conn->error);
    }

    // Write INSERT queries encrypted twice
    $rows = $conn->query("SELECT * FROM `$tableName`");
    if ($rows) {
        while ($data = $rows->fetch_assoc()) {
            $escapedValues = array_map([$conn, 'real_escape_string'], array_values($data));
            $quotedValues = "'" . implode("','", $escapedValues) . "'";
            $insertSQL = "INSERT INTO `$tableName` VALUES ($quotedValues);\n";
            fwrite($handle, $encrypt->encrypt($encrypt->encrypt($insertSQL)) . "\n");
        }
    } else {
        die("❌ Failed to get table rows: " . $conn->error);
    }

    fclose($handle);
    $conn->close();

    // PHPMailer code (unchanged)
    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'abrsheGodolyas999@gmail.com';
        $mail->Password   = 'ebbq zlzm rlsa jtpa';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom('abrsheGodolyas999@gmail.com', 'Bingo Reporter');
        $mail->addAddress('wawbym@gmail.com', 'Admin');
        $mail->addAddress('abrshedad@gmail.com', 'Super Admin');
        $mail->addAttachment($filePath);

        $mail->isHTML(true);
        $mail->Subject = $computerName.' => Bingo Report Exported - '.$currentDateTime;
        $mail->Body    = 'Hi Boss,todays Bingo report has been generated and attached.';

        $mail->send();
        echo '✔ Report generated and emailed successfully.  - '.$currentDateTime.'<br>';
    } catch (Exception $e) {
        echo "❌ Email could not be sent. Mailer Error: {$mail->ErrorInfo}<br>";
    }

    echo "📁 File saved at: " . htmlspecialchars($filePath);
}


?>

