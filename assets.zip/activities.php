<?php
    
    include_once("encryption.php");
    $purpose = $_POST['Purpose'];
    $encrypt = new encryption();
    session_start();
    if($purpose == "Login"){
        include("connection.php");
        $username = $encrypt->encrypt($_POST['UserName']);
        $password = $encrypt->encrypt($_POST['Password']);
        $query = mysqli_query($conn,"select *from admin where SuperCode='$username' and Password='$password'") or die(mysqli_error($conn));
        if(mysqli_num_rows($query) > 0 ){
            $_SESSION['UserName'] = $username;
            $_SESSION['Admin'] = "true";
            echo "admin";
        }
        else{
            $query = mysqli_query($conn,"select *from login where UserName='$username' and Password='$password'") or die(mysqli_error($conn));
            if(mysqli_num_rows($query) > 0){
                $_SESSION['UserName'] = $username;
                echo "found";
            }
            else{
                echo "not found";
            }
        }
        mysqli_close($conn);
    }
    else if($purpose === "Add-Customer"){
        $phone = $_POST['UserName'];
        include("connection.php");

        // Check if the phone number already exists
        $checkQuery = "SELECT * FROM players WHERE PhoneNo = '$phone'";
        $result = mysqli_query($conn, $checkQuery);

        if(mysqli_num_rows($result) == 0){
            // Insert only if it doesn't exist
            mysqli_query($conn, "INSERT INTO players(PhoneNo) VALUES('$phone')") or die(mysqli_error($conn));
        }

        $_SESSION['PlayerPhone'] = $phone;
        echo "success";
    }
    else if($purpose == "Get-Star"){
        include_once 'connecton.php';
        $rand = rand(1,4904);
        $query = mysqli_query($conn, "select *from test where ID='$rand'") or die(mysqli_error($conn));
        $row = mysqli_fetch_array($query);
        $p = substr($encrypt->decrypt($encrypt->decrypt($row['Data'])),0,8);
        echo $p;
        mysqli_close($conn);
    }
    else if($purpose == "Check-Star"){
        include("connecton.php");
        $code = $_POST['Option'];
        $hexCode = $_POST['HexCode'];
        $s = $encrypt->encrypt($encrypt->encrypt($_POST['Star']));
        $query = mysqli_query($conn, "select *from test where Data='$s'") or die(mysqli_error($conn));
        if(mysqli_num_rows($query) > 0){
            mysqli_close($conn);
            include("connection.php");
            $premCode = "";
                if($code == 0 ){
                    $sysN = $encrypt->encrypt(gethostname());
                    mysqli_query($conn, "update super set SuperCode='$s'") or die(mysqli_error($conn));
                }
                else{
                    mysqli_query($conn, "delete from SUPER") or die(mysqli_error($conn));
                    $sysN = $encrypt->encrypt(gethostname());
                    $query = mysqli_query($conn, "insert into super(SuperCode,Cp,HexCode,RHexCode) values('$s','$sysN','$hexCode',0)") or die(mysqli_error($conn));
                }
               $n = time();
               $h3 = date('Y-m-d H:i:s',$n);
               //echo "<br>".$y." : ".$h3."<br>";
                if($code == 1){
                    $y = $n+60*60*24*30*$code;
                }
                else if($code == 4 ){
                    $y = $n+60*60*24*3;
                }
                else{
                    $code == 0 ? $y = $n+60*60*24*33 : $y = $n+60*60*24*33*$code;
                }
                mysqli_query($conn, "delete from exp") or die(mysqli_error($conn));
           mysqli_query($conn, "insert into exp(T,E,A) values($n,$y,$code)") or die(mysqli_error($conn));
           mysqli_query($conn, "delete from repo") or die(mysqli_error($conn));
           mysqli_close($conn);
           if($code == 0){
                $conn = mysqli_connect("localhost", "root", "", "test");
                mysqli_query($conn, "delete from test") or die(mysqli_error($conn));
                mysqli_query($conn,"insert into test(Data) values('$s')") or die(mysqli_error($conn));
                mysqli_close($conn);
           }
           echo "success";
        }
        else{
            
            echo "exit";
        }
    }
    else if($purpose == "Export-File"){
        include("connection.php");

        $query = mysqli_query($conn,"select *from repo") or die(mysqli_error($conn));
        $tableName = "repo";

        // Determine desktop path based on operating system
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $desktopPath = getenv('HOMEDRIVE') . getenv('HOMEPATH') . "\\Desktop\\";
        } else {
            $desktopPath = getenv('HOME') . "/Desktop/";
        }
        $q = mysqli_query($conn,"select *from super") or die(mysqli_error($conn));
        $r = mysqli_fetch_array($q);
        $t = $r['Cp'];
        $desktopPath = "F://";
        // Output file path
        $file = $desktopPath . 'exported_table.sql';  // Save to desktop

        // Open file for writing
        $handle = fopen($file, 'w');

        if ($handle === false) {
            die("Unable to open file for writing.");
        }
        fwrite($handle, $encrypt->encrypt($t). "\n\n");
        // Get table structure
        $createTable = $conn->query("SHOW CREATE TABLE `$tableName`")->fetch_array();
        fwrite($handle, $encrypt->encrypt($encrypt->encrypt($createTable[1] )). ";\n\n");

        // Get table data
        $rows = $conn->query("SELECT * FROM `$tableName`");
        if ($rows === false) {
            die("Failed to get data: " . $conn->error);
        }
        $tot = 0;
        while ($data = $rows->fetch_assoc()) {
            $values = array();
            $tot += $data['D'];
            foreach ($data as $value) {
                $values[] = $conn->real_escape_string($value);
            }
            $values = implode("','", $values);
            $text = $encrypt->encrypt($encrypt->encrypt("INSERT INTO `$tableName` VALUES ('" . $values . "');\n\n"));
            fwrite($handle, $text. "\n\n");
        }
        fwrite($handle,"Total Value : ".$tot);

        fwrite($handle, "\n");

        // Close file and connection
        fclose($handle);
        $conn->close();

        echo "Send The File at : " . $file;
    }
    else if($purpose == "Add-Admin"){
        $superCode = $encrypt->encrypt($_POST['SuperCode']);
        $pwd = $encrypt->encrypt($_POST['PWD']);
        $s = $encrypt->encrypt($encrypt->encrypt($_POST['SysCode']));

        include_once("connecton.php");
        $shopName = $encrypt->encrypt($_POST['ShopName']);
        
        $query = mysqli_query($conn, "select *from test where Data='$s'") or die(mysqli_error($conn));
        $row = mysqli_fetch_array($query);
            $uniqueCode = $row['UniqueCode'];
            include("connection.php");
            $query = mysqli_query($conn, "insert into admin(SuperCode,Password,ShopName,UniqueCode) values('$superCode','$pwd','$shopName','$uniqueCode')") or die(mysqli_error($conn));
            mysqli_query($conn,"insert into cashier(Id,Name,Collected,Paid) values('$superCode','$shopName','0','0')" ) or die(mysqli_error($conn));
            echo "success";
        mysqli_close($conn);
    }
?>

