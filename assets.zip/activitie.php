FUCK YOU MEN

<?php
	ini_set('max_execution_time', 0);
	include_once("encryption.php");
	include("connecton.php");
	$encrypt = new encryption();

	$arrayName = array();
	for($i=1;$i<76;$i++){
		echo"<br>";
		echo '\'/audio/'.$i.".mp3'";
	}
	//'/audio/3.mp3',
	/*for($i=1;$i<=4904;$i++){
		$uCode = rand(1,4904);
		if(in_array($uCode, $arrayName)){
			$i--;
			echo "<br> match found";
		}
		else{
			array_push($arrayName, $uCode);

			$encC = $encrypt->encrypt($encrypt->encrypt($uCode));
			echo "<br>".$i." - ".$uCode." - ".$encC."<br>";
			mysqli_query($conn,"update test set UniqueCode='$encC' where ID='$i'") or die(mysqli_error());
			//mysqli_query($conn, "insert into uc(ID,uc) values('$i','$encC')") or die(mysqli_error($conn));
		}
	}
	/*mysqli_query($conn,'delete from uc') or die(mysqli_error());
	for($i=1;$i<=8000;$i++){
		$uCode = randomString();
			if(in_array($uCode, $arrayName)){
				$i--;
			}
			else{
			array_push($arrayName, $uCode);

			$encC = $encrypt->encrypt($encrypt->encrypt($uCode));
			echo "<br>".$i." - ".$uCode."<br>";
			mysqli_query($conn, "insert into uc(ID,uc) values('$i','$encC')") or die(mysqli_error($conn));
		}
		
	}
	function randomString($length = 10){
		$characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$charlength = strlen($characters);
		$randomString = '';
		for($i=0;$i<$length;$i++){
			$randomString .=$characters[random_int(0, $charlength-1)];
		}
		return $randomString;
	}*/
?>