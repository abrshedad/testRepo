<!DOCTYPE html>
<?php
    session_start();
    if(isset($_SESSION['UserName']) && $_SESSION['UserName'] != ""){
        echo $_SESSION['UserName'];
        include_once '../connection.php';
        include_once '../encryption.php';
        $encrypt = new encryption();
        $query = mysqli_query($conn, "select ShopName,UniqueCode from admin") or die(mysqli_error($conn));
        $res = mysqli_fetch_array($query);
        $shopName = $encrypt->decrypt($res['ShopName']);
        $uniq = $encrypt->decrypt($encrypt->decrypt($res['UniqueCode']));
        $shopName = $shopName." - ".$uniq;
?>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>AB STAR BINGO</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />


    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />
    <link rel="stylesheet" href="../assets/css/styles.css"/>
    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
    <script src="../assets/sweet.js"></script>
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/js/html2canvas.min.js"></script>
    <script src="../assets/print.min.js"></script>
    <link rel="stylesheet" href="../assets/css/styles.css"/>
    <link rel="stylesheet" href="../assets/css/mobile.css"/>

    <style>
        .footer{
            background: linear-gradient(0deg, red 50%, rgba(253,187,45,1) 100%);;
            color: gold;
        }
        .printDiv{
            display: inline-block;
            margin-bottom: 15px;
        }
        .spin{
            background:rgb(131,58,180);
            background-b: linear-gradient(90deg, rgba(131,58,180,1) 0%, rgba(62,29,253,1) 19%, rgba(74,57,219,1) 41%, rgba(74,66,208,1) 48%, rgba(73,77,194,1) 57%, rgba(73,85,185,1) 63%, rgba(73,143,85,1) 63%, rgba(73,107,159,1) 68%, rgba(73,116,148,1) 70%, rgba(73,120,143,1) 71%, rgba(73,142,117,1) 76%, rgba(72,206,38,1) 91%, rgba(72,219,22,1) 94%, rgba(71,232,6,1) 97%, rgba(252,176,69,1) 100%);;
              text-align: center;
              align-items: center;
              color: white;
              left : 0;
              position: relative;
        }
        .spin:hover{
            width: 80px;
            height: 45px;
        }
        .btn-input{
            cursor: text;
        }
        .cancel_btn{
            background: black;
            color: white;
        }
        .shakePremium {
            font-size: 200%;
            animation: shake 10s infinite;
            margin: 0px;
        }
        @keyframes shake{
            0% { color: green; transform:rotate(0deg); }
            50% { color:yellow; }
            80% { color: red;transform:rotate(0deg); }
            85% { transform:rotate(5deg); }
            95% { transform:rotate(-5deg); }
            100% { transform:rotate(0deg); }
        }

    </style>
    <script>
        var selectedCartelas = new Array();
        var d = new Date();
        var day = d.getDate();
        var month = d.getMonth();
        var year = d.getFullYear();
        var interval;
        var counter = 1,currentWinnerNos,goodBingoId,goodBingoFound = false; 
        let currentPosition = 0;
        let storedWinnerCartelas = [];
        var totalCartelasForCurrentGame = 0;
        let storedArr = JSON.parse(localStorage.getItem('myArray')) || [];
        var isLastNumberInWinners = false;
        var lastNumberIsInGreenRows = false;
        var lastNumberIsInGreenCols = false;
        var lastNumberIsInGreenDiags = false;
        let lastNumberInAny = false;
        let gamePaused = false;
        let userInput = 0;
        
        // with socket programming
        let gameStatusDiv = "";
        let running = false;
        let lastWinnerNo = 0;
        const host = window.location.hostname;
        const socket = new WebSocket(`ws://${host}:8999`);
        let messageQueue = [];

        socket.onopen = () => {
            gameStatusDiv.innerHTML = "Connected ✅";
            while (messageQueue.length > 0) {
                socket.send(messageQueue.shift());
            }
        };
        socket.onmessage = (event) => {
            const data = JSON.parse(event.data);

            if (data.type === "status") {
              running = data.running;
              if (data.all) {
                data.all.forEach(n => setColorToCalledNumbers(n));
              }
              gameStatusDiv.textContent = running ? "Game running..." : "Game stopped.";
            }

            if (data.type === "number" && running) {
                //console.log(data.value);
              if (data.value) {
                //markNumberOnCard(data.value);
                showWinner(data.value);
                if(lastWinnerNo!=0) addWinnerNumber(lastWinnerNo);
                lastWinnerNo = data.value;
              }
            }
            if (data.type === "paused") {
                console.log("game paused ");
                running = false
                gameStatusDiv.textContent = "Game paused for checking cards ⏸️"; 
                const modal = document.getElementById('checkCartelaModal');

                if (modal.classList.contains('show')) {
                    console.log('Modal is OPEN');
                } else {
                    const button = document.getElementById('pauseGameButton');
    
                    // Check if the button exists
                    if (button) {
                        // Simulate a click on the button
                        button.click();
                    }
                }      
            }
            if (data.type === "resumed") {
                running = true;
                gameStatusDiv.textContent = "Game resumed ▶️";
            }

            if (data.type === "start") {
                running = true;
                gameStatusDiv.style.display = "block";
                gameStatusDiv.textContent = "Game started!";
                document.getElementById('lastThreeWinners').innerHTML ="";
            }
            if (data.type === "restart") {
                running = true;
                gameStatusDiv.style.display = "block";
                gameStatusDiv.textContent = "Game Re-started!";
                document.getElementById('lastThreeWinners').innerHTML ="";
            }
        };

        socket.onerror = () => {
          gameStatusDiv.textContent = "Connection error ❌";
        };

        socket.onclose = () => {
          gameStatusDiv.textContent = "Disconnected from server";
          okBtn.disabled = true;
        };

        function setColorToCalledNumbers(value){
            const x = parseInt(value);
            const parentDiv = document.getElementById("winnerShow_tbl");
            if (x >= 1 && x <= 75) {
                const row = Math.floor((x - 1) / 15);
                const col = ((x - 1) % 15) + 1;

                parentDiv.rows[row].cells.item(col).style.backgroundColor = "green";
                parentDiv.rows[row].cells.item(col).style.color = "white";
            }
        }
        $(document).ready(function(){
            
            //window.addEventListener('contextmenu',function(e){e.preventDefault();},false);
            changeAudio();
            getSelectedValue(); 
            gameStatusDiv = document.getElementById("status_div");
            $.ajax({
                url: "activities.php",
                type:"post",
                data:({Purpose:"Current-Activity"}),
                success: function(result){
                    if(result == 0 ) {
                        loadUntakenCartelas();
                        document.getElementById("addPlayTime_div").style.display = "none";
                        document.getElementById("displayWinnerTime_div").style.display="none";
                    }
                    else if(result == 2){
                        document.getElementById("addPlayTime_div").style.display = "none";
                        document.getElementById("displayWinnerTime_div").style.display="block";
                        disableBetElements();
                        const button = document.getElementById('pauseGameButton');
    
                        // Check if the button exists
                        if (button) {
                            // Simulate a click on the button
                            button.click();
                        }
                        getWinnerNos();
                        pauseGame();
                    }
                    else {
                        document.getElementById("addPlayTime_div").style.display = "none";
                        document.getElementById("displayWinnerTime_div").style.display="block";
                        getWinnerNos();
                        showWinners(currentWinnerNos,currentPosition);
                        disableBetElements();            
                    }  
                }
            });
            showDetail();
        });
        // after mobile functionality is added
        function getWinnerNos(){
            $.ajax({
              url: "bingoMobileActivities.php",
              type: "post",
              data:({Purpose:"Get-Winners"}),
              success: function(result){
                  var res = JSON.parse(result);
                  currentWinnerNos = res.winnerNos.trim();
                  document.getElementById('lastThreeWinners').innerHTML ="";
                  currentPosition = parseInt(res.currentPosition);
                  console.log(currentWinnerNos+"\n : "+currentPosition);
                }
            });
        }
        function enableBetElements(){
            const div = document.getElementById('selectBetAmount_div');
            const buttons = div.querySelectorAll('button');
            buttons.forEach(button => {
                button.disabled = false;
            });
            document.getElementById("betAmount_txt").disabled = false;
            document.getElementById("defaultMessage_div").style.display="block";
            localStorage.setItem("allLinePlay",false);
            localStorage.setItem("noOfAllLines",0);
            localStorage.setItem("noOfRows",0);
            localStorage.setItem("noOfCols",0);
            localStorage.setItem("noOfDiagonals",0);
        }
        function disableBetElements(){
            const div = document.getElementById('selectBetAmount_div');
            const buttons = div.querySelectorAll('button');
            buttons.forEach(button => {
                button.disabled = true;
            });
            document.getElementById("betAmount_txt").disabled = true;
            document.getElementById("defaultMessage_div").style.display="none";
        }
        function changeText(id) {
            id.value = "";
            var text = id.value;
            if(text=="NaN"){ id.innerText = "10";}
        }
        function focusOut(id){
            var text = id.innerText;
            if(text == ""){ id.innerText = "ODD";}
        }
        function changeValue(id){
            id.value = "";
        }

        function addBetAmount(value){
            document.getElementById("betAmount_txt").value = value;
        }
        function loadCashierData(){
            document.getElementById("success_td").innerHTML = "";
            $.ajax({
                url: "../AdminPage/activities.php",
                type:"post",
                data:({Purpose:"Load"}),
                success: function(result){
                   document.getElementById("cashierData_div").innerHTML = result;
                }
            });
        }
        function au(i,c,p,diff,n){
            swal({
              title: "Accept "+diff+"Birr From Cashier ?",
              text: "Be sure before click procced.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((betCartela) => {
              if (betCartela) {
                 var success = document.getElementById("success_td");
                $.ajax({
                    url: "../AdminPage/activities.php",
                    type:"post",
                    data:({Purpose:"Au",I:i,Am:diff,C:c,P:p,N:n}),
                    success: function(result){
                        var r = $.trim(result);
                         success.innerHTML = r;
                        if(r === "not admin"){
                            window.open("../","_self");
                        }
                        else if(r === "success"){
                            success.innerHTML = "Cashier Audited Successfully.";
                            success.style.backgroundColor = "gold";
                            //window.open("MainPage/","_self");
                            loadCashierData();
                        }
                        else{
                            success.innerHTML="Error to Audit Cashier. "+result;
                            success.style.backgroundColor = "red";
                        }
                    }
                });
              }
            });
            
        }
        function saveMyBingos(cartelaId){
            var amount = parseInt(document.getElementById("betAmount_txt").value);
            var divId = document.getElementById("bingos_div");
            var phone = document.getElementById("customerPhone_txt").value;
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Save-Bingo",CartelaNo:cartelaId,BetAmount:amount,PhoneNo:phone}),
                success : function(result){
                    //printDiv("bingos_div");
                    document.getElementById("saveMyBingosFromTemporary_btn").style.display = "none";
                    loadUntakenCartelas();
                    printDiv();
                    showDetail();
                    getPhoneNos();
                    $('#bingos_div').html(result);
                }
            });
        }

        function saveMyBingosWithArray(cartelaId){
            const amount = parseInt(document.getElementById("betAmount_txt").value);
            const phoneInput = document.getElementById("customerPhone_txt");
            const phone = phoneInput.value.trim();

            if (!/^\d{10}$/.test(phone)) {
                phoneInput.focus();
                phoneInput.style.border = "1px solid red";
                return;
            }

            phoneInput.style.border = "0.5px solid blue";
            $.ajax({
                url:"bingoActivities.php",
                type:"post",
                data:{Purpose:"Save-Bingo-Array",SelectedCartelas:selectedCartelas,BetAmount:amount,PhoneNo:phone},
                success:function(result){
                    const r=$.trim(result);
                    loadUntakenCartelas();
                    showDetail();
                    getPhoneNos();
                    if(r==="success"){
                        totalCartelasForCurrentGame=parseInt(totalCartelasForCurrentGame)+selectedCartelas.length;
                        selectedCartelas=[];
                        document.getElementById("saveMyBingosFromTemporary_btn2").style.display="none";
                        document.getElementById("cartelaSavedMessage_div").style.display="block";
                        var tempoTotal = totalCartelasForCurrentGame;
                        tempoTotal = parseInt(tempoTotal)+parseInt(selectedCartelas.length);
                        document.getElementById("noOfTotalTakenCartelas_h5").innerText = "የተመረጡ ካርቴላዎች ብዛት ➡️> "+selectedCartelas.length+"\n ጠቅላላ የተያዙ እና የተመረጡ ካርቴላዎች ብዛት ➡️> "+tempoTotal;  
                        console.log("temp total "+tempoTotal);
                        document.getElementById("customerPhone_txt").value="";
                    }
                }
            });
        }

        function  loadUntakenCartelas() {
            $.ajax({
                url: "bingoActivities.php",
                type: "POST",
                data: { Purpose: "Load-Untaken-Bingos" },
                dataType: "json",
                success: function(response) {
                    const untakenContainer = $('#untakenBingos_li');
                    const takenContainer = $('#takenBingos_li');

                    untakenContainer.empty();
                    takenContainer.empty();

                    // Untaken bingos (no phone number)
                    response.untaken.forEach(code => {
                        const button = $('<button>')
                            .addClass('btn btn-outline-info rounded-pill')
                            .attr({
                                type: 'button',
                                value: code,
                                'data-bs-toggle': 'tooltip',
                                'data-bs-placement': 'top'
                            })
                            .text(code)
                            .on('click', function () { changeColor(this); });

                        untakenContainer.append(button);
                    });

                    // Taken bingos (with PhoneNo as tooltip)
                    response.taken.forEach(item => {
                        const tooltipText = item.PhoneNo 
                            ? `${item.PhoneNo}` 
                            : 'Already taken';

                        const button = $('<button>')
                            .addClass('btn btn-outline-info rounded-pill')
                            .attr({
                                type: 'button',
                                value: item.No,
                                'data-bs-toggle': 'tooltip',
                                'data-bs-placement': 'top',
                                title: tooltipText
                            })
                            .text(item.No)
                            .on('click', function () { removeSelection(this,1); });

                        takenContainer.append(button);
                    });

                    totalCartelasForCurrentGame = response.taken.length;
                    // Initialize Bootstrap tooltips
                    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                    tooltipTriggerList.map(function (tooltipTriggerEl) {
                        return new bootstrap.Tooltip(tooltipTriggerEl);
                    });
                },
                error: function(xhr, status, error) {
                    console.error("Failed to load bingo data:", error);
                }
            });
        }
        function removeSelection(id,type){
            const cartNo = id.value;
            var amount = parseInt(document.getElementById("betAmount_txt").value);
            let text = "";
            text = type == 1 ? "Remove Cartela "+cartNo+ " ? " :  "Remove all selections ? ";
            swal({
              title: "Are you remove this selection ??",
              text: text,
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((betCartela) => {
              if (betCartela) {
                $.ajax({
                    url : "bingoMobileActivities.php",
                    type: "post",
                    data: ({Purpose:"Remove-Selection",CartelaNo:cartNo,Type:type,BetAmount:amount}),
                    success : function(result){
                        console.log(result);
                        loadUntakenCartelas();
                        if(type == 1){
                            totalCartelasForCurrentGame=parseInt(totalCartelasForCurrentGame)-1;
                        } else {
                            totalCartelasForCurrentGame=0;
                        }
                        var tempoTotal = totalCartelasForCurrentGame;
                        tempoTotal = parseInt(tempoTotal)+parseInt(selectedCartelas.length);
                        document.getElementById("noOfTotalTakenCartelas_h5").innerText = "የተመረጡ ካርቴላዎች ብዛት ➡️> "+selectedCartelas.length+"\n ጠቅላላ የተያዙ እና የተመረጡ ካርቴላዎች ብዛት ➡️> "+tempoTotal;  
                        console.log("temp total "+tempoTotal);
                        showDetail();
                    }
                });
              }
            });
        }

        function startGame(){
            swal({
              title: "Are you sure to start the bingo ??",
              text: "If you say yes, The game will start genereting winners automatically.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((betCartela) => {
              if (betCartela) {
                 var success = document.getElementById("success_td");
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Generate-Winners"}),
                    success : function(result){
                        currentWinnerNos = result.trim();
                        document.getElementById('lastThreeWinners').innerHTML="";
                        currentPosition = 0;
                        resetTableCellsToDefaultColor();
                        //showWinners(result,0);
                        storedArr = [];
                        document.getElementById("addPlayTime_div").style.display = "none";
                        document.getElementById("displayWinnerTime_div").style.display="block";
                        localStorage.setItem("bingoSelectedData","");
                        totalCartelasForCurrentGame = 0;
                        socket.send(JSON.stringify({ type: 'startGame' }));
                    }
                });
              }
            });            
        }
        function endGame(){
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"End-Game"}),
                success : function(result){
                    var r = $.trim(result);
                    if(r !== "success"){
                        endGame();
                    }
                    gamePaused = false;                     
                }
            });
        }
        function restartFullGame(){
            const c = getTypeOfPlayMessage();
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"End-Game",PlayType:c}),
                success : function(result){
                        setTimeout(function() {
                            $.ajax({
                            url : "bingoActivities.php",
                            type: "post",
                            data: ({Purpose:"Generate-Winners"}),
                            success : function(result){
                                console.log("winnerNos : "+result);
                                result = result.trim();
                                currentWinnerNos = result;
                                currentPosition = 0;
                                resetTableCellsToDefaultColor();
                                showWinners(result,0);
                                document.getElementById("addPlayTime_div").style.display = "none";
                                document.getElementById("displayWinnerTime_div").style.display="block";
                                socket.send(JSON.stringify({ type: 'restart' }));
                            }
                        });
                    }, 3000); // Delay of 3000ms (3 seconds)
                }
            });  
        }
        function exitMatch(){
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Exit-Match"}),
                success : function(result){
                    const val = 0;
                    //window.location.href = "report.php?message=${val}";
                    localStorage.setItem('Winner-Cartela',val);
                    resetTableCellsToDefaultColor();
                    counter = 151;
                    document.getElementById("goodBingo_btn").style.display = "none";
                    document.getElementById("horseRedeem_div").style.display = "block";
                }
            });
        }
        function showWinner(value) {
            const parentDiv = document.getElementById("winnerShow_tbl");
            const hostId = document.getElementById("winnerNumber_span");
            const winnerBadgeSpan = document.getElementById("winnerBadge_span");
            hostId.innerHTML = "0 0";

            const letter = getBingoLetter(value);
            winnerBadgeSpan.textContent = letter;
            hostId.textContent = value;

            // Trigger animation
            hostId.classList.remove("pop-in-glow");
            void hostId.offsetWidth;
            hostId.classList.add("pop-in-glow");

            // Color the number
            const x = parseInt(value);
            if (x >= 1 && x <= 75) {
                const row = Math.floor((x - 1) / 15);
                const col = ((x - 1) % 15) + 1;

                parentDiv.rows[row].cells.item(col).style.backgroundColor = "green";
                parentDiv.rows[row].cells.item(col).style.color = "white";
            }
        }

        async function showWinners(result,c){
            console.log("res");
        }

        function checkForStatusChange() {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: "bingoActivities.php",
                    type: "post",
                    data: { Purpose: "Check-Say-Bingo" },
                    success: function (result) {
                        var res = result.trim();
                        console.log("testing" + res);
                        if ((res == "1" || res == 1) && gamePaused == false) {
                            gamePaused = true;
                            document.getElementById('pauseGameButton').click();
                            pauseGame();  // This should stop further processing
                            resolve(false);
                        } else {
                            resolve(true);
                        }
                    },
                    error: function () {
                        reject(false);
                    }
                });
            });
        }

        function getBingoLetter(number) {
            if (number >= 1 && number <= 15) return "B";
            if (number >= 16 && number <= 30) return "I";
            if (number >= 31 && number <= 45) return "N";
            if (number >= 46 && number <= 60) return "G";
            if (number >= 61 && number <= 75) return "O";
            return "?"; // fallback for out-of-range numbers
          }
        function addWinnerNumber(number) {
            const container = document.getElementById('lastThreeWinners');

            const circle = document.createElement('div');
            circle.className = 'lastWinnerCircle';
            circle.innerText = number;

            container.prepend(circle);

            // Force reflow to apply animation
            circle.offsetWidth;

            // Push-in class triggers transition
            circle.classList.add('push-in');

            // Keep only the last 3
            while (container.children.length > 3) {
              container.removeChild(container.lastChild);
            }
        }
        function resetTableCellsToDefaultColor() {
          const table = document.getElementById("winnerShow_tbl");
          if (!table) return;

          const rows = table.rows;
          for (let i = 0; i < rows.length; i++) {
            const cells = rows[i].cells;
            for (let j = 1; j < cells.length; j++) {
                cells[j].style.color = "black";
              cells[j].style.backgroundColor = ""; // reset to default
            }
          }
        }

        function getPhoneNos(){
            $.ajax({
              url: 'bingoMobileActivities.php', // Adjust the path to your PHP file
              type: 'POST',
              dataType: 'json',
              data: { Purpose: "Get-PhoneNos"},
              success: function (data) {
                const datalist = document.getElementById("datalistOptions");
                datalist.innerHTML = ""; // Clear old options

                data.forEach(phone => {
                  const option = document.createElement("option");
                  option.value = phone;
                  datalist.appendChild(option);
                });
              },
              error: function (err) {
                console.error("Failed to load phone numbers:", err);
              }
            });
        }

        var totalNoOfWinnerCartelas = 0;
        function pauseGame(){  
            clearInterval(interval);
            if(running) socket.send(JSON.stringify({ type: 'pause', phone:'Admin' }));
            captureAndStoreImage();
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Pause-Game"}),
                success : function(result){
                    let res = $.trim(result);
                    if(res === "none" || res === "" || res ===null){
                        document.getElementById("exitBingo_btn").style.display = "block";
                        $('#topRowCheckCartela_div').html("");
                        $('#checkCartelaModalBody_div').html("");
                    } else{
                        document.getElementById("exitBingo_btn").style.display = "none";
                        $('#topRowCheckCartela_div').html = result;
                        document.getElementById("topRowCheckCartela_div").innerHTML = result;
                        document.getElementById("playTypeCheckCartela_div").innerHTML = getTypeOfPlayMessage();
                        
                        $('#checkCartelaModalBody_div').html("");
                        totalNoOfWinnerCartelas = 0;
                        document.getElementById("totalNoOfWinners_txt").value = totalNoOfWinnerCartelas;
                        storedWinnerCartelas.length = 0;
                        if( localStorage.getItem("noOfWinnerNumbersShown") >= 150 )
                            document.getElementById("refreshGame_btn").style.display = "block";
                        else
                            document.getElementById("refreshGame_btn").style.display = "none";
                    }
                    storedArr = JSON.parse(localStorage.getItem('myArray')) || [];
                    let reversedArr = storedArr.slice().reverse();
                    let header = document.getElementById("lastThreeWinners_h3");
                    const colors = ['#2ecc71', '#f1c40f','#e74c3c'];
                    header.innerText = "";
                    reversedArr.forEach((value, index) => {
                      let btn = document.createElement('button');
                      btn.textContent = value;
                      btn.className = 'btn';
                      btn.classList.add("rounded-pill");
                      btn.classList.add("btn-dark");
                      btn.style.backgroundColor = colors[index % colors.length];
                      header.appendChild(btn);
                    });
                }
            });
        }
        function restartGame(){
            localStorage.setItem('goodBingoIsFound', false);
            localStorage.setItem('cartelaNo', "");
            localStorage.removeItem("storedImage");
            if(goodBingoFound){
                endGame();
                goodBingoFound =false;
                return;
            }
            document.getElementById("goodBingo_btn").style.display = "none";
            document.getElementById("badBingo_message").style.display = "none";
            document.getElementById("horseRedeem_div").style.display = "none";
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Restart-Game"}),
                success : function(result){
                    var r = $.trim(result);
                    if(r === "success"){
                        console.log("restarted" + result);
                        showWinners(currentWinnerNos, currentPosition);
                        gamePaused = false;
                    }
                    else{
                        console.log("result : " + result);
                        restartGame();
                    }
                }
            });
            socket.send(JSON.stringify({ type: 'resume' }));
        }

        function checkMyBingos(){
            var no = document.getElementById("selectBingoCartelaToCheck_option").value;
            if(no != 0 ){
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Load-My-Bingo-Detail",CartelaNo:no}),
                    success : function(result){
                        $('#checkCartelaModalBody_div').html(result);
                    }
                });
            }
        }
        function checkMyBingos(no){
            //var no = document.getElementById("selectBingoCartelaToCheck_option").value;
            if(no != 0 ){
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Load-My-Bingo-Detail",CartelaNo:no}),
                    success : function(result){
                        $('#checkCartelaModalBody_div').html(result);
                    }
                });
            }
        }
        function setBackground(bingoCode,winnersShown,noOfShownWinners){
            lastNumberInAny = false;
            storedArr = JSON.parse(localStorage.getItem('myArray')) || [];
            console.log(" ============= ============ ====== > "+storedArr[2]);
            for (var i = 0; i < 5; i++) {
                for(var j=1; j<=5; j++){
                    var playTableValue = document.getElementById(bingoCode).rows[j].cells.item(i).innerText;
                    //checkNumber(playTableValue,winnersShown);
                    for(var m = 0;m<=noOfShownWinners;m +=2){
                        if(winnersShown.substr(m,2) == playTableValue){
                            //console.log('match'+ " : "+winnersShown.substr(m,2)+" : "+playTableValue);
                            document.getElementById(bingoCode).rows[j].cells.item(i).style.backgroundColor="green";
                        }
                        if(parseInt(playTableValue) === storedArr[2]){
                            lastNumberInAny = true;
                        }
                    }
                } 
            }
            document.getElementById(bingoCode).rows[3].cells.item(2).style.backgroundColor="green";
            checkBingoResultRows(bingoCode);
        }
        function checkBingoResultRows(bingoCode) {
            const storedArr = JSON.parse(localStorage.getItem('myArray')) || [];
            const anyNumberPlay = parseInt(localStorage.getItem("AnyNumbers")) || 0;
            const table = document.getElementById(bingoCode);

            let noOfRows = 0, noOfCols = 0, noOfDiagonals = 0;
            let lastNumberIsInGreenRows = false;
            let lastNumberIsInGreenCols = false;
            let lastNumberIsInGreenDiags = false;
            if (anyNumberPlay !== 0) {
                let validCols = 0;
                for (let col = 0; col < 5; col++) {
                    let greenCount = 0;
                    for (let row = 1; row < 6; row++) {
                        if (table.rows[row].cells[col].style.backgroundColor === "green") {
                            greenCount++;
                        }
                    }
                    if (greenCount >= anyNumberPlay) validCols++;
                }
                if (validCols >= 3) {
                    showWinOrLoss(storedArr.includes(storedArr[2]), bingoCode);
                } else {
                    displayErrorMessage(bingoCode);
                }
                return;
            }

            // ROW & COL check
            for (let row = 1; row < 6; row++) {
                let isGreenRow = true, isGreenCol = true;

                for (let col = 0; col < 5; col++) {
                    if (table.rows[row].cells[col].style.backgroundColor !== "green") isGreenRow = false;
                    if (table.rows[col + 1].cells[row - 1].style.backgroundColor !== "green") isGreenCol = false;
                }

                if (isGreenRow) {
                    noOfRows++;
                }

                if (isGreenCol) {
                    noOfCols++;
                }
            }

            // DIAGONAL 1 (top-left to bottom-right)
            let greenMainDiagonal = true;
            for (let i = 1; i <= 5; i++) {
                if (table.rows[i].cells[i - 1].style.backgroundColor !== "green") {
                    greenMainDiagonal = false;
                    break;
                }
            }
            if (greenMainDiagonal) {
                noOfDiagonals++;
            }

            // DIAGONAL 2 (bottom-left to top-right)
            let greenAntiDiagonal = true;
            for (let row = 5, col = 0; row > 0 && col < 5; row--, col++) {
                if (table.rows[row].cells[col].style.backgroundColor !== "green") {
                    greenAntiDiagonal = false;
                    break;
                }
            }
            if (greenAntiDiagonal) {
                noOfDiagonals++;
            }

            const total = noOfRows + noOfCols + noOfDiagonals;

            //console.log(noOfRows + " : "+noOfCols+" : "+noOfDiagonals+ " = "+total);
            // Update UI
            document.getElementById(`${bingoCode}rows_td`).innerText = noOfRows;
            document.getElementById(`${bingoCode}cols_td`).innerText = noOfCols;
            document.getElementById(`${bingoCode}diagonals_td`).innerText = noOfDiagonals;
            document.getElementById(`${bingoCode}total_td`).innerText = total;

            const res = checkWinOrLoss(noOfRows, noOfCols, noOfDiagonals, total, bingoCode);

            if (!res) return displayErrorMessage(bingoCode);

            const noOfAllLine = parseInt(localStorage.getItem("noOfAllLines")) || 0;
            const playLines = localStorage.getItem("linesSelected");

            if (playLines !== "0") {
                showWinOrLoss(true,bingoCode);
            } else if (noOfAllLine !== 0) {
                showWinOrLoss(true,bingoCode);
            } else {
                if (
                    (noOfRows >= parseInt(localStorage.getItem("noOfRows"))) ||
                    (noOfCols >= parseInt(localStorage.getItem("noOfCols")) ) ||
                    (noOfDiagonals >= parseInt(localStorage.getItem("noOfDiagonals")))
                ) {
                    document.getElementById("removeCartela_btn").style.display = "none";
                    showWinOrLoss(true, bingoCode);
                } else {
                    showWinOrLoss(false, bingoCode);
                }
            }
        }

        function checkWinOrLoss(row, col, diag, total, id) {
            const storedArr = JSON.parse(localStorage.getItem('myArray')) || [];
            const noOfAllLine = localStorage.getItem("noOfAllLines");
            const playLines = localStorage.getItem("linesSelected");
            

            const table = document.getElementById(id); // id is the bigoCode

            const isGreenCol = (colIdx) => {
                for (let row = 1; row < 6; row++) {
                    if (table.rows[row].cells[colIdx].style.backgroundColor !== "green") return false;
                }
                //console.log(colIdx+" is Green column");
                return true;
            };

            const isGreenRow = (rowIdx) => {
                for (let col = 0; col < 5; col++) {
                    if (table.rows[rowIdx].cells[col].style.backgroundColor !== "green") return false;
                }
                //console.log(rowIdx+" is Green row");
                return true;
            };

            const isGreenDiagonal = () => {
                for (let row = 1; row <= 5; row++) {
                    //console.log(table.rows[row].cells[row - 1]);
                    if (table.rows[row].cells[row - 1].style.backgroundColor !== "green") return false;
                }
                return true;
            };

            const isFourCorner = () => {
                if(table.rows[1].cells[0].style.backgroundColor != "green") return false;
                if(table.rows[1].cells[4].style.backgroundColor != "green") return false;
                if(table.rows[5].cells[0].style.backgroundColor != "green") return false;
                if(table.rows[5].cells[4].style.backgroundColor != "green") return false;
                return true;
            };

            isGreenDiagonal();

            if (playLines !== "0") {
                if (isGreenCol(0)) {
                    if (playLines === "L" && isGreenRow(5)) return true;
                    if (playLines === "በ" && isGreenCol(4) && isGreenRow(1)) return true;
                    if (playLines === "ሀ" && isGreenCol(4) && isGreenRow(5)) return true;
                    if (playLines === "N" && isGreenCol(4) && isGreenDiagonal()) return true;
                    if (playLines === "4" && isFourCorner()) return true;
                }
            } else if (noOfAllLine != 0) {
                return total >= noOfAllLine;
            } else {
                console.log(row + " : "+col+" : "+diag);
                console.log(localStorage.getItem("noOfRows")+" : "+localStorage.getItem("noOfCols")+" : "+localStorage.getItem("noOfDiagonals"));
                if(row >= localStorage.getItem("noOfRows") && col >= localStorage.getItem("noOfCols") && diag >= localStorage.getItem("noOfDiagonals")){
                    return true;
                }
                else{
                    return false;
                }
            }

            return false;
        }

        function showWinOrLoss(win, bingoCode) {
            const mess = document.getElementById("badBingo_message");
            document.getElementById("removeCartela_btn").style.display = "none";

            if (win || !win) {
                $.ajax({
                    url: "bingoActivities.php",
                    type: "post",
                    data: { Purpose: "Get-Taken-Cartelas" },
                    success: function (result) {
                        const res = JSON.parse(result);
                        let betAmount = 0;
                        let noOfTakenCartelas = 0;
                        let p = 0;

                        for (let key in res) {
                            if (key === "betAmount") betAmount = parseInt(res[key]);
                            if (key === "noOfTakenCartelas") noOfTakenCartelas = parseInt(res[key]);
                            if (key === "percent") p = res[key];
                        }

                        const percent = parseFloat((100 - p) / 100).toFixed(2);
                        const totalReward = noOfTakenCartelas * betAmount * percent;

                        document.getElementById("totalReward_txt").value = totalReward;
                        mess.style.display = "block";
                        mess.innerText = ` === GOOD BINGO === ለአሸናፊው ${totalReward} ብር ይክፈሉ ፡፡ `;
                        mess.style.backgroundColor = "green";
                        mess.style.color = "white";
                        document.getElementById("goodBingo_btn").style.display = "block";
                        document.getElementById("rightMark_div").style.display = "block";
                        document.getElementById("wrongMark_div").style.display = "none";
                        document.getElementById("message_div").innerHTML = `Percent : ${p}`;

                        if (!storedWinnerCartelas.includes(bingoCode)) {
                            storedWinnerCartelas.push(bingoCode);
                            const total = document.getElementById("totalNoOfWinners_txt");
                            total.value = parseInt(total.value) + 1;

                            if (parseInt(total.value) >= 3) {
                                socket.send(JSON.stringify({ type: 'multipleGoodBingo' }));
                                document.getElementById("restartGame_btn").click();
                                exitMatch();
                            }
                        }

                        goodBingoId = bingoCode;
                        captureAndStoreImage();
                        localStorage.setItem("goodBingoIsFound", true);
                        localStorage.setItem("cartelaNo", bingoCode);
                    },
                });
            } else {
                mess.style.display = "block";
                mess.innerText = " ይህ ካርቴላ የተጠራው ቁጥር አልፎታል (የመዝጊያ ቁጥር የለውም) ፡ እባክዎ ቀጣዩን ቁጥር ይጠብቁ  ";
                mess.style.backgroundColor = "yellow";
                mess.style.color = "black";
                document.getElementById("removeCartela_btn").style.display = "block";
                document.getElementById("goodBingo_btn").style.display = "none";
                document.getElementById("rightMark_div").style.display = "none";
                document.getElementById("wrongMark_div").style.display = "block";
                captureAndStoreImage();
                localStorage.setItem("goodBingoIsFound", false);
                localStorage.setItem("cartelaNo", bingoCode);
            }
        }

        function displayErrorMessage(bingoCode) {
            const mess = document.getElementById("badBingo_message");
            mess.style.display = "block";
            mess.innerText = " የተሟላ መስመር ስላልሰራ ይህ ካርቴላ ተቀባይነት አላገኘም ";
            mess.style.backgroundColor = "red";
            mess.style.color = "white";
            document.getElementById("removeCartela_btn").style.display = "block";
            document.getElementById("goodBingo_btn").style.display = "none";
            document.getElementById("rightMark_div").style.display = "none";
            document.getElementById("wrongMark_div").style.display = "block";
            captureAndStoreImage();
            localStorage.setItem("goodBingoIsFound", false);
            localStorage.setItem("cartelaNo", bingoCode);
        }

        function discardCartela(cartelaId){
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Discard-Cartela",CartelaNo:cartelaId}),
                    success : function(result){
                    swal("Successfully ", "Cartela Discarded Successfully !! " , "info");
                    pauseGame();
                }
            });
        }
        function goodBingo(){
            var amount = document.getElementById("totalReward_txt").value;
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Good-Bingo",CartelaNo:goodBingoId,WinAmount: amount}),
                success : function(result){
                    var r = $.trim(result);
                    if(r === "success"){
                        goodBingoFound = true;
                        swal("Cartela Wins Successfully ", "Success Message", "success");
                        const val = "hello new boss page : "+goodBingoId;
                        //console.log(val);
                        localStorage.setItem('Winner-Cartela',val);
                        $.ajax({
                            url : "bingoActivities.php",
                            type: "post",
                            data: ({Purpose:"End-Game"}),
                            success : function(result){
                                var r = $.trim(result);
                                console.log("end-game stst : "+r)
                                if(r !== "success"){
                                    endGame();
                                    gamePaused = false;
                                }
                                 
                            }
                        });
                        
                        counter = 151;
                        enableBetElements();
                        document.getElementById("displayWinnerTime_div").style.display="none";
                        document.getElementById("displayWinnerTime_div").style.display="none";
                        document.getElementById("badBingo_message").style.display = "none";
                        document.getElementById("goodBingo_btn").style.display = "none";
                        document.getElementById("horseRedeem_div").style.display = "block";
                        loadUntakenCartelas();
                        document.getElementById('topRowCheckCartela_div').innerHTML = "";
                        const button = document.getElementById('exitBingo_btn');
                        button.click();
                        socket.send(JSON.stringify({ type: 'goodBingo' }));

                    }else{
                        swal("Error In Paying a good bingo ", result, "error");
                    }
                }
            });     
        }
        function exitGame(){
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Exit-Bingo"}),
                success : function(result){
                    const val = 0;
                    //window.location.href = "report.php?message=${val}";
                    localStorage.setItem('Winner-Cartela',val);
                    
                    counter = 151;
                    enableBetElements();
                    document.getElementById("displayWinnerTime_div").style.display="none";
                    document.getElementById("badBingo_message").style.display = "none";
                    document.getElementById("goodBingo_btn").style.display = "none";
                    document.getElementById("horseRedeem_div").style.display = "block";
                    loadUntakenCartelas(); 
                }
            });
        }

        function captureAndStoreImage() {
            html2canvas(document.querySelector("#snipThis_div")).then(canvas => {
                const imageDataURL = canvas.toDataURL("image/png");
                localStorage.setItem('storedImage', imageDataURL);
                fetch('bingoMobileActivities.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        Purpose: "Save-Image",  // add this if you want to send a purpose flag
                        image: imageDataURL 
                    })
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Image saved:', data);
                })
                .catch(err => {
                    console.error('Error saving image:', err);
                });
            });
        }

        function saveNewCartela(){
            var errorM = document.getElementById("error_p");
            var cartNo = document.getElementById("newCartelaNo_txt").value;
            if(cartNo =="" || cartNo == 0){
                errorM.style.display = "block"; errorM.style.backgroundColor = "red"; errorM.style.color = "white";
                errorM.innerText = "Cartela Number is Required";
                document.getElementById("newCartelaNo_txt").style.backgroundColor="red";
            }
            else{
                document.getElementById("newCartelaNo_txt").style.backgroundColor="white";
                swal({
                  title: "Are you sure to SAVE this Cartela ??",
                  text: "If you say yes, This Cartela Will be added to the system.",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                })
                .then((sureToAdd) => {
                  if (sureToAdd) {
                    var bingos = new Array();
                    var tableValue;
                    var table = document.getElementById("newCartela_table");
                    for(var row=0;row<5;row++){
                        var columnData = "";// a variable to hold the whole values in a single column
                        for(col=1;col<=5;col++){
                            tableValue = table.rows[col].cells.item(row).innerText;
                            if(tableValue != "Free") tableValue = parseInt(tableValue);
                            if(tableValue < 10 ) tableValue = "0"+tableValue;
                            columnData =columnData+''+tableValue;
                        }
                        bingos[row] = columnData;
                    }
                    $.ajax({
                        url : "bingoActivities.php",
                        type: "post",
                        data: ({Purpose:"Add-Cartela",Cartela: bingos,CartelaNo:cartNo}),
                        success : function(result){
                            var r = $.trim(result);
                            if(r === "success"){
                                errorM.style.display = "block"; errorM.style.backgroundColor = "green"; errorM.style.color = "white";
                                errorM.innerText = "Cartela Added Successfully";
                                const cells = table.querySelectorAll('td');
                                cells.forEach(cell => { cell.style.backgroundColor = "white"; cell.style.color = "black"; cell.innerText = ""});
                                table.rows[3].cells.item(2).innerText = "Free";
                                loadUntakenCartelas();
                                showDetail();
                            }
                            else{
                                errorM.style.display = "block"; errorM.style.backgroundColor = "red"; errorM.style.color = "white";
                                errorM.innerText = "Error To Add the cartela : "+result;
                            }
                        }
                    });
                  }
                });
            }
        }
        function clearAddMessage(){
            var errorM = document.getElementById("error_p");
            errorM.style.display = "none";
        }
        function loadCartelaToUpdate(){
            var cartelaId = document.getElementById("cartelaNo_txt").value;

            if(isNaN(cartelaId) || cartelaId == ""){
                var errorM = document.getElementById("error_p");
                errorM.style.display = "block";
                errorM.style.backgroundColor = "red"; errorM.style.color = "white";
                errorM.innerText = "Cartela Number is not correct";
                //console.log("carte "+cartelaId);
            }
            else{
                clearAddMessage();
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Load-To-Update",Cartela: cartelaId}),
                    success : function(result){
                        document.getElementById("cartelaDetail_div").innerHTML = "";
                        document.getElementById("cartelaDetail_div").innerHTML = result;
                    }
                });
            }
        }
        function updateCartela(cartelaId){
            var errorM = document.getElementById("error_p");
            swal({
              title: "Are you sure to UPDATE this Cartela ??",
              text: "If you say yes, This Cartela Will be Updated to the system.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((sureToAdd) => {
              if (sureToAdd) {
                var bingos = new Array();
                var tableValue;
                var table = document.getElementById("updateTable_tbl");
                for(var row=0;row<5;row++){
                    var columnData = "";// a variable to hold the whole values in a single column
                    for(col=1;col<=5;col++){
                        tableValue = table.rows[col].cells.item(row).innerText;
                        if(tableValue != "Free") tableValue = parseInt(tableValue);
                        if(tableValue < 10 ) tableValue = "0"+tableValue;
                        columnData =columnData+''+tableValue;
                    }
                    bingos[row] = columnData;
                }
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Update-Cartela",CartelaId: cartelaId,Cartela: bingos}),
                    success : function(result){
                        var r = $.trim(result);
                        if(r === "success"){
                            errorM.style.display = "block"; errorM.style.backgroundColor = "green"; errorM.style.color = "white";
                            errorM.innerText = "Cartela Added Successfully";
                            const cells = table.querySelectorAll('td');
                            cells.forEach(cell => { cell.style.backgroundColor = "white"; cell.style.color = "black"; cell.innerText = ""});
                            table.rows[3].cells.item(2).innerText = "Free";
                            loadUntakenCartelas();
                        }
                        else{
                            errorM.style.display = "block"; errorM.style.backgroundColor = "red"; errorM.style.color = "white";
                            errorM.innerText = "Error To Add the cartela : "+result;
                        }
                    }
                });
              }
            });
        }
        function deleteCartela(cartelaId){
            var errorM = document.getElementById("error_p");
            swal({
              title: "Are you sure to Delete this Cartela ?? \t\t Caretla Number : "+cartelaId,
              text: "If you say yes, This Cartela Will be Deleted from the system.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((sureToAdd) => {
              if (sureToAdd) {
                $.ajax({
                    url : "bingoActivities.php",
                    type: "post",
                    data: ({Purpose:"Delete-Cartela",CartelaId: cartelaId}),
                    success : function(result){
                        var r = $.trim(result);
                        if(r === "success"){
                            errorM.style.display = "block"; errorM.style.backgroundColor = "green"; errorM.style.color = "white";
                            errorM.innerText = "Cartela Added Successfully";
                            
                            loadUntakenCartelas();
                        }
                        else{
                            errorM.style.display = "block"; errorM.style.backgroundColor = "red"; errorM.style.color = "white";
                            errorM.innerText = "Error To Add the cartela : "+result;
                        }
                    }
                });
              }
            });
        }
        function checkPlays(){
            const allLinePlay = document.getElementById("noOfPlays_txt").value;
            const rows = document.getElementById("selectNoOfRows_option").value;
            const cols = document.getElementById("selectNoOfCols_option").value;
            const diags = document.getElementById("selectNoOfDiagonals_option").value;

            localStorage.setItem("linesSelected","0");
            //alert("Game Type : "+colorChanged1 + " : "+colorChanged2);
            if(rows == 0 && cols == 0 && diags == 0 && allLinePlay ==0 && !colorChanged1 && !colorChanged2 && !colorChanged3 && !colorChanged4 && !colorChanged5 && !colorChanged6){
                swal("የጨዋታ ዓይነት አልተመረጠም","እባክዎ የጨዋታውን አይነት ይምረጡ ....... ","error");
                return 0;
            }else if(colorChanged1){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","በ");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            } else if(colorChanged2){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","ሀ");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            } else if(colorChanged3){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","L");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            } else if(colorChanged4){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","N");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            }
            else if(colorChanged5){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","0");
                localStorage.setItem("AnyNumbers",userInput);
                return 1;
            }
            else if(colorChanged6){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","4");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            }
            else if(allLinePlay == 0 ){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',rows );
                localStorage.setItem('noOfCols',cols );
                localStorage.setItem('noOfDiagonals', diags);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","0");
                localStorage.setItem("AnyNumbers",0);
                //console.log("BEfore Start : "+localStorage.getItem("noOfCols") + " : "+localStorage.getItem("noOfRows")+ " : "+localStorage.getItem("noOfDiagonals"));
                return 1;
            } else{
                localStorage.setItem("allLinePlay", true);
                localStorage.setItem("noOfAllLines",allLinePlay);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("linesSelected","0");
                localStorage.setItem("AnyNumbers",0);

                return 1;
            }
        }
        function checkNewPlays(){
            const allLinePlay = document.getElementById("noOfPlays_txt1").value;
            const rows = document.getElementById("selectNoOfRows_option1").value;
            const cols = document.getElementById("selectNoOfCols_option1").value;
            const diags = document.getElementById("selectNoOfDiagonals_option1").value;
            localStorage.setItem("linesSelected","0");
            if(rows == 0 && cols == 0 && diags == 0 && allLinePlay ==0){
                swal("የጨዋታ ዓይነት አልተመረጠም","እባክዎ የጨዋታውን አይነት ይምረጡ ....... ","error");
                return 0;
            }
            else if(allLinePlay == 0 ){
                localStorage.setItem('allLinePlay', false);
                localStorage.setItem('noOfRows',rows );
                localStorage.setItem('noOfCols',cols );
                localStorage.setItem('noOfDiagonals', diags);
                localStorage.setItem("noOfAllLines",0);
                localStorage.setItem("linesSelected","0");
                localStorage.setItem("AnyNumbers",0);
                
                return 1;
            }else{
                localStorage.setItem("allLinePlay", true);
                localStorage.setItem("noOfAllLines",allLinePlay);
                localStorage.setItem('noOfRows',0 );
                localStorage.setItem('noOfCols',0 );
                localStorage.setItem('noOfDiagonals', 0);
                localStorage.setItem("linesSelected","0");
                localStorage.setItem("AnyNumbers",0);
                return 1;
            }
        }
        function startBetting(){
            const betAmount = document.getElementById("betAmount_txt").value;
            const percent = document.getElementById("percent_txt").value;
            const ret = checkPlays();
            if(ret == 1 ){
                if(betAmount == "" || betAmount == 0 || percent ==""){
                    swal("Bet Amount Error","Bet Amount or Percent Can't Be null. ","error");
                }
                else{
                    /*console.log("all line play : "+localStorage.getItem("allLinePlay"));
                    console.log("no of all lines : "+localStorage.getItem("noOfAllLines"));
                    console.log("No of any nymbers"+localStorage.getItem("AnyNumbers"));*/
                    swal({
                        title: "Are you sure to Start Playing With \t\t "+betAmount+" Birr ??",
                        text: "",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                    .then((sureToStart) => {
                      if (sureToStart) {
                        const c = getTypeOfPlayMessage();
                        getPhoneNos();
                        $.ajax({
                            url : "bingoActivities.php",
                            type: "post",
                            data: ({Purpose:"Add-Bet-Amount",BetAmount: betAmount,Percent:percent,PlayType:c}),
                            success : function(result){
                                console.log(result);
                                disableBetElements();
                                document.getElementById("addPlayTime_div").style.display = "block";
                                showDetail();
                                selectedCartelas = new Array();;
                                localStorage.setItem("bingoSelectedData",JSON.stringify(selectedCartelas));
                                socket.send(JSON.stringify({ type: 'startBetting' }));
                            }
                        });
                      }
                    });  
                }
            }
        }
        function restartBetting(){
            const ret = checkNewPlays();
            if(ret == 1){
                swal({
                    title: "Are you sure to Restart the game with the selected playing types ??",
                    text: "",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((sureToStart) => {
                    disableBetElements();
                    document.getElementById("goodBingo_btn").style.display = "none";
                    document.getElementById("badBingo_message").style.display = "none";
                    document.getElementById("horseRedeem_div").style.display = "none";
                    localStorage.setItem('goodBingoIsFound', false);
                    localStorage.setItem('cartelaNo', "");
                    localStorage.removeItem("storedImage");
                    localStorage.setItem('storedImage', "");
                    $.ajax({
                        url : "bingoActivities.php",
                        type: "post",
                        data: ({Purpose:"Get-Taken-Cartelas"}),
                        success : function(result){
                            showDetail();
                            restartFullGame();
                        }
                    });
                });  
            }
        }
        function getTypeOfPlayMessage(){
            var row,col,diag,type = "";
            let linesValue = localStorage.getItem("linesSelected");
            let anyNumbers = localStorage.getItem("AnyNumbers");
            //console.log("Items : "+linesValue);
            if(anyNumbers != 0){
                return "የጨዋታ ዓይነት  ፡ ANY "+anyNumbers+" መስመር";
            }
            else if(linesValue != "0" && linesValue != null){
                if(linesValue=="4" || linesValue == 4){
                    return "የጨዋታ ዓይነት  ፡ 4 Corners";
                }
                else {
                    return "የጨዋታ ዓይነት  ፡ "+linesValue;
                }
            }
            else if(localStorage.getItem("noOfAllLines") == 0 ){
                col = localStorage.getItem("noOfCols");
                if(col != 0 )
                    type = col+" ቋሚ ፡ ".concat(type);
                row = localStorage.getItem("noOfRows");
                if(row != 0 )
                    type = type.concat(row+" አግዳሚ ፡ ");
                diag = localStorage.getItem("noOfDiagonals");
                if(diag != 0 )
                    type = type.concat(diag+" ዲያጎናል");
                return type;
            }
            else{
                return "በማንኛውም "+localStorage.getItem("noOfAllLines")+" መስመር  "
            }
        }
        function showDetail(){
            var percent,p, betAmount;
            var timerDiv = document.getElementById('timer_div');
            var playTypeDiv = document.getElementById("type_div");
            var gameCode = document.getElementById('gameCode_div');
            var timer2Div = document.getElementById('timer2_div');
            var gameCode2 = document.getElementById('gameCode2_div');
            var playTypeDiv2 = document.getElementById("type2_div");
            var noofcs;
            $.ajax({
                url : "bingoActivities.php",
                type: "post",
                data: ({Purpose:"Get-Taken-Cartelas"}),
                success : function(result){
                    var res = JSON.parse(result);
                    $.each(res,function(key,val){
                        switch(key){
                            case "betAmount":
                                betAmount = parseInt(val); break;
                            case "noOfTakenCartelas": 
                                
                                noofcs = noOfTakenCartelas = parseInt(val);
                                timerDiv.innerHTML = "መጫወቻ : "+betAmount+" ብር <br> የተያዙ ካርቴላዎች :   "+val;
                                const c = getTypeOfPlayMessage();
                                playTypeDiv.innerHTML = c ;
                                gameCode.innerHTML = (parseInt(val)*betAmount*percent) +" ብር"; 
                                timer2Div.innerHTML = "መጫወቻ : "+betAmount+" ብር <br> የተያዙ ካርቴላዎች :   "+val;
                                playTypeDiv2.innerHTML = c;
                                
                                break;
                            case "percent":
                                //console.log("Percent total : "+val);
                                p = val;
                                percent = parseFloat(parseInt(100-val)/100).toFixed(2);
                                //console.log(percent + " : "+betAmount+" : "+noofcs);
                                gameCode.innerHTML = (noofcs*betAmount*percent) +" ብር"; 
                                gameCode2.innerHTML = (noofcs*betAmount*percent)+" ብር";
                                document.getElementById("message_div").innerHTML = "Percent : "+p;
                            default:
                        }
                    });
                }
            });
        }
        function deleteCashier(id,name,diff){
            swal({
              title: "Are You Sure To Delete Cashier "+name+" From The System ?",
              text: "Accept "+diff+"Birr, thenBe sure before click procced.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((sure) => {
              if (sure) {
              var success = document.getElementById("success_td");
                $.ajax({
                    url: "../AdminPage/activities.php",
                    type:"post",
                    data:({Purpose:"Delete-Cashier",I:id,Diff:diff}),
                    success: function(result){
                        var r = $.trim(result);
                         success.innerHTML = r;
                        if(r === "not admin"){
                            window.open("../","_self");
                        }
                        else if(r === "success"){
                            success.innerHTML = "Cashier Deleted Successfully.";
                            loadCashierData();
                        }
                        else{
                            success.innerHTML="Error to Delete Cashier. "+result;
                        }
                    }
                });
              }
            });
        }
        function changePassword(){
            var cp = document.getElementById("currentPassword_txt").value;
            var np = document.getElementById("newPassword_txt").value;
            var confp = document.getElementById("confirmPassword_txt").value;
            var s = document.getElementById("pChangeSuccess_td");
            if(cp.length<6 || np.length<6 || confp.length <6){
                s.style.background = "red";
                s.innerText = "Password Error";
            }
            else if(np != confp){
                s.style.background = "red";
                s.innerText = "New Password Mis-match";
            }
            else if(np == cp){
                s.style.background = "gray";
                s.innerText = "Your New Password is The Same As Your Current Password.";
            }
            else{
                $.ajax({
                    url: "activities.php",
                    type:"post",
                    data:({Purpose:"Change-Password",CP:cp,NP:np}),
                    success: function(result){
                        s.style.background = "green";
                        s.innerText = result;
                    }
                });
            }
        }
        function changeColor(id){
            const backgroundColor = id.style.backgroundColor;
            const value = id.value;
            var tempoTotal = totalCartelasForCurrentGame;
            document.getElementById("cartelaSavedMessage_div").style.display = "none";
            if(backgroundColor == "green"){
                id.style.backgroundColor = "white";
                id.style.color = "cyan";
                selectedCartelas = selectedCartelas.filter(num => num !== value);

            }
            else{
                id.style.backgroundColor = "green";
                id.style.color = "black";               
                selectedCartelas.push(value);
                const p = document.getElementById("customerPhone_txt");
                if(p.value == "" || p.value == "09"){
                    p.value = "09";
                    p.focus();
                }
                
            }
            tempoTotal = parseInt(tempoTotal)+parseInt(selectedCartelas.length);
            document.getElementById("noOfTotalTakenCartelas_h5").innerText = "የተመረጡ ካርቴላዎች ብዛት ➡️> "+selectedCartelas.length+"\n ጠቅላላ የተያዙ እና የተመረጡ ካርቴላዎች ብዛት ➡️> "+tempoTotal;
            localStorage.setItem("bingoSelectedData",JSON.stringify(selectedCartelas));

            selectedCartelas.length > 0 ? document.getElementById("saveMyBingosFromTemporary_btn2").style.display = "block" : document.getElementById("saveMyBingosFromTemporary_btn2").style.display = "none";
        }
        function changeAudio(){
            var value = document.getElementById("genederSelection_option").value;
            localStorage.setItem("Gender",value);
            //console.log(localStorage.getItem("Gender"));
        }
        function generateReport(){
            var success = document.getElementById("success_td");

            if (success) {
                let timeLeft = 60; // 1-minute countdown

                function updateTimer() {
                    success.innerHTML = `Working on report... ⏳ ${timeLeft} seconds remaining`;
                    success.style.backgroundColor = "gold";
                    timeLeft--;

                    if (timeLeft < 0) {
                        clearInterval(timerInterval);
                        success.innerHTML = "Report generation restarted...";
                        setTimeout(startTimer, 1000); // Restart after 1 second
                    }
                }

                function startTimer() {
                    timeLeft = 60; // Reset timer
                    timerInterval = setInterval(updateTimer, 1000);
                    
                    $.ajax({
                        url: "../AdminPage/activities.php",
                        type: "post",
                        data: { Purpose: "Submit-Report" },
                        success: function(result) {
                            clearInterval(timerInterval); // Stop timer
                            success.innerHTML = `✅ Report Generated Successfully!<br>${result}`;
                            success.style.backgroundColor = "lightgreen";
                        },
                        error: function() {
                            success.innerHTML = "❌ Error generating report.";
                            success.style.backgroundColor = "red";
                        }
                    });
                }

                startTimer();
            }
        }
        function shuffleTheNumbers(){
            localStorage.setItem("Shuffle",true);
        }
    </script>

  </head>

    <body>
        <center>
            <div class="" id="expIndicator_div" style="margin:0px;background: #ff3e1d; color: white; font-weight: bold; text-align: center; "></div>
            <div style="margin-bottom: -35px; margin-top: -10px;">
            <?php 
                $query = mysqli_query($conn,"select PremiumCode from super");
                $row = mysqli_fetch_array($query);
                  
                if($row['PremiumCode'] != ""){
                    ?> <p style="color:green;" class="shakePremium">&#9733;&#9733;&#9733;&#9733;&#9733; </p> <?php
                }
                else{
                    ?> <p style="color:green;" class="shakePremium">&#9733;&#9733;&#9733;  </p><?php
                }
            ?>
            </div>
        </center>
        <nav class="navbar navbar-example navbar-expand-lg bg-light">
          <div class="container-fluid">
            <div class="navbar-collapse collapse show row" id="navbar-ex-3" style="">
                <div class="navbar-nav me-auto" style="justify-content: center; align-items:center;">
                    <div class="col-md-5">
                    <!-- <a class="nav-item nav-link" href="javascript:void(0)" id="horseLink_a" onclick="changeGame(0)"><img src="../h.jpg" alt="Horse" style="width:60%; aspect-ratio: 4/3; object-fit: contain; mix-blend-mode:color-burn;"/></a>
                    <a class="nav-item nav-link" id="dogLink_a" href="javascript:void(0)" style="background: gold;"  onclick="changeGame(1)">Dog</a>
                    <center style="margin-left: 25px;"> -->
                    <button class="btn btn-outline-warning rounded-pill" type="button" onclick="loadCashierDetail()" data-bs-toggle="modal" data-bs-target="#cashierOptionModal"><i class="bx bx-dollar me-2"></i>Cashier</button>
                
                    <button class="btn btn-outline-success  rounded-pill" type="button" data-bs-toggle="modal" onclick="clearAddMessage()" data-bs-target="#addNewCartelaModal"><i class="bx bx-table me-2"></i>Cartela</button>

                    <?php
                        $n = time();
                        $query = "SELECT * FROM exp";
                        $result = mysqli_query($conn, $query);

                        if (!$result) {
                            error_log(mysqli_error($conn));
                            die("Database query failed.");
                        }

                        $r = mysqli_fetch_array($result);
                        $t = $r['T'];
                        $e = $r['E'];
                        $a = $r['A'];

                        $dateE = new DateTime('@' . $e);
                        $dateN = new DateTime('@' . $n);
                        $interval = $dateE->diff($dateN);

                        $h3 = $interval->days;
                        $h = $interval->h;
                        $i = $interval->i;
                        $s = $interval->s;

                        if ($a != 0) {
                            if ($n < $t) {
                                $d = date('d/m/Y', $t);
                                echo "<script>alert('Your System Time is not correct. Set it after --> $d'); window.open('../', '_self');</script>";
                            } else {
                                //echo $h3;
                                if ($h3 <= 0) {
                                    $stmt = $conn->prepare("UPDATE exp SET T = ?");
                                    $stmt->bind_param("i", $n);
                                    $stmt->execute();
                                    echo "<script>alert('YOUR SYSTEM IS ALREADY EXPIRED. CONTACT US USING 09 76 03 27 77');window.open('../', '_self');</script>";
                                } elseif ($h3 <= 7) {
                                    $stmt = $conn->prepare("UPDATE exp SET T = ?");
                                    $stmt->bind_param("i", $n);
                                    $stmt->execute();
                                    echo "<script>
                                        let h3 = " . json_encode($h3) . ";
                                        let h = " . json_encode($h) . ";
                                        let i = " . json_encode($i) . ";
                                        let s = " . json_encode($s) . ";
                                        document.getElementById('expIndicator_div').innerHTML = `Audit Date Is Approaching. Your System Expires In => ${h3} Days - ${h} Hours - ${i} Minutes And ${s} Seconds. Contact us using 09 76 03 27 77`;
                                        document.getElementById('expIndicator_div').style.display = 'block';
                                    </script>";
                                } else {
                                    echo "<script>
                                        let h3 = " . json_encode($h3) . ";
                                        let h = " . json_encode($h) . ";
                                        let i = " . json_encode($i) . ";
                                        let s = " . json_encode($s) . ";
                                        document.getElementById('expIndicator_div').innerHTML = `Audit Date Is Approaching. Your System Expires In => ${h3} Days - ${h} Hours - ${i} Minutes And ${s} Seconds. Contact us using 09 76 03 27 77`;
                                        document.getElementById('expIndicator_div').style.display = 'block';
                                    </script>";
                                    $stmt = $conn->prepare("UPDATE exp SET T = ?");
                                    $stmt->bind_param("i", $n);
                                    $stmt->execute();
                                    //echo "<script>document.getElementById('expIndicator_div').style.display = 'none';</script>";
                                }
                            }
                        }

                        else{
                           echo "<script> document.getElementById('expIndicator_div').innerHTML='';document.getElementById('expIndicator_div').style.display='none';</script>";
                        }
                        if(isset($_SESSION['Admin'])){
                            ?>
                            <button class="btn btn-outline-danger  rounded-pill" type="button" data-bs-toggle="modal" data-bs-target="#showAuditModal" onclick="loadCashierData()"><i class="bx bx-pie-chart me-2"></i>Audit</button> 
                            <button class="btn btn-outline-danger  rounded-pill" type="button" id="restartGame_btn" data-bs-toggle="modal" data-bs-target="#showRestartTheGameModal" onclick="" style="display: none;"><i class="bx bx-pie-chart me-2"></i>Restart the</button>
                            <?php
                        }
                    ?>
                    <button class="btn btn-outline-info rounded-pill" type="button" data-bs-toggle="modal" data-bs-target="#showSettingModal"> <i class="bx bx-cog me-2"></i>Settings</button>
                    <div style="display: flex;">
                        <select id="genederSelection_option" style="width:30%;" class="form-select d-flex"  onclick="changeAudio()">
                            <option value="Male">Male</option><option value="Female">Female</option>
                        </select>
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio4" value="7.0"  autocomplete="off">
                            <label class="btn btn-outline-primary" for="btnradio4">Super Slow</label>
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio1" value="5.0"  autocomplete="off">
                            <label class="btn btn-outline-primary" for="btnradio1">Slow</label>
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio2" checked="" value="3.5" autocomplete="off">
                            <label class="btn btn-outline-primary" for="btnradio2">Normal</label>
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio3" value="2.0" autocomplete="off">
                            <label class="btn btn-outline-primary" for="btnradio3">Fast</label>
                        </div>
                    </div>
                    
                    </div> 

                    <div class="col-md" style="border: 1px solid black;" id="selectBetAmount_div">
                        <div id="status_div">Connecting to server...</div>
                        <input type="number" class="btn btn-input" onclick="changeText(this)" min="0" onfocus="changeText(this)" oninput="checkEvent(this)" id="betAmount_txt" value="10" style="width: 15%; text-align: center; border: 1px solid black; color: black; "/>
                        <button class="bet-btns btn btn-outline-primary" type="button" onclick="addBetAmount(20)">20</button>
                        <button class="bet-btns btn btn-outline-warning" type="button" onclick="addBetAmount(30)">30</button>
                        <button class="bet-btns btn btn-outline-danger" type="button" onclick="addBetAmount(40)">40</button>
                        <button class="bet-btns btn btn-outline-success" type="button" onclick="addBetAmount(50)">50</button>
                        <button class="bet-btns btn btn-outline-warning" type="button" onclick="addBetAmount(100)">100</button>
                        <button class="bet-btns btn btn-outline-danger" type="button" onclick="addBetAmount(200)">200</button>
                        <button class="bet-btns btn btn-outline-primary" type="button" onclick="addBetAmount(500)">500</button>
                        <script>
                            // Select all radio buttons in the group
                            const radioButtons = document.querySelectorAll('input[name="btnradio"]');

                            // Attach the event listener to each radio button
                            radioButtons.forEach((radio) => {
                                radio.addEventListener('change', function() {
                                  getSelectedValue();
                                });
                            });

                            // Function to get the value of the selected radio button
                            function getSelectedValue() {
                                const selectedRadioButton = document.querySelector('input[name="btnradio"]:checked');
                                if (selectedRadioButton) {
                                    //console.log("Selected value: " + selectedRadioButton.id + " : "+selectedRadioButton.value);
                                    const speed = selectedRadioButton.value;
                                    localStorage.setItem("soundSpeed",speed);
                                    const msg = JSON.stringify({
                                        type: 'gameSpeed',
                                        GameSpeed: speed
                                    });
                                    if (socket.readyState === WebSocket.OPEN) {
                                        socket.send(msg);
                                    } else {
                                        messageQueue.push(msg);
                                    }
                                }
                            }
                        </script>

                    </div>
                    <a class="nav-item nav-link" href="../">LOG OUT</a> 
                </div>
                   
            </div>
          </div>
        </nav>
        <div class="row mb-4">
            <!-- Basic Alerts -->
            <hr>
            <div class="col-md mb-6 mb-md-0">
                <div  id="addPlayTime_div" class="row">
                    <div class="row">
                        <div  class="col-md-9">
                            <style>
                                #untakenBingos_li {
                                    display: grid;               /* Use grid layout */
                                    grid-template-columns: repeat(15, 1fr); /* Create 15 equal-width columns */
                                    gap: 2px;                    /* Space between grid items */
                                    width: 100%;                  /* Full width */
                                    padding: 0px;
                                    grid-auto-rows: minmax(20px, auto); /* Set row height to be flexible, minimum 50px */
                                }
                            </style>
                            <div id="untakenBingos_li" ></div>
                            <div class="row">
                                <div class="mb-3 col-md-4">
                                    <label for="customerPhone_txt" class="form-label">Phones In Your System</label>
                                    <input class="form-control" list="datalistOptions" id="customerPhone_txt" placeholder="Type to search...">
                                    <datalist id="datalistOptions">    </datalist>
                                </div>
                                <div class="col-md-4">
                                    <label for="saveMyBingosFromTemporary_btn2" class="form-label">Click Me to Save</label>
                                    <button class="form-control btn-success" style="display: none;" id="saveMyBingosFromTemporary_btn2" onclick="saveMyBingosWithArray()">Save My Bingos</button>
                                </div>
                                <div class="col-md-4">
                                    <label for="removeAllSelections_btn" class="form-label">Click Me to Save</label>
                                    <button class="form-control btn-danger" id="removeAllSelections_btn" onclick="removeSelection(this,0)">Remove All Selections</button>
                                </div>
                            </div>
                            
                            <div id="takenBingos_li" ></div>
                            <hr><center>
                            <h3 class="card-title text-primary center" id="noOfTotalTakenCartelas_h5"></h3>
                            <div id="bingos_div">
                                        
                                    <div class="field" id="cartelaSavedMessage_div" style="background-color: yellow; display: none;">
                                        <h3> Cartela's Saved Successfully. </h3>
                                    </div>
                                
                            </div> </center>
                            <button class="form-control btn-outline-warning" style="margin-top: 0;" id="startGameButton" onclick="startGame()">START BINGO</button>
                        </div>
                        <div  class="col-md-3">
                            
                            <div class="col-md">
                                <div class="message_div" id="message_div">
                                    PLAY TIME
                                </div>
                                <div class="col-md card hostTimer_div"  id="type_div" style="background: black;">
                                    Bingo playing time
                                </div>
                                <div class="col-md card hostTimer_div"  id="timer_div" style="background: black;">
                                
                                </div>
                                <div class="gameCode_div hostTimer_div card" id="gameCode_div">
                                   
                                </div><br><center>
                                <button class="btn rounded-pill btn-primary" style="display:block; font-size: 18px;" onclick="shuffleTheNumbers()">Shuffle / ሸክሽክ </button></center>
                                <div class="center-div">AB-STAR <br> GAMES</div>
                            </div>                            
                        </div> 
                    </div>
                </div>

                <div  id="displayWinnerTime_div">
                    <div class="row">
                        <div id="bingos_div" class="col-md-8">
                            <button class="form-control btn-outline-danger" style="margin-top: 10em;" id="pauseGameButton" onclick="pauseGame()" data-bs-toggle="modal" data-bs-target="#checkCartelaModal">STOP BINGO</button>
                            <style type="text/css">
                                #winnerShow_tbl td{
                                    border-radius: 50%;
                                    font-style: italic;
                                    font-family: monospace;
                                    background-color: white;
                                    font-size: 100%;

                                    font-weight: bold;
                                    border: none;
                                    border-bottom: 3px solid black;
                                    border-right: 3px solid red;
                                    border-left: 3px solid gold;
                                    border-bottom-right-radius: 50%;
                                }

                                #winnerShow_tbl th{
                                    border-radius: 50%;
                                    font-style: italic;
                                    font-family: monospace;
                                    background-color: white;
                                    font-size: 25px;
                                    border: none;
                                    background-color: black;
                                    color: gold;
                                }
                            </style>
                            <table id="winnerShow_tbl" class="table table-bordered" style="row-height:2px;text-align: center; width: 100%; width: 80%;">
                                <tr class="td"><th>B</th><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td></tr>
                                <tr class="td"><th>I</th><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td><td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td></tr>
                                <tr class="td"><th>N</th><td>31</td><td>32</td><td>33</td><td>34</td><td>35</td><td>36</td><td>37</td><td>38</td><td>39</td><td>40</td><td>41</td><td>42</td><td>43</td><td>44</td><td>45</td></tr>
                                <tr class="td"><th>G</th><td>46</td><td>47</td><td>48</td><td>49</td><td>50</td><td>51</td><td>52</td><td>53</td><td>54</td><td>55</td><td>56</td><td>57</td><td>58</td><td>59</td><td>60</td></tr>
                                <tr class="td"><th>O</th><td>61</td><td>62</td><td>63</td><td>64</td><td>65</td><td>66</td><td>67</td><td>68</td><td>69</td><td>70</td><td>71</td><td>72</td><td>73</td><td>74</td><td>75</td> </tr>                   
                            </table>
                        </div>
                    <div class="col-md-4">
                        <div class="message_div" id="message_div">
                            PLAY TIME
                        </div>
                        <div class="col-md card hostTimer_div"  id="type2_div" style="background: black;">
                            
                        </div>
                        <div class="col-md card hostTimer_div"  id="timer2_div" style="background: black;">
                        
                        </div>
                        <div class="gameCode_div hostTimer_div card" id="gameCode2_div">
                           
                        </div>
                        <div class="col-6 col-md-12 d-flex justify-content-center">
                              <div id="winnerHost_div" class="winnerHostCircle winnerHostCircleMainPage position-relative">
                                <!-- Badge inside the top of the circle -->
                                <span class="badge badge-inside bg-info text-dark" id="winnerBadge_span">B</span>

                                <!-- Winner number centered in the circle -->
                                <span class="winnerNumber_span" id="winnerNumber_span">00</span>
                              </div>
                        </div>
                        <div class="col-6 col-md-12 d-flex justify-content-center">
                          <div id="lastThreeWinners" class="lastWinnersGrid winnerHostCircleMainPage">
                            <!-- JS will populate this with winner circles -->
                            78
                          </div>
                        </div>
                        <div class="center-div">AB-STAR <br> GAMES</div>
                    </div>
                    </div>
                </div>
                <div id="defaultMessage_div">
                    <style>
                        /* Style for the beveled box */
                        .beveled-box {
                            display: inline-flex;
                            justify-content: center;
                            align-items: center;
                            width: 150px; /* Adjust the width of the box */
                            height: 150px; /* Adjust the height of the box */
                            background-color: #f0f0f0;
                            border-radius: 15px; /* Bevel effect */
                            box-shadow: 4px 4px 15px rgba(0, 0, 0, 0.2), -4px -4px 15px rgba(255, 255, 255, 0.5);
                            transition: transform 0.3s ease, box-shadow 0.3s ease;
                            cursor: pointer;
                        }

                        /* Change on hover for a more interactive effect */
                        .beveled-box:hover {
                            transform: scale(1.05);
                            box-shadow: 6px 6px 20px rgba(0, 0, 0, 0.3), -6px -6px 20px rgba(255, 255, 255, 0.4);
                        }

                        /* Style for the clickable paragraph inside the box */
                        .clickable-paragraph {
                            font-family: 'sans-serif', monospace; /* Monospace font for blocky style */
                            font-size: 130px; /* Adjusted font size to fill the box */
                            color: blue;
                            margin: 0;
                            cursor: pointer;
                        }
                        .clickable-paragraph-any{
                            font-size: 80px;
                        }
                        .clickable-paragraph-fourCorners{
                            font-size: 25px;
                        }

                        /* Add class for rotating text */
                        .rotated {
                            transform: rotate(180deg); /* Rotate the letter upside down */
                        }
                    </style>
                    <table class="table table-striped table-bordered" style="align-items: center;">
                        <thead><th>ቋሚ</th><th>አግዳሚ</th><th>ዲያጎናል </th><th>በማንኛውም</th> <th> Percent </th></thead>
                        <tbody>
                            <tr>
                                <td>
                                    <select id="selectNoOfCols_option" class="form-select d-flex" onchange="changeNoOfRows(this)">
                                      <option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
                                      <option value="4">4</option><option value="5">5</option>
                                    </select>
                                </td>
                                <td><select id="selectNoOfRows_option" class="form-select d-flex" onchange="changeNoOfRows(this)">
                                      <option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
                                      <option value="4">4</option><option value="5">5</option>
                                    </select>
                                </td>
                                <td><select id="selectNoOfDiagonals_option" class="form-select d-flex" onchange="changeNoOfRows(this)">
                                      <option value="0">0</option><option value="1">1</option><option value="2">2</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" class="btn btn-input" onclick="changeText(this)" onfocus="changeText(this)" oninput="checkNoOfPlays(this)" id="noOfPlays_txt" value="2" min="0" max="12" style=" text-align: center; border: 1px solid black; color: black; " />
                                </td>

                                <td>
                                    <input type="number" class="btn btn-input" onclick="changePercent(this)" onfocus="changePercent(this)" oninput="changePercent(this)" id="percent_txt" value="20" min="0" max="100" style=" text-align: center; border: 1px solid blue; color: black; " />
                                </td>
                            </tr>
                            <tr> <td colspan="1"><center>
                                <!-- Beveled Box with Clickable Paragraph -->
                                <div class="beveled-box" id="downLetter_div">
                                    <p class="clickable-paragraph rotated" id="clickableParagraph1">
                                        U
                                    </p>
                                </div></center>
                            </td>
                            <td colspan="1"><center>
                                <div class="beveled-box" id="upLetter_div">
                                    <p class="clickable-paragraph" id="clickableParagraph2">
                                        U
                                    </p>
                                </div></center>
                            </td>
                            <td colspan="1"><center>
                                <div class="beveled-box" id="letterL_div">
                                    <p class="clickable-paragraph" id="clickableParagraph3">
                                        L
                                    </p>
                                </div></center>
                            </td>
                            <td colspan="1"><center>
                                <div class="beveled-box" id="letterN_div">
                                    <p class="clickable-paragraph" id="clickableParagraph4">
                                        N
                                    </p>
                                </div></center>
                            </td>
                            <td colspan="1"><center>
                                <div class="beveled-box" id="letterAnyNumber_div">
                                    <p class="clickable-paragraph clickable-paragraph-any" id="clickableParagraph5">
                                        ANY
                                    </p>
                                </div></center>
                            </td>
                            <td colspan="1"><center>
                                <div class="beveled-box" id="fourCorners_div">
                                    <p class="clickable-paragraph clickable-paragraph-fourCorners" id="clickableParagraph6">
                                        Four Corners
                                    </p>
                                </div></center>
                            </td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <center><button class="bet-btns btn btn-outline-danger" type="button" onclick="startBetting()">Start Betting</button></center>
                                </td>
                                <td id="anyNumberPlay_td" style="text-align:center;"></td>
                            </tr>
                            <script type="text/javascript">
                                function checkNoOfPlays(id){
                                    var text = id.value;
                                    if( text != 0 ){
                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        upLetter.style.backgroundColor = '#f0f0f0';
                                        colorChanged2 = false;
                                        downLetter.style.backgroundColor = '#f0f0f0';
                                        colorChanged1 = false;
                                        letterL.style.backgroundColor = '#f0f0f0';
                                        colorChanged3 = false;
                                        letterN.style.backgroundColor = '#f0f0f0';
                                        colorChanged4 = false;
                                        letterAny.style.backgroundColor = '#f0f0f0';
                                        colorChanged5 = false;
                                        fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                        colorChanged6 = false;
                                        anyNumberPlay.innerText = "";
                                    }
                                    if(text < 0 || text > 12 ){ id.value = "12"; }
                                }
                                function changeNoOfRows(id){
                                    if(id.value != 0 ){
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        upLetter.style.backgroundColor = '#f0f0f0';
                                        colorChanged2 = false;
                                        downLetter.style.backgroundColor = '#f0f0f0';
                                        colorChanged1 = false;
                                        letterL.style.backgroundColor = '#f0f0f0';
                                        colorChanged3 = false;
                                        letterN.style.backgroundColor = '#f0f0f0';
                                        colorChanged4 = false;
                                        letterAny.style.backgroundColor = '#f0f0f0';
                                        colorChanged5 = false;
                                        fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                        colorChanged6 = false;
                                        anyNumberPlay.innerText = "";
                                    }
                                }
                                function changePercent(id){

                                }
                            </script>
                            <script>
                                // Define flags to track the color change state
                                let colorChanged1 = false;
                                let colorChanged2 = false;
                                let colorChanged3 = false;
                                let colorChanged4 = false;
                                let colorChanged5 = false;
                                let colorChanged6 = false;
                                // Get references to the divs
                                let downLetter = document.getElementById("downLetter_div");
                                let upLetter = document.getElementById("upLetter_div");
                                let letterL = document.getElementById("letterL_div");
                                let letterN = document.getElementById("letterN_div");
                                let letterAny = document.getElementById("letterAnyNumber_div");
                                let anyNumberPlay = document.getElementById("anyNumberPlay_td");
                                let fourCornersPlay = document.getElementById("fourCorners_div");
                                // Adding click event to the down letter box
                                downLetter.addEventListener("click", function() {
                                    // Toggle the color change state for the down letter box
                                    if (colorChanged1) {
                                        // Reset to the original color
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged1 = false;
                                    } else {
                                        // Change to a new color
                                        this.style.backgroundColor = 'lightgreen'; 
                                        colorChanged1 = true;

                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        anyNumberPlay.innerText = "";
                                    }
                                    // Reset the other box's color
                                    upLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged2 = false;
                                    letterL.style.backgroundColor = '#f0f0f0';
                                    colorChanged3 = false;
                                    letterN.style.backgroundColor = '#f0f0f0';  // Reset N box color
                                    colorChanged4 = false;
                                    letterAny.style.backgroundColor = '#f0f0f0';
                                    colorChanged5 = false;
                                    fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                    colorChanged6 = false;
                                });

                                // Adding click event to the up letter box
                                upLetter.addEventListener("click", function() {
                                    // Toggle the color change state for the up letter box
                                    if (colorChanged2) {
                                        // Reset to the original color
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged2 = false;
                                    } else {
                                        // Change to a new color
                                        this.style.backgroundColor = 'lightgreen'; 
                                        colorChanged2 = true;
                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        anyNumberPlay.innerText = "";
                                    }
                                    // Reset the other box's color
                                    downLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged1 = false;
                                    letterL.style.backgroundColor = '#f0f0f0';
                                    colorChanged3 = false;
                                    letterN.style.backgroundColor = '#f0f0f0';  // Reset N box color
                                    colorChanged4 = false;
                                    letterAny.style.backgroundColor = '#f0f0f0';
                                    colorChanged5 = false;
                                    fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                    colorChanged6 = false;
                                });
                                // Adding click event to the middle letter box (A box)
                                letterL.addEventListener("click", function() {
                                    if (colorChanged3) {
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged3 = false;
                                    } else {
                                        this.style.backgroundColor = 'lightgreen'; 
                                        colorChanged3 = true;
                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        anyNumberPlay.innerText = "";
                                    }
                                    downLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged1 = false;
                                    upLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged2 = false;
                                    letterN.style.backgroundColor = '#f0f0f0';  // Reset N box color
                                    colorChanged4 = false;
                                    letterAny.style.backgroundColor = '#f0f0f0';
                                    colorChanged5 = false;
                                    fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                    colorChanged6 = false;
                                });

                                // Adding click event to the new letter box (N box)
                                letterN.addEventListener("click", function() {
                                    if (colorChanged4) {
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged4 = false;
                                    } else {
                                        this.style.backgroundColor = 'lightgreen'; 
                                        colorChanged4 = true;
                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        anyNumberPlay.innerText = "";
                                    }
                                    downLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged1 = false;
                                    upLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged2 = false;
                                    letterL.style.backgroundColor = '#f0f0f0';
                                    colorChanged3 = false;
                                    letterAny.style.backgroundColor = '#f0f0f0';
                                    colorChanged5 = false;
                                    fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                    colorChanged6 = false;
                                });

                                // adding click event to the AnyNumber
                                letterAny.addEventListener("click", function() {
                                    if (colorChanged5) {
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged5 = false;
                                        anyNumberPlay.innerText = "";
                                    } else {
                                        
                                        
                                        while (true) {
                                            userInput = prompt("Enter a number:");
                                            if (userInput === null) {
                                                break;
                                            }

                                            if (userInput !== null && userInput.trim() !== "" && !isNaN(userInput) && userInput <=5 && userInput >0) {
                                                localStorage.setItem("AnyNumbers", userInput);
                                                this.style.backgroundColor = 'lightgreen'; 
                                                colorChanged5 = true;
                                                document.getElementById("selectNoOfCols_option").value = "0";
                                                document.getElementById("selectNoOfRows_option").value = "0";
                                                document.getElementById("selectNoOfDiagonals_option").value = "0";
                                                document.getElementById("noOfPlays_txt").value = 0;
                                                anyNumberPlay.innerText = "ቢያንስ በ 3 ቤት "+userInput+" ቁጥር"
                                                break; 
                                            } else {
                                                alert("Invalid input! Please enter a valid number.");
                                            }
                                        }

                                        // Retrieve the stored value later
                                        let retrievedValue = localStorage.getItem("AnyNumbers");
                                    }
                                    downLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged1 = false;
                                    upLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged2 = false;
                                    letterL.style.backgroundColor = '#f0f0f0';
                                    colorChanged3 = false;
                                    letterN.style.backgroundColor = '#f0f0f0';
                                    colorChanged4 = false;
                                    fourCornersPlay.style.backgroundColor = '#f0f0f0';
                                    colorChanged6 = false;
                                });

                                // adding click event to four cornesr play
                                fourCornersPlay.addEventListener("click", function() {
                                    console.log(colorChanged6);
                                    if (colorChanged6) {
                                        console.log("working four corners");
                                        this.style.backgroundColor = '#f0f0f0'; 
                                        colorChanged6 = false;
                                    } else {
                                        console.log("working four corners 2");
                                        this.style.backgroundColor = 'lightgreen'; 
                                        colorChanged6 = true;
                                        document.getElementById("selectNoOfCols_option").value = "0";
                                        document.getElementById("selectNoOfRows_option").value = "0";
                                        document.getElementById("selectNoOfDiagonals_option").value = "0";
                                        document.getElementById("noOfPlays_txt").value = 0;
                                        anyNumberPlay.innerText = "";
                                    }
                                    downLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged1 = false;
                                    upLetter.style.backgroundColor = '#f0f0f0';
                                    colorChanged2 = false;
                                    letterL.style.backgroundColor = '#f0f0f0';
                                    colorChanged3 = false;
                                    letterAny.style.backgroundColor = '#f0f0f0';
                                    colorChanged5 = false;
                                    letterN.style.backgroundColor = '#f0f0f0';
                                    colorChanged4 = false;
                                });
                            </script>
                        </tbody>
                    </table>
                    Select Bet Amount and Press Start Betting Button To Start The Game
                </div>
            </div>
            <!--/ Basic Alerts -->
            
            <!--/ Dismissible Alerts -->
        </div>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>
  </body>
</html>
<div class="modal fade" id="addNewCartelaModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">You Can Add New Cartelas Here</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body" id="advertsModal_div">
            <div class="row">
                <div class="nav-align-top mb-4">
                  <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <button
                        type="button"
                        class="nav-link active"
                        role="tab"
                        data-bs-toggle="tab"
                        data-bs-target="#addNewCartela_div"
                        aria-controls="addNewCartela_div"
                        aria-selected="true"
                      >
                        Add New Cartela
                      </button>
                    </li>
                    <li class="nav-item">
                      <button
                        type="button"
                        class="nav-link"
                        role="tab"
                        id="updateCartelaTab_btn"
                        data-bs-toggle="tab"
                        data-bs-target="#horseRedeem_div"
                        aria-controls="horseRedeem_div"
                        aria-selected="false"
                      >
                        Update Cartela
                      </button>
                    </li>
                  </ul>
                  <div class="tab-content" style="margin-left: -2%; width: 103%; ">
                    <div class="tab-pane fade show active" id="addNewCartela_div" role="tabpanel" >
                        <input type="number" class="form-control" id="newCartelaNo_txt" style="color: black;"  onfocus="changeValue(this)" placeholder="Cartela Number ...." min="0">
                        <table class="table table-striped table-bordered bingoTables"  id="newCartela_table" style="text-align: center;">
                            <thead style="background: #ed3939;">
                                <th>B</th>
                                <th>I</th>
                                <th>N</th>
                                <th>G</th>
                                <th>O</th>
                            </thead>
                            <tbody style="border: 1px solid gray;">
                                <tr><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td></tr>
                                <tr><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td></tr>
                                <tr><td contenteditable='true'></td><td contenteditable='true'></td><td>Free</td><td contenteditable='true'></td><td contenteditable='true'></td></tr>
                                <tr><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td></tr>
                                <tr><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td><td contenteditable='true'></td></tr>
                            </tbody>
                        </table>
                        <div class="demo-inline-spacing">
                        <button type="button" class="btn rounded-pill btn-success" id="saveNewCartela_btn"onclick="saveNewCartela()" >Save Cartela</button>
                        <button type="button" class="btn rounded-pill btn-danger" onclick="clearCartela_btn()">Clear Cartela</button>
                        <button type="button" class="btn rounded-pill btn-danger" id="updateCartela_btn"onclick="updateNewCartela()" >Update Cartela</button>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="horseRedeem_div" role="tabpanel" >
                        <div style="display: flex;">
                            <input type="number" class="form-control" id="cartelaNo_txt" oninput="loadCartelaToUpdate()" onfocus="changeValue(this)" placeholder="Cartela Number ...." min="0">

                            <button class="btn btn-outline-danger w-100" onclick="loadCartelaToUpdate()">Load Cartela</button>
                            
                        </div>
                        <hr>
                        <div id="cartelaDetail_div">
                            
                        </div>
                    </div>
                  </div>
                </div>
            </div> 
            <h3 id="error_p"></h3>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<script>
    function loadCashierDetail(){
        $.ajax({
            url: "activities.php",
            type:"post",
            data:({Purpose:"Cashier-Detail"}),
            success: function(result){
                document.getElementById("cashierDetailModalBody_div").innerHTML = result;
            }
        });
    }
    

</script>
<div class="modal fade" id="cashierOptionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Your Cashier Status</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
          
        ></button>
      </div>
      <div class="modal-body" id="cashierDetailModalBody_div">
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade modal-xl" id="checkCartelaModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Check Cartela</h5><h3 style="background-color: blueviolet; color: floralwhite; width:50%; margin-left:25%;  font-style: bold; text-align: center; display: block;" id="playTypeCheckCartela_div"> </h3>
        <h3 style="background-color: goldenrod; color: floralwhite; width:20%; margin-left:0%;  font-style: bold; text-align: center; display: block;" id="lastThreeWinners_h3"> 7 ,7</h3>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
          id = "exitModal_btn"
          onclick="restartGame()" 
        ></button>
        </div>
        <div class="modal-body" id="">
            <div id=""></div>
            <div id="topRowCheckCartela_div" class="row"></div>
            <div id="snipThis_div">
                <div id="checkCartelaModalBody_div">
                
                </div>
                <h3 style="background-color: red; color: white; font-style: bold; text-align: center; display: none;" id="badBingo_message"> የተሟላ መስመር ስላልሰራ ይህ ካርቴላ ተሰርዟል </h3>
                <hr>
            </div>
        </div>
      
        <button type="button" class="form-control btn btn-success" style="display: none;" id="goodBingo_btn" onclick="goodBingo()" >Good Bingo
        </button>
        
      <div class="modal-footer">
        <button type="button" class="form-control btn btn-danger" style="display: none;" id="exitBingo_btn" data-bs-dismiss="modal" onclick="exitGame()" >Exit Game
        </button>
        <button type="button" class="form-control btn btn-warning" style="display: none;" id="refreshGame_btn" data-bs-dismiss="modal" onclick="restartBetting()" >Restart Game
        </button>
        <button type="button" class="form-control btn btn-outline-secondary" onclick="restartGame()"  data-bs-dismiss="modal">
          Close
        </button>
        <input type="number" id="totalReward_txt" disabled value="0" />
        <input type="number" id="totalNoOfWinners_txt" disabled value="0" />
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="showAuditModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Audit Your System</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body" id="cashierData_div">
            
      </div>
        <center><div id="success_td"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="showSettingModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Change Your Password</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>
      <div class="modal-body">

        <div class="row mb-3">
          <label class="col-sm-2 col-form-label" for="currentPassword_txt">Current Password</label>
          <div class="col-sm-10">
            <div class="input-group input-group-merge">
                <input type="password" id="currentPassword_txt" class="form-control" name="currentPassword_txt" placeholder="············" aria-describedby="showCurrentPass">
                <span class="input-group-text cursor-pointer" id="showCurrentPass"><i class="bx bx-hide"></i></span>
              </div>
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 col-form-label" for="newPassword_txt">New Password</label>
          <div class="col-sm-10">
            <div class="input-group input-group-merge">
                <input type="password" id="newPassword_txt" class="form-control" name="newPassword_txt" placeholder="············" aria-describedby="password">
                <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
              </div>
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 col-form-label" for="confirmPassword_txt">Confirm Password</label>
          <div class="col-sm-10">
            <div class="input-group input-group-merge">
                <input type="password" id="confirmPassword_txt" class="form-control" name="confirmPassword_txt" placeholder="············" aria-describedby="password">
                <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
              </div>
          </div>
        </div>   
        <div class="mb-3">
                  <button class="btn btn-primary d-grid w-100" type="submit" onclick="changePassword()">Change Password</button>
                </div>
      </div>
        <center><div id="pChangeSuccess_td" class="text-white"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade modal-xl" id="showRestartTheGameModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">ከ 3 በላይ አሸናፊ ስለተገኘ ጨዋታውን እንደገና ለማካሄድ የጨዋታ አይነት ይምረጡ  </h5>
        
      </div>
      <div class="modal-body">
   
        <table class="table table-striped table-bordered" style="align-items: center;">
            <thead><th>ቋሚ</th><th>አግዳሚ</th><th>ዲያጎናል </th><th>በማንኛውም</th></thead>
            <tbody>
                <tr>
                    <td>
                        <select id="selectNoOfCols_option1" class="form-select d-flex" onchange="changeNoOfReRows(this)">
                          <option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
                          <option value="4">4</option><option value="5">5</option>
                        </select>
                    </td>
                    <td><select id="selectNoOfRows_option1" class="form-select d-flex" onchange="changeNoOfReRows(this)">
                          <option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
                          <option value="4">4</option><option value="5">5</option>
                        </select>
                    </td>
                    <td><select id="selectNoOfDiagonals_option1" class="form-select d-flex" onchange="changeNoOfReRows(this)">
                          <option value="0">0</option><option value="1">1</option><option value="2">2</option>
                        </select>
                    </td>
                    <td>
                        <input type="number" class="btn btn-input" onclick="changeText(this)" onfocus="changeText(this)" oninput="checkNoOfRePlays(this)" id="noOfPlays_txt1" value="2" min="0" max="12" style=" text-align: center; border: 1px solid black; color: black; " />
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center><button class="bet-btns btn btn-outline-danger"  data-bs-dismiss="modal" type="button" onclick="restartBetting()">Start Betting</button></center>
                    </td>
                    <script type="text/javascript">
                        function checkNoOfRePlays(id){
                            var text = id.value;
                            if( text != 0 ){
                                document.getElementById("selectNoOfCols_option1").value = "0";
                                document.getElementById("selectNoOfRows_option1").value = "0";
                                document.getElementById("selectNoOfDiagonals_option1").value = "0";
                                upLetter.style.backgroundColor = '#f0f0f0';
                                colorChanged2 = false;
                                downLetter.style.backgroundColor = '#f0f0f0';
                                colorChanged1 = false;
                            }
                            if(text < 0 || text > 12 ){ id.value = "12"; }
                        }
                        function changeNoOfReRows(id){
                            if(id.value != 0 ){
                                document.getElementById("noOfPlays_txt1").value = 0;
                                upLetter.style.backgroundColor = '#f0f0f0';
                                colorChanged2 = false;
                                downLetter.style.backgroundColor = '#f0f0f0';
                                colorChanged1 = false;
                            }
                        }
                    </script>
                </tr>

            </tbody>
        </table>
      </div>
        <center><div id="pChangeSuccess_td" class="text-white"></div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
<?php
    }
    else{
        ?>
        <script>
        window.open("../","_self");</script>
        <?php
    }
    ?>

