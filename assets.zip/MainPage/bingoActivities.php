<?php
	require_once("../connection.php");
	require_once('../encryption.php');
	session_start();
	$encrypt = new encryption();
	$purpose = $_POST['Purpose'];
	$username = $_SESSION['UserName'];
	$now = time();
    mysqli_query($conn,"update exp set T=$now") or die(mysqli_error($conn));
	if($purpose == "Load-Saved-Bingos-Detail"){
		$cartelaNo = $_POST['CartelaNo'];
		$q = mysqli_query($conn,"select *from bingo where No='$cartelaNo'") or die(mysqli_error($conn));
		$noOfTables = mysqli_num_rows($q);
		if($noOfTables > 0){
			
			$i = 0;
			while($row = mysqli_fetch_array($q)){
				?>
					<div class="row" id="toPrint_div" style="display: inline-flex; color: black;">
						<div class="col-sm-12" style="display: inline-flex;">
							<h5 style="color: black; margin-left: 10px;">ካርቴላ ቁጥር :</h5>
							<h5 style="color: black; font-weight: bold; font-size: 20px;margin-left: 8px;"><?php echo $cartelaNo;  ?></h5>
							<center><h6 style="border:1px solid black; margin-left: 8px; color: black;"> &#x2B50; AB-STAR BINGO GAME &#x2B50;</h6></center>
						</div>
						<div class="col-sm-2">
						</div>
					</div>
					<table class="table table-bordered bingoTables" style="color: black; margin-top: -15px; border: 1px solid black; text-align: center;" id="<?php echo $cartelaNo; ?>">
						<thead style="background: #ed3939; color: black; font-size: 15px;">
							<th style="color: black;font-size: 15px;font-weight: bold;">B</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">I</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">N</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">G</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">O</th>
						</thead>
						<tbody style="border: 1px solid gray;">
							<?php
								$bcol = preg_replace("/\s*/m", '', $row['B']);
								$icol = preg_replace("/\s*/m", '', $row['I']);
								$ncol = preg_replace("/\s*/m", '', $row['N']);
								$gcol = preg_replace("/\s*/m", '', $row['G']);
								$ocol = preg_replace("/\s*/m", '', $row['O']);
								for ($m=0; $m < 10; $m+=2) 
								{
									$ncoldisp = substr($ncol,$m,2 );
									if($m > 3){
										if($m == 4) {	$ncoldisp = substr($ncol,$m,4); }
										else{	$ncoldisp = substr($ncol,$m+2,2);	}
									}
									else{	$ncoldisp = substr($ncol,$m,2 ); }
									?>
								<tr><?php
									if($m == 4 )
										echo "<td >".substr($bcol,$m,2 )."</td>"."<td >".substr($icol,$m,2 )."</td>".
											"<td >".$ncoldisp."</td>"."<td >".substr($gcol,$m,2 )."</td>".
											"<td >".substr($ocol,$m,2 )."</td>";
									else
										echo "<td >".substr($bcol,$m,2 )."</td>"."<td >".substr($icol,$m,2 )."</td>".
											"<td >".$ncoldisp."</td>"."<td >".substr($gcol,$m,2 )."</td>".
											"<td >".substr($ocol,$m,2 )."</td>";
								?> </tr>
								<?php
								}
							?>		
						</tbody>
					</table>
					<center><h6 style="color: black; font-size: 15px;"> &#x1F31F;&#x1F31F;&#x1F31F; መልካም ዕድል - ከዕድልዎ ቤት &#x1F31F;&#x1F31F;&#x1F31F;</h6></center>
				<?php
				$i++;
			}?> <button class="form-control btn-success" id="saveMyBingosFromTemporary_btn" onclick="saveMyBingos('<?php echo $cartelaNo; ?>')">Save My Bingos</button> <?php
		}
		else{
			?>
			<cneter> 
				<h3> The Cartela Number you have entered doesn't found on the system. </h3>
				<h5> 
					<ul>
						<li> The Game Ends. </li>
						<li> The Game is played and removed from your temporary folder. </li>
					</ul>
					Contact system administrator for more information.
				</h5>
			</cneter>
			<?php
		}
	}
	/* CHECK BINGO ACTIVITIES */
	else if ($purpose == "Save-Bingo") {
		$cartelaNo = $_POST['CartelaNo'];
		$phoneNo = $_POST['PhoneNo'];
		$query = mysqli_query($conn,"update bingo set Taken = 1,PhoneNo='$phoneNo' where No = '$cartelaNo';") or die(mysqli_error($conn));
		$addAmount = $_POST['BetAmount'];
		mysqli_query($conn, "update cashier set Collected =(Collected+'$addAmount') where Id='$username'") or die(mysqli_error($conn));
		mysqli_query($conn, "update currentActivity set NoOfTakenCartelas =(NoOfTakenCartelas+1)") or die(mysqli_error($conn));
        $n = time();
        mysqli_query($conn,"update exp set T=$n");
		?>
		<cneter>
			<div class="field" style="background-color: yellow;">
				<h3> Cartela Saved Successfully. </h3>
			</div>
		</cneter>
		<?php
	}
	else if ($purpose == "Save-Bingo-Array") {
		$selectedCartelas = $_POST['SelectedCartelas'];
		$phoneNo = $_POST['PhoneNo'];
		$noOfCartelas = count($selectedCartelas);
		$i = 0;
		while($i < $noOfCartelas ){
			$cartelaNo = $selectedCartelas[$i];
			$query = mysqli_query($conn,"update bingo set Taken = 1,PhoneNo='$phoneNo' where No = '$cartelaNo';") or die(mysqli_error($conn));
			$i++;
		}
		
		$addAmount = $noOfCartelas * $_POST['BetAmount'];
		mysqli_query($conn, "update cashier set Collected =(Collected+'$addAmount') where Id='$username'") or die(mysqli_error($conn));
		mysqli_query($conn, "update currentActivity set NoOfTakenCartelas =(NoOfTakenCartelas+$noOfCartelas)") or die(mysqli_error($conn));
        $n = time();
        mysqli_query($conn,"update exp set T=$n");
    	echo "success";
		?>
		
		<?php
	}
	else if($purpose == "Load-Untaken-Bingos"){
	   	$untaken = [];
	    $taken = [];

	    // Load untaken
	    $query1 = mysqli_query($conn, "SELECT No FROM bingo WHERE Taken = 0");
	    if ($query1) {
	        while ($row = mysqli_fetch_assoc($query1)) {
	            $untaken[] = $row['No'];
	        }
	    } else {
	        echo json_encode(["error" => mysqli_error($conn)]);
	        exit;
	    }

	    // Load taken with PhoneNo
	    $query2 = mysqli_query($conn, "SELECT No, PhoneNo FROM bingo WHERE Taken = 1");
	    if ($query2) {
	        while ($row = mysqli_fetch_assoc($query2)) {
	            $taken[] = [
	                'No' => $row['No'],
	                'PhoneNo' => $row['PhoneNo']
	            ];
	        }
	    } else {
	        echo json_encode(["error" => mysqli_error($conn)]);
	        exit;
	    }

	    echo json_encode([
	        "untaken" => $untaken,
	        "taken" => $taken
	    ]);
	}
	else if($purpose == "Generate-Winners"){
	    $now = time();
	    mysqli_query($conn, "update exp set T=$now") or die(mysqli_error($conn));

	    // Retrieve previous winners
	    $prev_winners_query = mysqli_fetch_array(mysqli_query($conn, "SELECT Winners FROM winner")) or die(mysqli_error($conn));
	    $prev_winners = str_split($prev_winners_query['Winners'], 2); // Split into two-digit pairs
	    //echo $prev_winners_query['Winners']."<br>";
	    $array = [];
	    
	    for($i = 0; $i < 75; $i++) { // Ensuring EXACTLY 75 iterations
	    	//echo "\n".$i." P : ".$prev_winners[$i];
	        do {
	            $rand = str_pad(rand(1, 75), 2, "0", STR_PAD_LEFT); // Always two digits
	        } while(in_array($rand, $array, true) || $rand == $prev_winners[$i]); // Prevent duplicates & same position
	        //echo "\n".$i." - ".$prev_winners[$i]." = ".$rand;
	        $array[] = $rand; // Store the correctly formatted number
	    }

	    $winners = implode("", $array); // Joining numbers WITHOUT spaces or extra characters

	    // **Ensuring Correct Length**
	    if(strlen($winners) !== 150) {
	        echo "Error: Generated string length is incorrect.";
	    } else {
	        // Save new winners
	        mysqli_query($conn, "UPDATE winner SET Winners='$winners', noOfWinnersShown=0") or die(mysqli_error($conn));
	        mysqli_query($conn, "UPDATE currentActivity SET Playing=1,SayBingo=0,CallerPhone=''") or die(mysqli_error($conn));
	    }

	    echo $winners;
	}
	else if($purpose == "Get-Winners"){
		$q = mysqli_query($conn,"select *from winner") or die(mysqli_error($conn));
		$res ="";
		while($row = mysqli_fetch_array($q)){
			$res = $row["Winners"];
		}
		echo $res;
	}
	else if($purpose == "Add-Bet-Amount") {
	    $bm = $_POST['BetAmount'];
	    $p = $_POST['Percent'];
	    $playType = $_POST['PlayType'];

	    mysqli_query($conn, "UPDATE currentActivity SET BetAmount=$bm, Percent=$p, PlayType='$playType'") or die(mysqli_error($conn));
	}
else if($purpose == "Pause-Game"){
    mysqli_query($conn,"UPDATE currentActivity SET Playing=2") or die(mysqli_error($conn));

    $q1 = mysqli_query($conn,"SELECT * FROM currentActivity") or die(mysqli_error($conn));
    $row = mysqli_fetch_array($q1);
    $sayerPhone = $row['CallerPhone'];

    $query = mysqli_query($conn,"SELECT No, PhoneNo FROM bingo WHERE Taken=1") or die(mysqli_error($conn));

    if(mysqli_num_rows($query) <= 0){
        echo "none";
    } else {
        $allTakenNumbers = [];
        $callerNumbers = [];

        while($row = mysqli_fetch_array($query)){
            $allTakenNumbers[] = $row;
            if($row['PhoneNo'] === $sayerPhone){
                $callerNumbers[] = $row['No'];
            }
        }
        ?>
		<div class="row">
		    <div class="col-md-8 nav nav-tabs" style="
		        display: flex;
		        overflow-x: auto;
		        gap: 6px;
		        padding: 10px 0;
		        white-space: nowrap;
		    ">
		        <?php
		        $odd = 1;
		        foreach($allTakenNumbers as $row){
		            $code = $row['No'];
		            $class = ($odd == 1) ? "btn-outline-success" : "btn-outline-danger";
		            $odd = 1 - $odd;
		            ?>
		            <button class="btn rounded-pill <?php echo $class; ?>" onclick="checkMyBingos(<?php echo $code; ?>)">
		                <?php echo $code; ?>
		            </button>
		            <?php
		        }
		        ?>
		    </div>

		    <div class="col-md-4">
		        <h4><?php echo htmlspecialchars($sayerPhone)." : ". implode(", ", $callerNumbers); ?></h4>
		    </div>
		</div>

        <?php
    }
}

	else if($purpose == "Restart-Game") {
	    $query = "UPDATE currentActivity SET Playing = 1, SayBingo = 0";
	    if ($conn->query($query)) {
	        echo "success";
	    } else {
	        echo "Error: " . $conn->error;
	    }
	}
	elseif ($purpose == "End-Game") {
	    $playType = isset($_POST['PlayType']) ? $_POST['PlayType'] : null;

	    // Prepare the SQL query
	    if ($playType !== null) {
	        $sql = "UPDATE currentActivity SET Playing = 0, SayBingo = 0, PlayType = ?";
	    } else {
	        $sql = "UPDATE currentActivity SET Playing = 0, SayBingo = 0";
	    }

	    $success = false;
	    $retries = 0;
	    $maxRetries = 5;

	    while (!$success && $retries < $maxRetries) {
	        if ($playType !== null) {
	            $stmt = $conn->prepare($sql);
	            $stmt->bind_param("s", $playType);
	            $success = $stmt->execute();
	        } else {
	            $success = mysqli_query($conn, $sql);
	        }

	        if ($success) {
	            echo "success";
	            break;
	        } else {
	            error_log("Retrying... Error: " . mysqli_error($conn));
	            usleep(100000); // 100ms delay before retry
	            $retries++;
	        }
	    }

	    if (!$success) {
	        echo "error";
	    }
	}

	else if($purpose == "Discard-Cartela"){
		$bingoCode = $_POST['CartelaNo'];
		mysqli_query($conn,"update bingo set Taken=0,PhoneNo='' where No='$bingoCode'") or die(mysqli_error($conn));
	}
	else if($purpose == "Good-Bingo"){
		$amount = $_POST['WinAmount'];
		$winnerCartela = $_POST['CartelaNo'];
		mysqli_query($conn,"update bingo set Taken=0") or die(mysqli_error($conn));
		mysqli_query($conn,"update currentActivity set Playing=0, NoOfTakenCartelas=0 ,SayBingo=0,CallerPhone=''") or die(mysqli_error($conn));
		mysqli_query($conn,"update cashier set Paid =(Paid+'$amount') where Id='$username'") or die(mysqli_error($conn));
		mysqli_query($conn, "UPDATE currentActivity SET Playing=0,SayBingo=0") or die(mysqli_error($conn));
		echo "success";
	}
	else if($purpose == "Exit-Bingo"){
		mysqli_query($conn,"update bingo set Taken=0,PhoneNo=''") or die(mysqli_error($conn));
		mysqli_query($conn,"update currentActivity set Playing=0, NoOfTakenCartelas=0 ,SayBingo=0,CallerPhone=''") or die(mysqli_error($conn));
	}
	else if($purpose == "Check-Say-Bingo"){
		$data = 0;
		$query = mysqli_query($conn,"select *from currentActivity");
		while($row = mysqli_fetch_array($query)){
			$data = $row['SayBingo'];
		}
		echo $data;
	}
	else if($purpose == "Exit-Match"){
		mysqli_query($conn,"update currentActivity set Playing=0,SayBingo=0,CallerPhone=''") or die(mysqli_error($conn));
	}
	else if($purpose == "Restart-The-Game"){
		mysqli_query($conn,"update currentActivity set Playing=0,,SayBingo=0,CallerPhone=''") or die(mysqli_error($conn));
	}
	else if($purpose == "Get-Taken-Cartelas"){
		$q = mysqli_query($conn,"select *from currentActivity") or die(mysqli_error($conn));
		$res = mysqli_fetch_array($q);
		$noOfCartelas = $res['NoOfTakenCartelas'];
        $betAmount = $res['BetAmount'];
        $percent = $res['Percent'];
        $data  = array('betAmount'=>$betAmount,'noOfTakenCartelas' => $noOfCartelas,'percent'=>$percent);
        echo json_encode($data); 
	}
	else if($purpose == "Update-NoOfCartelasShown"){
		$no = $_POST['No'];
		mysqli_query($conn,"update winner set NoOfWinnersShown='$no'") or die(mysqli_error($conn));
	}
	else if($purpose == "Load-My-Bingo-Detail"){
	    
	    $bingoCode = $_POST['CartelaNo'];
	    $q = mysqli_query($conn,"select *from winner") OR die(mysqli_error($conn));
        $row = mysqli_fetch_array($q);
	    $noOfWinnersShown = $row['NoOfWinnersShown'];
	    $winnerNos = $row['Winners'];
	    $winnersShown = substr($winnerNos, 0,$noOfWinnersShown+1);
    		$q = mysqli_query($conn,"select *from bingo where No='$bingoCode'") or die(mysqli_error($conn));
    			$i = 0;
    			?> <div class="row"> <?php
    			while($row = mysqli_fetch_array($q)){
    				?>
    				<div class="col-sm-2" style="display: grid;place-items: center; "><h2 style="display: inline-flex; ">ካርቴላ ቁጥር</h2> <h1 style="font-size: 180px;"><?php echo $bingoCode; ?> </h1></div>
    				<div class="col-sm-4" style="margin-left: 5%;">
    					<table class="table table-bordered table-condensed bingoTables" style="border: 2px solid #ed3939;text-align: center;color: black;" id="<?php echo $bingoCode; ?>">
    						<thead style="background: #ed3939; color: black;">
    							<th style="color: black;font-size: 15px;font-weight: bold;">B</th>
									<th style="color: black;font-size: 15px;font-weight: bold;">I</th>
									<th style="color: black;font-size: 15px;font-weight: bold;">N</th>
									<th style="color: black;font-size: 15px;font-weight: bold;">G</th>
									<th style="color: black;font-size: 15px;font-weight: bold;">O</th>
    						</thead>
    						<tbody style="border: 1px solid gray; color: black;">
    						<?php
    							$bcol = preg_replace("/\s*/m", '', $row['B']);
    							$icol = preg_replace("/\s*/m", '', $row['I']);
    							$ncol = preg_replace("/\s*/m", '', $row['N']);
    							$gcol = preg_replace("/\s*/m", '', $row['G']);
    							$ocol = preg_replace("/\s*/m", '', $row['O']);
    							for ($m=0; $m < 10; $m+=2) 
    							{
    								$ncoldisp = substr($ncol,$m,2 );
    								if($m > 3){
    									if($m == 4) {	$ncoldisp = substr($ncol,$m,4); }
    									else{	$ncoldisp = substr($ncol,$m+2,2);	}
    								}
    								else{	$ncoldisp = substr($ncol,$m,2 ); }
    								?>
    							<tr><?php
    								if($m == 4 )
    									echo "<td>".substr($bcol,$m,2 )."</td>"."<td >".substr($icol,$m,2 )."</td>".
    										"<td >".$ncoldisp."</td>"."<td >".substr($gcol,$m,2 )."</td>".
    										"<td >".substr($ocol,$m,2 )."</td>";
    								else
    									echo "<td >".substr($bcol,$m,2 )."</td>"."<td >".substr($icol,$m,2 )."</td>".
    										"<td >".$ncoldisp."</td>"."<td >".substr($gcol,$m,2 )."</td>".
    										"<td >".substr($ocol,$m,2 )."</td>";
    							?> </tr>
    							<?php
    							}
    						?>		
    						</tbody>
    					</table>
    				</div>
    				
    				<div class="col-sm-2" style="align-content: center; align-self: center; position: relative;">
    					<table class="table table-striped table-bordered" style="text-align: center;">
    						<th colspan="2" style="background: #297ae0;">Your Result</th>
    						<tr><td>Row(s) / አግዳሚ </td><td id="<?php echo $bingoCode."rows_td"; ?>">0</td></tr>
    						<tr><td>Column(s) / ቋሚ</td><td id="<?php echo $bingoCode."cols_td"; ?>">0</td></tr>
    						<tr><td>Diagonal(s)</td><td id="<?php echo $bingoCode."diagonals_td"; ?>">0</td></tr>
    						<tr><td style="text-align: right;">Total :</td><td id="<?php echo $bingoCode."total_td"; ?>"></td></tr>
    						<tr><td colspan="2" style="text-align: center;" id="<?php echo $bingoCode."win_td"; ?>"></td></tr>
    					</table>
    				</div>
    				<div class="col-sm-2 mark check" id="rightMark_div" style="display: none;">✓</div>
    				<div class="col-sm-2 mark wrong" id="wrongMark_div" style="display: none;">✗</div>
    				<?php
    				$i++;
    			}
    			echo "<script type='text/javascript'>setBackground('$bingoCode','$winnersShown','$noOfWinnersShown');
    				</script>";
	    		?>
	    			</div>
	    			<div>
	    				<button class="form-control btn-outline-danger" style="display:none;" id="removeCartela_btn" onclick="discardCartela('<?php echo $bingoCode; ?>')">Discard This Cartela</button>
	    			</div>
	    		<?php
	}

	else if($purpose == "Check-My-Bingo"){
		$phone = $_POST['Phone'];
		$bingoCode = $_POST['BingoCode'];
		$checkedBy = $encrypt->encrypt('SELF');
		$amount = $_POST['Money'];
		$gameType = "Bingo";
		$betAmount = 10;
		$winTime = date("Y-m-d H:i:s");
		$checkTableQ = "update bingo set Checked=1,CheckedBy='$checkedBy' where BingoCode='$bingoCode' and PhoneNo='$phone' and Checked=0";
		$updateMoneyQ = "update players set CurrentAmount=(CurrentAmount+'$amount') where PhoneNo='$phone'";
		$updateBingoWinnerTable = "update bingowinner set TotalWinMoney=(TotalWinMoney+'$amount') where BingoCode='$bingoCode'";
		mysqli_query($conn,$checkTableQ) or die(mysqli_error($conn));
		if($amount > 0)
		{
			if($amount >= 20){
				mysqli_query($conn,"insert into wins(PhoneNo,GameId,GameType,BetAmount,WinAmount,WinTime) values('$phone','$bingoCode','$gameType','$betAmount','$amount','$winTime')") or die(mysqli_error($conn));
			}
			if(mysqli_query($conn,$updateMoneyQ)){
				mysqli_query($conn,$updateBingoWinnerTable) or die(mysqli_error($conn));
				echo "success";}
			else
				echo mysqli_error($conn);
		}
		else{
			echo "success";
		}
	}
	//delete a bingo card
	else if($purpose == "Delete-Bingo-Card"){
		$tableCode = $_POST['TableCode'];
		$gameCode = $_POST['GameCode'];

		$deleteQuery = "delete from temporarybingo where GameCodeForPlayer='$gameCode' and TableCode='$tableCode'";
		if(mysqli_query($conn,$deleteQuery))
			echo "success";
		else
			echo mysqli_error($conn);
	}
	else if($purpose == "Add-Cartela"){
		$bingo = $_POST['Cartela'];
		$cartNo = $_POST['CartelaNo'];
		
		$insertQuery = "insert into bingo (No,B,I,N,G,O,Taken) values('$cartNo','$bingo[0]','$bingo[1]','$bingo[2]','$bingo[3]','$bingo[4]',0)";
		if(mysqli_query($conn,$insertQuery)){
			echo "success";
		}
		else{
			echo "failed Reason :->  ".mysqli_error($conn);
		}
	}
	else if($purpose == "Load-To-Update"){
		$cartelaId = $_POST['Cartela'];
		$query = mysqli_query($conn,"select *from bingo where No='$cartelaId'") or die(mysqli_error($conn));
		if(mysqli_num_rows($query)){
			while($row = mysqli_fetch_array($query)){ ?>
				<table class="table table-striped table-bordered bingoTables"  id="updateTable_tbl" style="text-align: center;">
				<thead style="background: #ed3939;">
					<th style="color: black;font-size: 15px;font-weight: bold;">B</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">I</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">N</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">G</th>
							<th style="color: black;font-size: 15px;font-weight: bold;">O</th>
				</thead>
				<tbody style="border: 1px solid gray;">
					<?php
							$bcol = preg_replace("/\s*/m", '', $row['B']);
							$icol = preg_replace("/\s*/m", '', $row['I']);
							$ncol = preg_replace("/\s*/m", '', $row['N']);
							$gcol = preg_replace("/\s*/m", '', $row['G']);
							$ocol = preg_replace("/\s*/m", '', $row['O']);
							for ($m=0; $m < 10; $m+=2) 
							{
								$ncoldisp = substr($ncol,$m,2 );
								if($m > 3){
									if($m == 4) {	$ncoldisp = substr($ncol,$m,4); }
									else{	$ncoldisp = substr($ncol,$m+2,2);	}
								}
								else{	$ncoldisp = substr($ncol,$m,2 ); }
								?>
							<tr><?php
								if($m == 4 )
									echo "<td contenteditable=true>".substr($bcol,$m,2 )."</td>"."<td contenteditable=true>".substr($icol,$m,2 )."</td>".
										"<td contenteditable=false>".$ncoldisp."</td>"."<td contenteditable=true>".substr($gcol,$m,2 )."</td>".
										"<td contenteditable=true>".substr($ocol,$m,2 )."</td>";
								else
									echo "<td contenteditable=true>".substr($bcol,$m,2 )."</td>"."<td contenteditable=true>".substr($icol,$m,2 )."</td>".
										"<td contenteditable=true>".$ncoldisp."</td>"."<td contenteditable=true>".substr($gcol,$m,2 )."</td>".
										"<td contenteditable=true>".substr($ocol,$m,2 )."</td>";
							?> </tr>
							<?php
							}
						?>				
				</tbody>
			</table><center>
			<div class="demo-inline-spacing">
          <button type="button" class="btn rounded-pill btn-success" onclick="updateCartela(<?php echo $cartelaId; ?>)">Update</button>
          <button type="button" class="btn rounded-pill btn-danger" onclick="deleteCartela(<?php echo $cartelaId; ?>)">Delete</button>
        </div></center>
			<?php }
		}
		else{
			echo "<center><h3>Cartela number not found </h3></center>";
		}
	}
	else if($purpose == "Update-Cartela"){
		$cartelaId = $_POST['CartelaId'];
		$bingo = $_POST['Cartela'];
		$updateQuery = "update bingo set B='$bingo[0]',I='$bingo[1]',N='$bingo[2]',G='$bingo[3]',O='$bingo[4]' where No=$cartelaId";
		if(mysqli_query($conn,$updateQuery)){
			echo "success";
		}
		else{
			echo "failed".mysqli_error($conn);
		}
	}
	else if($purpose == "Delete-Cartela"){
		$cartelaId = $_POST['CartelaId'];
		$deleteQuery = "delete from bingo where No=$cartelaId";
		if(mysqli_query($conn,$deleteQuery)){
			
			echo "success";
		}
		else{
			echo "Failed : ".mysqli_error($conn);
		}
	}
	else {
		echo "Undefined Function";
	}
	mysqli_close($conn);
?>