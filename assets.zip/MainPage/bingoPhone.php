﻿<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en" data-theme="light">
  <head>
      <meta charset="utf-8" />
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
      />

      <title>AB STAR BINGO</title>

      <meta name="description" content="" />

      <!-- Favicon -->
      <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />


      <!-- Icons. Uncomment required icon fonts -->
      <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

      <!-- Core CSS -->
      <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
      <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
      <link rel="stylesheet" href="../assets/css/demo.css" />

      <!-- Vendors CSS -->
      <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

      <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />
      <link rel="stylesheet" href="../assets/css/mobile.css"/>
      <!-- Page CSS -->

      <!-- Helpers -->
      <script src="../assets/vendor/js/helpers.js"></script>

      <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
      <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
      <script src="../assets/js/config.js"></script>
      <script src="../assets/sweet.js"></script>
      <script src="../assets/vendor/libs/jquery/jquery.js"></script>
      <script src="../assets/js/html2canvas.min.js"></script>
      <script src="../assets/print.min.js"></script>

    <style>
      body, html {
        height: 100%;
        overflow-x: hidden;
          }
        .subRows{
          background: linear-gradient(0deg, rgba(34,193,195,1) 0%,red 50%, rgba(253,187,45,1) 100%);; 
        }

      .winnerHost_div {
        display: flex !important;
        flex: 0 0 auto !important;
        width: auto !important;
      }

      .bingo-hit {
          background-color: green !important; /* Green */
          color: white !important;
          font-weight: bold;
      }
    </style>
    <script>
      let percent, betAmount = 1, noOfTakenCartelas, paused = false, myCartelas = 0;

      let noOfTakenCartelasDiv, betAmountDiv, totalWinAmountDiv, winnerNumberSpan, winnerBadgeSpan,playTypeDiv, checkWinnerDiv, mainDiv, gameStatusDiv;

      let winnerInterval = null; // keep global control
      let currentStatus = null;
      let winnerShowStatus = false;
      let winnerNumbers = null;
      let currentPosition = "";
      let autoplayEnabled = false;

      $(document).ready(function () {
        // Get DOM references
        noOfTakenCartelasDiv = document.getElementById("noOfTakenCartelas_div");
        betAmountDiv = document.getElementById("betAmount_div");
        totalWinAmountDiv = document.getElementById("totalWinAmount_div");
        playTypeDiv = document.getElementById("playType_div");
        winnerNumberSpan = document.getElementById("winnerNumber_span");
        winnerBadgeSpan = document.getElementById("winnerBadge_span");
        checkWinnerDiv = document.getElementById("checkBingo_div");
        mainDiv = document.getElementById("mainDiv_div");
        gameStatusDiv = document.getElementById("gameStatus_div");
        // Start game control loop
        document.getElementById('autoplayCheckbox').addEventListener('change', function () {
          autoplayEnabled = this.checked;
          console.log('Autoplay is now', autoplayEnabled ? 'enabled' : 'disabled');

          // Close the dropdown
          const dropdownToggle = document.getElementById('menuDropdown');
          const dropdown = bootstrap.Dropdown.getInstance(dropdownToggle);
          if (dropdown) {
            dropdown.hide();
          }
        });
      });

      function getMyCartelas() {
          sendRequest("bingoMobileActivities.php", { Purpose: "Load-My-Bingos" }, function (result) {
              // ✅ If result is already an object, do NOT parse it
              const data = result;

              mainDiv.innerHTML = ''; // Clear previous content

              if (data.status === 'success') {
                myCartelas = data.bingos.length;
                  data.bingos.forEach(bingo => {
                      const tableHTML = createCartelaTable(bingo);
                      mainDiv.innerHTML += tableHTML;
                  });
                  mainDiv.innerHTML += `<center><h6 style="color: black; font-size: 15px;">✨✨✨ መልካም ዕድል - ከዕድልዎ ቤት ✨✨✨</h6></center>`;
              } else {
                myCartelas = 0;
                mainDiv.innerHTML = `<center><h3 style="margin-left: 5%;">${data.message}</h3></center>`;
              }
          });
      }

      function createCartelaTable(bingo) {
          const { cartelaNo, B, I, N, G, O } = bingo;

          let table = `
          <div class="row" style="display: inline-flex; color: black;">
              <div class="col-sm-12" style="display: inline-flex;">
                  <h5 style="margin-left: 10px;">ካርቴላ ቁጥር :</h5>
                  <h5 style="font-weight: bold; font-size: 20px; margin-left: 8px;">${cartelaNo}</h5>
              </div>
          </div>
          <table class="table table-bordered bingoTables" style="color: black; border: 1px solid black; text-align: center; margin-top: -15px;" id="${cartelaNo}">
              <thead style="background: #ed3939;">
                  <tr>
                      <th>B</th><th>I</th><th>N</th><th>G</th><th>O</th>
                  </tr>
              </thead>
              <tbody>`;

          // Indices for N column
          const nParts = [
              N.substr(0, 2),
              N.substr(2, 2),
              N.substr(4, 4), // FREE
              N.substr(8, 2),
              N.substr(10, 2)
          ];

          for (let row = 0; row < 5; row++) {
              const bVal = B.substr(row * 2, 2);
              const iVal = I.substr(row * 2, 2);
              const gVal = G.substr(row * 2, 2);
              const oVal = O.substr(row * 2, 2);

              // Handle center row with FREE
              const nCell = row === 2
                  ? `<td data-number="FREE" class="bingo-hit">FREE</td>`
                  : `<td data-number="${nParts[row]}">${nParts[row]}</td>`;

              table += `<tr>
                  <td data-number="${bVal}">${bVal}</td>
                  <td data-number="${iVal}">${iVal}</td>
                  ${nCell}
                  <td data-number="${gVal}">${gVal}</td>
                  <td data-number="${oVal}">${oVal}</td>
              </tr>`;
          }

          table += `</tbody></table>`;
          return table;
      }


      function playingStatus(){
        sendRequest("../differentFunctions.php", { Purpose: "Detail" }, function (result) {
            
            var res = JSON.parse(result);
            let status;
            const updaters = {
              betAmount: val => {
                betAmount = parseInt(val);
                betAmountDiv.innerText = betAmount + " ብር";
              },
              noOfTakenCartelas: val => {
                noOfTakenCartelas = val;
                noOfTakenCartelasDiv.innerText = noOfTakenCartelas;
              },
              percent: val => {
                percent = parseFloat((100 - val) / 100).toFixed(2);
                totalWinAmountDiv.innerText = parseInt(noOfTakenCartelas * betAmount * percent) + " ብር";
              },
              playType: val => playTypeDiv.innerText = val,
              playing: val => status = val
            };

            $.each(res, function(key, val) {
              if (updaters[key]) updaters[key](val);
            });
            if(status == 1 && myCartelas != 0){
              document.getElementById("sayBingo_btn").style.display = "block";
              document.getElementById("bingoMessage_h4").innerText = "";
            } else {
              document.getElementById("sayBingo_btn").style.display = "none";
            }
          });
      }

      function showWinnerNumber(number) {
        const span = winnerNumberSpan;
        const hostDiv = document.getElementById("winnerHost_div");

        if (span) {
          const letter = getBingoLetter(number);
          span.textContent = parseInt(number);
          winnerBadgeSpan.textContent = letter;

          // Remove existing animation class (to re-trigger)
          span.classList.remove("pop-in-glow");

          // Trigger reflow to allow re-adding class
          void span.offsetWidth;

          // Add class to start animation
          span.classList.add("pop-in-glow");
          if(autoplayEnabled) autoPlay(number);
        }
      }

      function getBingoLetter(number) {
        if (number >= 1 && number <= 15) return "B";
        if (number >= 16 && number <= 30) return "I";
        if (number >= 31 && number <= 45) return "N";
        if (number >= 46 && number <= 60) return "G";
        if (number >= 61 && number <= 75) return "O";
        return "?"; // fallback for out-of-range numbers
      }

      function addWinnerNumber(number) {
        const container = document.getElementById('lastThreeWinners');

        const circle = document.createElement('div');
        circle.className = 'lastWinnerCircle';
        circle.innerText = parseInt(number);

        container.prepend(circle);

        // Force reflow to apply animation
        circle.offsetWidth;

        // Push-in class triggers transition
        circle.classList.add('push-in');

        // Keep only the last 3
        while (container.children.length > 3) {
          container.removeChild(container.lastChild);
        }
      }

      function showWinnerImage(src = "currentWinner.png") {
        removePausedImage();

        const img = document.createElement("img");
        img.id = "pauseImage";
        img.alt = "Paused image";

        // Force reload with cache-busting query param
        img.src = `${src}?t=${Date.now()}`;

        // Style the image
        img.style.width = "100%";
        img.style.zIndex = "999";

        // Add error handler
        img.onerror = function () {
          removePausedImage(); // remove the broken image
          const fallback = document.createElement("div");
          fallback.id = "pauseImageFallback";
          fallback.innerText = "Result Image will be loaded here...";
          fallback.style.color = "#555";
          fallback.style.fontSize = "1.5em";
          fallback.style.textAlign = "center";
          fallback.style.padding = "2rem";
          fallback.style.width = "100%";
          fallback.style.zIndex = "999";
          fallback.style.backgroundColor = "white";

          checkWinnerDiv.appendChild(fallback);
        };

        // Append image to container
        checkWinnerDiv.appendChild(img);
      }
      function removePausedImage() {
        const img = document.getElementById("pauseImage");
        const fallback = document.getElementById("pauseImageFallback");

        if (img) img.remove();
        if (fallback) fallback.remove();
      }

      //reusable code
      function sendRequest(url, data, callback) {
        $.ajax({
          url,
          type: "post",
          data,
          success: callback,
          error: (err) => console.error("AJAX Error:", err)
        });
      }

      function sayBingo(){
          document.getElementById("bingoMessage_h4").innerText = "You said Bingo, Good Luck";
      }

      function autoPlay(number){
          const numberStr = String(number).padStart(2, '0'); // Ensure format matches data-number

          // Select all cells with this number
          const matchingCells = document.querySelectorAll(`td[data-number="${numberStr}"]`);

          matchingCells.forEach(cell => {
              cell.classList.add('bingo-hit');
          });
      }

      function clearTables(){
        document.querySelectorAll('td[data-number]').forEach(td => {
          if (td.getAttribute('data-number') !== 'FREE') {
            td.classList.remove('bingo-hit');
          }
        });
      }
    </script>
<script>
  document.addEventListener("DOMContentLoaded", () => {
    const host = window.location.hostname;
    const socket = new WebSocket(`ws://${host}:8999`);

    const gameStatusDiv = document.getElementById("gameStatus_div");
    const bingoCard = document.getElementById("bingoCard");
    const okBtn = document.getElementById("sayBingo_btn");
    const statusDiv = document.getElementById("status");

    let lastWinnerNo = 0;
    let running = false;
    let myCard = {}; // number → cell
    let myNumbers = [];

    okBtn.addEventListener("click", () => {
      const phoneNumber = document.getElementById("playerPhone_txt").value; // You can fetch this from session/user
      if (running) {
        socket.send(JSON.stringify({
          type: "pause",
          phone: phoneNumber
        }));
        gameStatusDiv.textContent = "Bingo requested! Waiting for verification...";
        okBtn.style.display = "none";
        document.getElementById("bingoMessage_h4").innerText = "You said Bingo";
      }
    });
 
    socket.onopen = () => {
      gameStatusDiv.innerHTML = "Connected ✅";
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log("Server Message:", data);

      if (data.type === "status") {
        getMyCartelas();
        playingStatus();
        running = data.running;
        if (data.all) {
          data.all.forEach(n => addWinnerNumber(n));
        }
        gameStatusDiv.style.display = "block";
        gameStatusDiv.innerHTML = running ? "Game running..." : "Game stopped.";
        if(running){
          checkWinnerDiv.style.display = "none";
          mainDiv.style.display = "block";
        }
        if(data.paused){
          gameStatusDiv.style.display = "block";
          gameStatusDiv.textContent = "Game paused for checking cards ⏸️";

          winnerNumberSpan.textContent = "⏸️";
          mainDiv.style.display = "none";

          checkWinnerDiv.innerHTML = `
            <h1 class="card-title" style="text-align:center; font-family: Arial, sans-serif; margin-left: 3%; margin-bottom: 0.5%;background: black; color: white;">ካርቴላ ቸክ በመደረግ ላይ</h1>`;
          checkWinnerDiv.style.display = "block";
          winnerInterval = setInterval(() => {
            showWinnerImage();
          }, 1000);
        } else {
          checkWinnerDiv.style.display = "none";
          mainDiv.style.display = "block";
        }
      } else if(data.type === "refresh"){
        getMyCartelas(); playingStatus();
        gameStatusDiv.style.display = "block";
        gameStatusDiv.innerHTML = "Betting is started... &#128523;";
        document.getElementById("lastThreeWinners").innerHTML = "";
        winnerNumberSpan.innerHTML = "&#128526;";
        checkWinnerDiv.style.display = "none";
        mainDiv.style.display = "block";
      }

      if (data.type === "number" && running) {
        if (data.value) {
          showWinnerNumber(data.value); if (lastWinnerNo != 0) addWinnerNumber(lastWinnerNo); lastWinnerNo = data.value;
        }
        gameStatusDiv.style.display = "none";
      }

      if (data.type === "welcome") {
        alert(data.value);
      }

      if (data.type === "stopped") {
        running = false;
        gameStatusDiv.textContent = data.message;
      }

      if (data.type === "paused") {
        running = false;
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "Game paused for checking cards ⏸️";

        winnerNumberSpan.textContent = "⏸️";
        mainDiv.style.display = "none";

        checkWinnerDiv.innerHTML = `
          <h1 class="card-title" style="text-align:center; font-family: Arial, sans-serif; margin-left: 3%; margin-bottom: 0.5%;background: black; color: white;">ካርቴላ ቸክ በመደረግ ላይ</h1>`;
        checkWinnerDiv.style.display = "block";
        okBtn.style.display = "none";
        document.getElementById("bingoMessage_h4").innerText = "";
        winnerInterval = setInterval(() => {
          showWinnerImage();
        }, 1000);
      }

      if (data.type === "resumed") {
        clearInterval(winnerInterval);
        running = true;
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "Game resumed ▶️";
        checkWinnerDiv.style.display = "none";
        mainDiv.style.display = "block";
        okBtn.style.display = "block";
        document.getElementById("bingoMessage_h4").innerText = "";
      }

      if (data.type === "start") {
        running = true;
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "Game started!";
        clearTables();
        clearInterval(winnerInterval);
        okBtn.style.display = "block";
        document.getElementById("bingoMessage_h4").innerText = "";
      }
      if (data.type === "restart") {
        running = true;
        clearInterval(winnerInterval);
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "Game Re-started!";
        clearTables();
        playingStatus();
        okBtn.style.display = "block";
        document.getElementById("bingoMessage_h4").innerText = "";
      }
      if(data.type === "goodBingo"){
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "✅ Good Bingo is found ✅";
        document.getElementById("lastThreeWinners").innerHTML = "";
        winnerNumberSpan.innerHTML = "&#128526;";
      }

      if(data.type === "multipleGoodBingo"){
        gameStatusDiv.style.display = "block";
        gameStatusDiv.textContent = "ከ 3 በላይ አሸናፊ ስለተገኘ ጨዋታው አይነቱ ተቀይሮ እንደገና ይጀምራል";
        document.getElementById("lastThreeWinners").innerHTML = "";
        winnerNumberSpan.innerHTML = "&#128526;";
      }
    };

    socket.onerror = () => {
      gameStatusDiv.style.display = "block";
      gameStatusDiv.textContent = "Connection error ❌";
    };

    socket.onclose = () => {
      gameStatusDiv.style.display = "block";
      gameStatusDiv.textContent = "Disconnected from server";
    };
  });
</script>


  </head>
  <body>
    <div class="main-container">
      <div class="row winnerShowRow_div subRows">
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div id="winnerHost_div" class="winnerHostCircle position-relative">
            <!-- Badge inside the top of the circle -->
            <span class="badge badge-inside bg-info text-dark" id="winnerBadge_span">B</span>

            <!-- Winner number centered in the circle -->
            <span class="winnerNumber_span" id="winnerNumber_span">00</span>
          </div>
        </div>
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div id="lastThreeWinners" class="lastWinnersGrid">
            <!-- JS will populate this with winner circles -->
          </div>
        </div>
      </div>
      <div class="row winnerShowRow_div subRows text-center align-items-center py-1">
        <div class="col-4">
          <span class="badge bg-primary mb-2">የተያዙ ካርቴላወች</span>
          <div class="info-box display_texts" id="noOfTakenCartelas_div">00</div>
        </div>
        <div class="col-4">
          <span class="badge bg-warning text-dark mb-2">መጫወቻ </span>
          <div class="info-box display_texts" id="betAmount_div">00 ብር</div>
        </div>
        <div class="col-4">
          <span class="badge bg-success mb-2">ደራሽ</span>
          <div class="info-box display_texts" id="totalWinAmount_div">000</div>
        </div>
      </div>
      <div class="row" style="">
        <div class="col-2">
          <button class="btn btn-sm btn-outline-secondary" style="margin-top:-0.3rem;" onclick="getMyCartelas()">&#x21bb;</button>
        </div>
        <div class="col-8">
          <h1 class="card-title text-center" id="playType_div" style=" font-family: Arial, sans-serif;margin-left:-2%;margin-top:-0.3rem; background: black;color : white;"></h1>
        </div>
        <div class="col-2 d-flex align-items-center justify-content-end" style="margin-top:-0.3rem;">
          <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="menuDropdown" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Menu">
              <i class="bx bx-dots-vertical-rounded"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="menuDropdown">
              <li>
                <a class="dropdown-item d-flex align-items-center" href="#" id="toggleAutoplay">
                  <input type="checkbox" id="autoplayCheckbox" style="margin-right: 8px;" />
                  Autoplay 
                </a>
              </li>
              <li>
                <input type="text" id="playerPhone_txt" value="<?php echo $_SESSION['PlayerPhone']; ?>" readonly >
              </li>
              <li><hr class="dropdown-divider" /></li>
              <li><a class="dropdown-item" href="../phone.php"><i class="bx bx-log-out-circle me-1"></i> Logout</a></li>
            </ul>
          </div>
        </div>
        <div id="gameStatus_div" class="text-center">Connected</div>
      </div>
      <div class="row" id="mainDiv_div">
        <table class="table table-striped table-bordered bingoTables"  id="updateTable_tbl" style="text-align: center;">
          <thead style="background: #ed3939;">
            <th style="color: black; font-size: 15px; font-weight: bold;">B</th>
            <th style="color: black; font-size: 15px; font-weight: bold;">I</th>
            <th style="color: black; font-size: 15px; font-weight: bold;">N</th>
            <th style="color: black; font-size: 15px; font-weight: bold;">G</th>
            <th style="color: black; font-size: 15px; font-weight: bold;">O</th>
          </thead>
          <tbody style="border: 1px solid gray;">
            <tr><td>21</td><td>21</td><td>21</td><td>21</td><td>21</td></tr>
            <tr><td>21</td><td>21</td><td>21</td><td>21</td><td>21</td></tr>
            <tr><td>21</td><td>21</td><td>21</td><td>21</td><td>21</td></tr>
            <tr><td>21</td><td>21</td><td>21</td><td>21</td><td>21</td></tr>
            <tr><td>21</td><td>21</td><td>21</td><td>21</td><td>21</td></tr>
          </tbody>
        </table>
      </div>
      <div class="row" id="checkBingo_div" style="display: none;">
        
      </div>
      <button class="form-control btn-success" id="sayBingo_btn" style="display:none;">Say Bingo</button>
      <h4 class="fw-bold py-3 mb-4" id="bingoMessage_h4"></h4>
    </div>
    <script>
      document.addEventListener("click", function (e) {
          // Check if the clicked element is a TD inside a bingo table
          if (e.target.tagName === "TD" && e.target.closest(".bingoTables")) {
              const cell = e.target;
              // Toggle color
              if (cell.style.backgroundColor === "green") {
                  cell.style.backgroundColor = "";
                  cell.style.color = "black";
              } else {
                  cell.style.backgroundColor = "green";
                  cell.style.color = "white";
              }
          }
      });
    </script>

    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>
  </body>
</html>
