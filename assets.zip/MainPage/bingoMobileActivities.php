<?php
	require_once("../connection.php");
	require_once('../encryption.php');
	session_start();
	$encrypt = new encryption();
	$inputData = json_decode(file_get_contents('php://input'), true);
	if ($inputData !== null && isset($inputData['Purpose'])) {
	    $purpose = $inputData['Purpose'];
	} else if (isset($_POST['Purpose'])) {
	    $purpose = $_POST['Purpose'];
	} else {
	    $purpose = null;
	}
	//$username = $_SESSION['UserName'];
if ($purpose == "Load-My-Bingos") {
    header('Content-Type: application/json');

    $response = [];

    if (isset($_SESSION['PlayerPhone'])) {
        $phoneNo = $_SESSION['PlayerPhone'];
        $q = mysqli_query($conn, "SELECT * FROM bingo WHERE PhoneNo='$phoneNo'") or die(mysqli_error($conn));
        $noOfTables = mysqli_num_rows($q);

        if ($noOfTables > 0) {
            $bingos = [];
            while ($row = mysqli_fetch_assoc($q)) {
                $bingos[] = [
                    'cartelaNo' => $row['No'],
                    'B' => preg_replace("/\s*/m", '', $row['B']),
                    'I' => preg_replace("/\s*/m", '', $row['I']),
                    'N' => preg_replace("/\s*/m", '', $row['N']),
                    'G' => preg_replace("/\s*/m", '', $row['G']),
                    'O' => preg_replace("/\s*/m", '', $row['O']),
                ];
            }
            $response = ['status' => 'success', 'bingos' => $bingos];
        } else {
            $response = ['status' => 'no_cartelas', 'message' => "You didn't pay for any cartela."];
        }
    } else {
        $response = ['status' => 'not_logged_in', 'message' => "You need to log in again."];
    }

    echo json_encode($response);
    exit;
}

	else if ($purpose == "Get-Winners") {
	    $q = mysqli_query($conn, "SELECT * FROM winner") or die(mysqli_error($conn));
	    $res = "";
	    $cpos = "";

	    while ($row = mysqli_fetch_array($q)) {
	        $res = $row["Winners"];
	        $cpos = $row['NoOfWinnersShown'];
	    }

	    $data = array('winnerNos' => $res,'currentPosition' => $cpos);

	    echo json_encode($data);
	}
	else if($purpose == "Save-Image"){
		// Get the raw POST data (JSON)
		$data = json_decode(file_get_contents('php://input'), true);

		if (!isset($data['image'])) {
		    http_response_code(400);
		    echo json_encode(['message' => 'No image data received']);
		    exit;
		}

		$imageData = $data['image'];

		// Remove the "data:image/png;base64," prefix
		$base64String = preg_replace('#^data:image/\w+;base64,#i', '', $imageData);

		// Decode base64 string
		$imageDecoded = base64_decode($base64String);

		if ($imageDecoded === false) {
		    http_response_code(400);
		    echo json_encode(['message' => 'Base64 decode failed']);
		    exit;
		}

		// Save the image to the current directory as "currentWinner.png"
		$filePath = __DIR__ . '/currentWinner.png';

		if (file_put_contents($filePath, $imageDecoded) === false) {
		    http_response_code(500);
		    echo json_encode(['message' => 'Failed to save image']);
		    exit;
		}

		// Success response
		echo json_encode(['message' => 'Image saved successfully!']);

	}
	else if($purpose == "Update-NoOfCartelasShown"){
		$no = $_POST['No'];
		mysqli_query($conn,"update winner set NoOfWinnersShown='$no'") or die(mysqli_error($conn));
	}
	else if ($purpose === "Get-PhoneNos") {
	    $query = mysqli_query($conn, "SELECT * FROM players") or die(mysqli_error($conn));
	    $phone = [];

	    while ($row = mysqli_fetch_array($query)) {
	        $phone[] = $row['PhoneNo']; // ✅ Correct array append in PHP
	    }

	    echo json_encode($phone);
	}
	else if($purpose == "Say-Bingo"){
		$uname = $_SESSION['UserName'];
		$status = $_POST['Status'];
		mysqli_query($conn,"update currentActivity set Playing=2, SayBingo=$status, CallerPhone='$uname'") or die(mysqli_error($conn));
		echo("successfully");
	}

	else if($purpose === "Remove-Selection"){
	   $cartelaNo = $_POST['CartelaNo'] ?? '';
	    $subAmount = floatval($_POST['BetAmount'] ?? 0);
	    $type = intval($_POST['Type'] ?? 0);
	    $username = $_SESSION['UserName'] ?? '';

	    if (empty($username)) {
	        echo json_encode(["error" => "Unauthorized action."]);
	        exit;
	    }

	    if ($type === 1 && !empty($cartelaNo)) {
	        mysqli_query($conn, "UPDATE bingo SET Taken = 0, PhoneNo = '' WHERE No = '" . mysqli_real_escape_string($conn, $cartelaNo) . "'") or die(json_encode(["error" => mysqli_error($conn)]));
	        mysqli_query($conn, "UPDATE currentActivity SET NoOfTakenCartelas = NoOfTakenCartelas - 1") or die(json_encode(["error" => mysqli_error($conn)]));
	        mysqli_query($conn, "UPDATE cashier SET Collected = Collected - $subAmount WHERE Id = '" . mysqli_real_escape_string($conn, $username) . "'") or die(json_encode(["error" => mysqli_error($conn)]));
	    } else if ($type === 0) {
	        $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM bingo WHERE Taken = 1");
	        $countRow = mysqli_fetch_assoc($q);
	        $takenCount = intval($countRow['total']);
	        $totalSubAmount = $takenCount * $subAmount;
	        mysqli_query($conn, "UPDATE bingo SET Taken = 0, PhoneNo = ''") or die(json_encode(["error" => mysqli_error($conn)]));
	        mysqli_query($conn, "UPDATE currentActivity SET NoOfTakenCartelas = 0") or die(json_encode(["error" => mysqli_error($conn)]));
	        mysqli_query($conn, "UPDATE cashier SET Collected = Collected - $totalSubAmount WHERE Id = '" . mysqli_real_escape_string($conn, $username) . "'") or die(json_encode(["error" => mysqli_error($conn)]));
	    }

	    echo json_encode(["success" => true]);
	}
	
	mysqli_close($conn);
?>