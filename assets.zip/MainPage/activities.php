<?php
    include_once("../connection.php");
    include_once("../encryption.php");
    $purpose = $_POST['Purpose'];
    session_start();
    $username = $_SESSION['UserName'];
    $encrypt = new encryption();
    if($purpose == "Cashier-Detail"){
        ?>
        <div class="row">
            <table class="table table-bordered table-striped" style="text-align:center; box-shadow: #008FFB">
            <?php
                $query = mysqli_query($conn, "select *from cashier where Id='$username'") or die(mysqli_error($conn));
                $row = mysqli_fetch_array($query);
                $name = $encrypt->decrypt($row['Name']);
                $collected = $row['Collected'];
                $paid = $row['Paid'];
                $diff = $collected - $paid;
                $query = mysqli_query($conn, "select *from super") or die(mysqli_error($conn));
                $row = mysqli_fetch_array($query);
                $hex = $row['HexCode'];
                $rhex = $row['RHexCode'];
                
                    ?>
                <tr><th>Name</th><td style="text-transform: capitalize;"><?php echo $name; ?></td></tr>
                <tr><th>Collected</th><td><?php echo "Br. ".$collected; ?></td></tr>
                <tr><th>Paid</th><td><?php echo "Br. ".$paid; ?></td></tr>
                <tr><th>Amount In Hand</th><td><?php echo "Br. ".$diff; ?></td></tr>
                <tr><th> Remaining Package </th><th><?php echo $hex." : ".(hexdec($hex)-$diff); ?></th>                   
            </table>
        </div>
        <?php 
    }
    else if($purpose == "Save-Play"){
        $data = $_POST['Plays'];
        $len = count($data);
        $totalAmount = 0;
        for($i=0;$i<$len;$i++){
            $gameType = $data[$i][4];
            $gameId = $data[$i][0];
            $playerId = $data[$i][1];
            $odd = $data[$i][2];
            $betAm = $data[$i][3];
            $cardCode = $encrypt->encrypt($data[$i][5]);
            $playStyle = $data[$i][6];
            $totalAmount += $betAm;
            if($gameType == "Horse")
                mysqli_query($conn, "insert into horse(UniqueCode,GameId,PlayerId,Odd,PlayStyle,BetAmount) values('$cardCode','$gameId','$playerId','$odd','$playStyle','$betAm')") or die(mysqli_error($conn));
            else if($gameType == "Dog")
                mysqli_query($conn, "insert into dog(UniqueCode,GameId,PlayerId,Odd,PlayStyle,BetAmount) values('$cardCode','$gameId','$playerId','$odd','$playStyle','$betAm')") or die(mysqli_error($conn));
        }
        mysqli_query($conn, "update cashier set Collected =(Collected+'$totalAmount') where Id='$username'") or die(mysqli_error($conn));
        $n = time();
        mysqli_query($conn,"update exp set T=$n");
    }
    else if($purpose == "Load-Dog-Data"){
        $cCode = $_POST['CardCode'];
        $cardCode = $encrypt->encrypt($cCode);
        $query = mysqli_query($conn, "select *from dog where UniqueCode='$cardCode'") or die(mysqli_error($conn));
        $res = mysqli_fetch_array($query);
        $gameId = $encrypt->encrypt($res['GameId']);
        $paid = $res['Paid'];
        // get winner numbers from the winners table
        $winnerQuery = mysqli_query($conn, "select *from winners where GameCode='$gameId' and GameType='Dog' ORDER BY Id DESC LIMIT 1") or die(mysqli_error($conn));
        $WinRes = mysqli_fetch_array($winnerQuery);
        $winners = $encrypt->decrypt($WinRes['Winners']);
        if(strlen($winners) > 0 ){
            $winner1 = substr($winners, 0,1); 
            $winner2 = substr($winners, 1,1); 
            $winner3 = substr($winners, 2,1);
            $totalWinAmount = 0;
            ?>
            <table class="table table-bordered tbale-striped" style="text-align: center;">
                <thead style="background: #71dd37; font-style: bold;"><th>Winner Nos : </th><th><?php echo $winner1; ?></th><th><?php echo $winner2; ?></th><th><?php echo $winner3; ?></th></thead>
            <tr><th>No</th><th>Play Id</th><th>Odd</th><th>Bet Amount</th></tr>
            <?php
            $no = 1;
            $query = mysqli_query($conn, "select *from dog where UniqueCode='$cardCode'") or die(mysqli_error($conn));
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_array($query)){
                    $playerId = $row['PlayerId'];
                    $odd = $row['Odd'];
                    $playType = $row['PlayStyle'];
                    $betAmount = $row['BetAmount'];
                    if($playerId == $winner1){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    else if($playerId == $winner2 && $playType === "Place"){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    else if($playerId == $winner3 && $playType === "Place"){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    ?>
                        <tr> <td><?php echo $no; ?></td><td><?php echo $playerId." ( ".$playType." )"; ?></td><td><?php echo $odd; ?></td><td><?php echo $betAmount; ?></td></tr>
                    <?php
                    $no++;
                }
                ?>
                    <tr style="background: aquamarine"><td colspan="3"> Total Win Amount :  </td><td><?php echo $totalWinAmount; ?> </td></tr> 
                <?php
                    if($paid == 0){ ?>
                       <tr><td colspan="4"> <button class="btn btn-outline-success" onclick="winnerP(<?php echo $cCode; ?>,<?php echo $totalWinAmount; ?>,'Dog')" type="button">Pay This Winner</button></td></tr> 
                    <?php }
                    else{
                        ?> <tr><td colspan="4"> <h3>This Card Is Already Paid </h3> </td></tr> 
                    <?php }
                    }
            else{
                ?> <tr><td colspan="4"> <h3>Card Number Not Found . </h3> </td></tr> 
                    <?php
            }
            ?>
            </table>
            <?php
        } else{
            ?> <center><h2>Please add winner numbers for this game code.</h2></center> <?php
        }
    }
    else if($purpose == "Load-Horse-Data"){
        $cCode = $_POST['CardCode'];
        $cardCode = $encrypt->encrypt($cCode);
        $query = mysqli_query($conn, "select *from horse where UniqueCode='$cardCode'") or die(mysqli_error($conn));
        $res = mysqli_fetch_array($query);
        $gameId = $encrypt->encrypt($res['GameId']);
        $paid = $res['Paid'];
        
        // get winner numbers from the winners table
        $winnerQuery = mysqli_query($conn, "select *from winners where GameCode='$gameId' and GameType='Horse' ORDER BY Id DESC LIMIT 1") or die(mysqli_error($conn));
        $WinRes = mysqli_fetch_array($winnerQuery);
        $winners = $encrypt->decrypt($WinRes['Winners']);
        //echo $winners;
        if(strlen($winners) > 0 ){
            $winner1 = substr($winners, 0,2); 
            $winner2 = substr($winners, 2,2); 
            $winner3 = substr($winners, 4,2);
            
            $totalWinAmount = 0;
            ?>
            <table class="table table-bordered tbale-striped" style="text-align: center;">
                <thead style="background: #71dd37; font-style: bold;"><th>Winner Nos : </th><th><?php echo $winner1; ?></th><th><?php echo $winner2; ?></th><th><?php echo $winner3; ?></th></thead>
                <tr><th>No</th><th>Play Id</th><th>Odd</th><th>Bet Amount</th></tr>
            <?php
            $no = 1;
            $query = mysqli_query($conn, "select *from horse where UniqueCode='$cardCode'") or die(mysqli_error($conn));
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_array($query)){
                    $playerId = $row['PlayerId'];
                    $odd = $row['Odd'];
                    $playType = $row['PlayStyle'];
                    $betAmount = $row['BetAmount'];
                    if($playerId == $winner1){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    else if($playerId == $winner2 && $playType === "Place"){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    else if($playerId == $winner3 && $playType === "Place"){
                        $totalWinAmount += $betAmount*$odd;
                    }
                    ?>
                        <tr> <td><?php echo $no; ?></td><td><?php echo $playerId." ( ".$playType." )"; ?></td><td><?php echo $odd; ?></td><td><?php echo $betAmount; ?></td></tr>
                    <?php
                    $no++;
                }
                ?>
                        <tr style="background: aquamarine"><td colspan="3"> Total Win Amount :  </td><td><?php echo $totalWinAmount; ?> </td></tr> 
                <?php
                    if($paid == 0){ ?>
                       <tr><td colspan="4"> <button class="btn btn-outline-success" onclick="winnerP(<?php echo $cCode; ?>,<?php echo $totalWinAmount; ?>,'Horse')" type="button">Pay This Winner</button></td></tr> 
                    <?php }
                    else{
                        ?> <tr><td colspan="4"> <h3>This Card Is Already Paid </h3> </td></tr> 
                    <?php }
            }
            else{
                ?> <tr><td colspan="4"> <h3>Card Number Not Found . </h3> </td></tr> 
                    <?php
            }
            ?>
            </table>
            <?php
        } else{
            ?> <center><h2>Please add winner numbers for this game code.</h2></center> <?php
        }
    }
    else if($purpose == "Add-Winners"){
        $gameCode =$encrypt->encrypt($_POST['GameCode']);
        $winners = $encrypt->encrypt($_POST['Winners']);
        $winnerOdd = $_POST['WinnerOdd'];
        $gameType = $_POST['GameType'];
        $betClosedAt = $_POST['BetClosedAt'];
        
        $n = time();
        mysqli_query($conn,"update exp set T=$n");
         $d = date("Y-m-d H:i:s",$n);
         $m = date("Y-m-d H:i:s",strtotime("+1 Hour"));
        //echo "<script> console.log('$winners'+'$winner1'+'$winner2'+'$winner3'); </script>";
        if(mysqli_query($conn, "insert into winners(GameCode,Winners,WinnerOdd,BetClosedAt,GameType,Date) values('$gameCode','$winners','$winnerOdd','$betClosedAt','$gameType','$m')")){
            echo "Successfully";
            autoPayWholePlays($conn,$_POST['GameCode'],$gameType,$_POST['Winners']);
        }
        else{
            die(mysqli_error($conn));
        }
    }
    else if($purpose == "Winner-P"){
        $cardCode = $encrypt->encrypt($_POST['CardCode']);
        $am = $_POST['Am'];
        $gameType = $_POST['GameType'];
        if($gameType == "Dog"){
            $activity1 = "update dog set Paid=1 where UniqueCode='$cardCode'";
        }
        else if($gameType == "Horse"){
            $activity1 = "update horse set Paid=1 where UniqueCode='$cardCode'";
        }
        if(mysqli_query($conn, $activity1)){
            echo "success";
            mysqli_query($conn, "update cashier set Paid =(Paid+'$am') where Id='$username'") or die(mysqli_error($conn));
        }
        else{
            die(mysqli_error($conn));
        }
    }
    else if($purpose == "Current-Activity"){
        $res = "";$query = mysqli_query($conn,"select *from currentActivity") or die(mysqli_error($conn));
        while($row = mysqli_fetch_array($query)){
            $res = $row['Playing'];
        }
        echo $res;
    }
    else if($purpose == "Change-Password"){
        $cp = $encrypt->encrypt($_POST['CP']);
        $np = $encrypt->encrypt($_POST['NP']);
        if(isset($_SESSION['Admin'])){
            $query = mysqli_query($conn,"select *from admin where SuperCode='$username' and Password='$cp'") or die(mysqli_error($conn));
            if(mysqli_num_rows($query) > 0 ){
                mysqli_query($conn,"update admin set Password='$np' where SuperCode='$username'") or die(mysqli_error($conn));
                echo "Password Chnaged Successfully";
            }
            else{
                echo "Error : Current Password Is Not correct";
            }
        }
        else{
            $query = mysqli_query($conn,"select *from login where UserName='$username' and Password='$password'") or die(mysqli_error($conn));
            if(mysqli_num_rows($query) > 0){
                mysqli_query($conn,"update login set Password='$np' where UserName='$username'") or die(mysqli_error($conn));
                echo "Password Chnaged Successfully";
            }
            else{
                echo "Error : Current Password Is Not correct";
            }
        }
    }
    function setPaid($conn,$gameType,$am,$gameCode){
        $username = $_SESSION['UserName'];
        if($gameType == "Dog"){
            $activity1 = "update dog set Paid=1 where GameId='$gameCode'";
        }
        else if($gameType == "Horse"){
            $activity1 = "update horse set Paid=1 where GameId='$gameCode'";
        }
        if(mysqli_query($conn, $activity1)){
            mysqli_query($conn, "update cashier set Paid =(Paid+'$am') where Id='$username'") or die(mysqli_error($conn));
        }
        else{
            die(mysqli_error($conn));
        }
    }
    function autoPayWholePlays($conn,$gameCode, $gameType,$winners){
        if($gameType == "Horse"){
            $query = mysqli_query($conn, "select *from horse where GameId='$gameCode'") or die(mysqli_error($conn));
        }
        else if($gameType == "Dog"){
            $query = mysqli_query($conn, "select *from dog where GameId='$gameCode'") or die(mysqli_error($conn));
        }
        if($gameType == 'Horse'){
            $winner1 = substr($winners, 0,2);
            $winner2 = substr($winners, 2,2); 
            $winner3 = substr($winners, 4,2);
        }
        else{
            $winner1 = substr($winners, 0,1);
            $winner2 = substr($winners, 1,1); 
            $winner3 = substr($winners, 2,1);
        }
        
        $totalWinAmount = 0;
        $n = time();
        
        $d = date("Y-m-d H:i:s",$n);
        $m = date("Y-m-d H:i:s",strtotime("+1 Hour"));
        //echo "\n ".time()." ==> ".$d;
        //echo "\n ".$n." ==> ".$m;
        //echo "\nTime now : ".$d;
        //echo "\nGAME TYpe + ".$gameType;
        //echo "\nGAME CODDE + ".$gameCode;
        if(mysqli_num_rows($query) > 0){
            //echo " ==> <br>".$winners;
            while($row = mysqli_fetch_array($query)){
                $playerId = $row['PlayerId'];
                $odd = $row['Odd'];
                $playType = $row['PlayStyle'];
                $betAmount = $row['BetAmount'];
                //echo " \nPlay : ".$playerId." ==/== ".$playType;
                if($playerId == $winner1){
                    $totalWinAmount += $betAmount*$odd;
                }
                else if($playerId == $winner2 && $playType === "Place"){
                    $totalWinAmount += $betAmount*$odd;
                }
                else if($playerId == $winner3 && $playType === "Place"){
                    $totalWinAmount += $betAmount*$odd;
                }
            }
        }
        setPaid($conn,$gameType,$totalWinAmount,$gameCode);
    }
?>

