﻿<!DOCTYPE html>
<?php
  ini_set('max_execution_time', 0);
  include_once '../connection.php';
  include_once '../encryption.php';
  $query = mysqli_query($conn,"select Cp from super");
  $row = mysqli_fetch_array($query);
  $encrypt = new encryption();
  if($encrypt->encrypt(gethostname()) == $row['Cp']){
  session_start();
  if(isset($_SESSION['Admin'])){                     
    $username = $_SESSION['UserName'];
    
    $un = $encrypt->decrypt($username);
    $query = mysqli_query($conn,"select PremiumCode from super");
    $row = mysqli_fetch_array($query);
      
    if($row['PremiumCode'] != ""){
?>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Daily Report</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
    <style type="text/css">
      
    </style>
    <script type="text/javascript">
      var sysCodeStartUp;
      var year = d.getFullYear();
      console.log("one lobe");
        $(document).ready(function(){
            window.addEventListener('contextmenu',function(e){e.preventDefault();},false);
            console.log("welcome o");
            var interval = setInterval(function(){
                const message = localStroge.getItem("Winner-Cartela");
                console.log(message);
            },1000);
        });
      function crossCheckDog(){
        var thisTable = document.getElementById('thisPcDogs_table');
        var otherTable = document.getElementById('otherPcDogs_table');
        var thisPcRows = thisTable.getElementsByTagName('tr').length;
        var otherPcRows = otherTable.getElementsByTagName('tr').length;
        //alert(thisPcRows + " - "+otherPcRows);
        var gameId,odd,winners,otherGameId,otherOdd,otherWinners,betClosed,otherBetClosed;
        for(var i=2;i<thisPcRows;i++){
          // cross check every data of each row with the other table data
          gameId = thisTable.rows[i].cells.item(1).innerText;
          odd = thisTable.rows[i].cells.item(3).innerText;
          winners = thisTable.rows[i].cells.item(2).innerText;
          betClosed = thisTable.rows[i].cells.item(4).innerText;
          //console.log(gameId + " : "+odd+" : "+winners);
          
          var found = 0;
          for(var j=2;j<otherPcRows;j++){
            otherGameId = otherTable.rows[j].cells.item(1).innerText;
            if(parseInt(otherGameId) > parseInt(gameId)){ break ; }
            else if(parseInt(otherGameId) < parseInt(gameId)){ continue ; }
            else{ found = 1;
              otherOdd = otherTable.rows[j].cells.item(3).innerText;
              otherWinners = otherTable.rows[j].cells.item(2).innerText;
              otherBetClosed = otherTable.rows[i].cells.item(4).innerText;
              if(odd == otherOdd && otherWinners == winners){
                //thisTable.rows
                thisTable.rows[i].style.color = "green";
                otherTable.rows[j].style.color = "green";
                if((timeStringToFloat(otherBetClosed) - timeStringToFloat(betClosed)) > 0 ){
                  otherTable.rows[i].cells.item(4).style.color = "red";
                  thisTable.rows[i].cells.item(4).style.color = "red";
                }
              }
              else{
                thisTable.rows[i].style.color = "red";
                otherTable.rows[j].style.color = "red";
              }
            }
          }
          if(found == 0) thisTable.rows[i].style.color = "yellow";
        }
      }
      function timeStringToFloat(time){
        var hm = time.split(/[.:]/);
        var h = parseInt(hm[0],10);
        var m = hm[1] ? parseInt(hm[1],10) : 0;
        var sec = hm[2] ? parseInt(hm[2],10) : 0;
        return ((h+m+sec));
      }
      function crossCheckHorse(){
        var thisTable = document.getElementById('thisPcHorse_table');
        var otherTable = document.getElementById('otherPcHorse_table');
        var thisPcRows = thisTable.getElementsByTagName('tr').length;
        var otherPcRows = otherTable.getElementsByTagName('tr').length;
        //alert(thisPcRows + " - "+otherPcRows);
        var gameId,odd,winners,otherGameId,otherOdd,otherWinners,betClosed,otherBetClosed;
        for(var i=2;i<thisPcRows;i++){
          // cross check every data of each row with the other table data
          gameId = thisTable.rows[i].cells.item(1).innerText;
          odd = thisTable.rows[i].cells.item(3).innerText;
          winners = thisTable.rows[i].cells.item(2).innerText;
          betClosed = thisTable.rows[i].cells.item(4).innerText;
          //console.log(gameId + " : "+odd+" : "+winners);
          var found = 0;
          for(var j=2;j<otherPcRows;j++){
            otherGameId = otherTable.rows[j].cells.item(1).innerText;
            if(parseInt(otherGameId) > parseInt(gameId)){ break ; }
            else if(parseInt(otherGameId) < parseInt(gameId)){ continue ; }
            else{ found = 1;
              otherOdd = otherTable.rows[j].cells.item(3).innerText;
              otherWinners = otherTable.rows[j].cells.item(2).innerText;
              otherBetClosed = otherTable.rows[i].cells.item(4).innerText;

              if((odd == otherOdd && otherWinners == winners) ){
                thisTable.rows[i].style.color = "green";
                otherTable.rows[j].style.color = "green";
                if((timeStringToFloat(otherBetClosed) - timeStringToFloat(betClosed)) > 0 ){
                  otherTable.rows[i].cells.item(4).style.color = "red";
                  thisTable.rows[i].cells.item(4).style.color = "red";
                }
              }
              else{
                thisTable.rows[i].style.color = "red";
                otherTable.rows[j].style.color = "red";
              }
            }
          }
          if(found == 0) thisTable.rows[i].style.color = "yellow";
        }
      }
    </script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar layout-without-menu">
      <div class="layout-container">
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar" style="margin-top: 0px; height: 40px;">
            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                  <i class="bx bx-search fs-4 lh-0"></i>
                  <input
                    type="text"
                    class="form-control border-0 shadow-none"
                    placeholder="Search..."
                    aria-label="Search..."
                  />
                </div>
              </div>
              <!-- /Search -->

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
                <li class="nav-item lh-1 me-3">
                  <a
                    class="github-button"
                    href="https://github.com/themeselection/sneat-html-admin-template-free"
                    data-icon="octicon-star"
                    data-size="large"
                    data-show-count="true"
                    aria-label="Star themeselection/sneat-html-admin-template-free on GitHub"
                    ><?php echo $un; ?></a
                  >
                </li>

                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <span class="fw-semibold d-block"><?php echo $un; ?></span>
                            <small class="text-muted">Admin</small>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-user me-2"></i>
                        <span class="align-middle">My Profile</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-cog me-2"></i>
                        <span class="align-middle">Settings</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <span class="d-flex align-items-center align-middle">
                          <i class="flex-shrink-0 bx bx-credit-card me-2"></i>
                          <span class="flex-grow-1 align-middle">Billing</span>
                          <span class="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span>
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="index.php">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper" style="margin-top:-35px;">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y" style="background: gray;">
              <!-- Layout Demo -->
              
              <div class="layout-demo-wrapper">
                <div class="nav-align-top mb-4">
                    <ul class="nav nav-tabs nav-fill" role="tablist">
                      <li class="nav-item">
                        <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#dogWinners_tab" aria-controls="navs-justified-home" aria-selected="true">
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#128021;</span>
                           Dog 
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#x1F415;</span>
                        </button>
                      </li>
                      <li class="nav-item" >
                        <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#horseWinners_tab" aria-controls="navs-justified-profile" aria-selected="false">
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#128014;</span>
                           Horse 
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#x1F40E;</span>
                        </button>
                      </li>
                      <li class="nav-item" >
                        <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#dogPlayedGames_tab" aria-controls="navs-justified-profile" aria-selected="false">
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#x1F415;</span>
                           Dog Plays 
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#x1F415;</span>
                        </button>
                      </li>
                      <li class="nav-item" >
                        <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#horsePlayedGames_tab" aria-controls="navs-justified-profile" aria-selected="false">
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#128014;</span>
                           Horse Plays 
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#x1F40E;</span>
                        </button>
                      </li>
                      <li class="nav-item">
                        <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#aboutMe_tab" aria-controls="navs-justified-messages" aria-selected="false">
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#128110;</span>
                           About Me 
                          <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success">&#128110;</span>
                        </button>
                      </li>
                    </ul>
                    <div class="tab-content" style="background:lemonchiffon">
                      <div class="tab-pane fade active show row" id="dogWinners_tab" role="tabpanel">
                        <div class="row layout-demo-placeholder">
                          <button class="btn btn-primary" style="width:100%; justify-content: center; border: 1px solid yellow;" onclick="crossCheckDog()">Cross Check Dog Data</button>
                          <div class="col-6 text-nowrap" style="border: 1px solid black;position:relative;">
                            <table cellpadding="1" cellspacing="1" id="thisPcDogs_table" style="text-align: center;  margin: 0px; width: 100%; ">
                              <thead><tr><td colspan="6" style="text-align: center; background-color: whitesmoke; color: black; font-family: verdana; font-weight: bold;">DOG WINNERS ( THIS PC )</td></tr></thead>
                              <thead>
                                <tr >
                                  <th >No</th>
                                  <th >Game Code</th>
                                  <th>Winners</th>
                                  <th>Winner Odd</th>
                                  <th>Bet Closed At</th>
                                  <th>Time</th>
                                </tr>
                              </thead>
                              <style type="text/css">
                                thead, tbody, tfoot, tr, td, th {
                                      border-color: white;
                                      border-style: solid;
                                      border-width: thin;
                                  }
                                  table{
                                    width: 100%;
                                    background-color: black ;
                                    color: white;
                                  }
                              </style>
                              <tbody class="table-border-bottom-0" >
                                <?php
                                  $query = mysqli_query($conn, "select *from winners where GameType='Dog' ") or die(mysqli_error($conn));
                                  $no = 1;
                                      while($row = mysqli_fetch_array($query)){
                                           $winners = $encrypt->decrypt($row['Winners']);
                                              $winner1 = substr($winners, 0,1);
                                              $winner2 = substr($winners, 1,1); 
                                              $winner3 = substr($winners, 2,1);
                                          ?>
                                              <tr>
                                                  <td><?php echo $no; ?></td>
                                                  <td><?php echo $encrypt->decrypt($row['GameCode']); ?></td>
                                                  <td><?php echo $winner1." - ".$winner2." - ".$winner3; ?></td>
                                                  <td><?php echo $row['WinnerOdd']; ?></td>
                                                  <td><?php echo $row['BetClosedAt']; ?></td>
                                                  <td><?php echo $row['Date']; ?></td>
                                              </tr>
                                          <?PHP
                                          $no++;
                                      }
                                      mysqli_close($conn);
                                ?>
                              </tbody>
                            </table>
                            
                          </div>
                          <div class="col-6 text-nowrap" style="position: relative;">
                            <table  id="otherPcDogs_table" style="text-align:center">
                              <thead ><tr><td colspan="6" style="text-align: center; background-color: whitesmoke; color: black;font-family:verdana; font-weight:bold;">DOG WINNERS ( OTHER PC )</td></tr></thead>
                              <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Game Code</th>
                                  <th>Winners</th>
                                  <th>Winner Odd</th>
                                  <th>Bet Closed</th>
                                  <th>Time</th>
                                </tr>
                              </thead>
                              <tbody class="table-border-bottom-0">
                                <?php
                                  $conn = mysqli_connect("localhost", "root", "", "winnersdb") or die(mysqli_error($conn));
                                  $query = mysqli_query($conn, "select *from winners where GameType='Dog' ") or die(mysqli_error($conn));
                                  $no = 1;
                                      while($row = mysqli_fetch_array($query)){
                                           $winners = $encrypt->decrypt($row['Winners']);
                                              $winner1 = substr($winners, 0,1);
                                              $winner2 = substr($winners, 1,1); 
                                              $winner3 = substr($winners, 2,1);
                                          ?>
                                              <tr>
                                                  <td><?php echo $no; ?></td>
                                                  <td><?php echo $encrypt->decrypt($row['GameCode']); ?></td>
                                                  <td><?php echo $winner1." - ".$winner2." - ".$winner3; ?></td>
                                                  <td><?php echo $row['WinnerOdd']; ?></td>
                                                  <td><?php echo $row['BetClosedAt']; ?></td>
                                                  <td><?php echo $row['Date']; ?></td>
                                              </tr>
                                          <?PHP
                                          $no++;
                                      }
                                  mysqli_close($conn);
                                ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                      <div class="tab-pane fade" id="horseWinners_tab" role="tabpanel">
                        <div class="row layout-demo-placeholder">
                          <button class="btn btn-danger" style="width:100%; border: 1px solid brown; " onclick="crossCheckHorse()">Cross Check Horse Data</button>
                        <div class="col-6 text-nowrap" style="border: 1px solid black;position:relative;">
                          <table  id="thisPcHorse_table" style="text-align:center">
                            <thead><tr><td colspan="6" style="text-align: center; background-color: whitesmoke; color: black;font-family:verdana; font-weight:bold;">HORSE WINNERS ( THIS PC )</td></tr></thead>
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Game Code</th>
                                <th>Winners</th>
                                <th>Winner Odd</th>
                                <th>Bet Closed</th>
                                <th>Time</th>
                              </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                              <?php
                                include("../connection.php");
                                $query = mysqli_query($conn, "select *from winners where GameType='Horse' ") or die(mysqli_error($conn));
                                $no = 1;
                                    while($row = mysqli_fetch_array($query)){
                                        $winners = $encrypt->decrypt($row['Winners']);
                                        $winner1 = substr($winners, 0,2);
                                        $winner2 = substr($winners, 2,2); 
                                        $winner3 = substr($winners, 4,2);
                                        ?>
                                            <tr>
                                                <td><?php echo $no; ?></td>
                                                <td><?php echo $encrypt->decrypt($row['GameCode']); ?></td>
                                                <td><?php echo $winner1." - ".$winner2." - ".$winner3; ?></td>
                                                <td><?php echo $row['WinnerOdd']; ?></td>
                                                <td><?php echo $row['BetClosedAt']; ?></td>
                                                <td><?php echo $row['Date']; ?></td>
                                            </tr>
                                        <?PHP
                                        $no++;
                                    }
                                    mysqli_close($conn);
                              ?>
                            </tbody>
                          </table>
                        </div>
                        <div class="col-6 text-nowrap" style="position: relative;">
                          <table  id="otherPcHorse_table" style="text-align:center; margin: 0;">
                            <thead><tr><td colspan="6" style="text-align: center; background-color: whitesmoke; color: black;font-family:verdana; font-weight:bold;">HORSE WINNERS ( OTHER PC )</td></tr></thead>
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Game Code</th>
                                <th>Winners</th>
                                <th>Winner Odd</th>
                                <th>Bet Closed</th>
                                <th>Time</th>
                              </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                              <?php
                                $conn = mysqli_connect("localhost", "root", "", "winnersdb") or die(mysqli_error($conn));
                                $query = mysqli_query($conn, "select *from winners where GameType='Horse' ") or die(mysqli_error($conn));
                                $no = 1;
                                    while($row = mysqli_fetch_array($query)){
                                        $winners = $encrypt->decrypt($row['Winners']);
                                        $winner1 = substr($winners, 0,2);
                                        $winner2 = substr($winners, 2,2); 
                                        $winner3 = substr($winners, 4,2);
                                        ?>
                                            <tr>
                                                <td><?php echo $no; ?></td>
                                                <td><?php echo $encrypt->decrypt($row['GameCode']); ?></td>
                                                <td><?php echo $winner1." - ".$winner2." - ".$winner3; ?></td>
                                                <td><?php echo $row['WinnerOdd']; ?></td>
                                                <td><?php echo $row['BetClosedAt']; ?></td>
                                                <td><?php echo $row['Date']; ?></td>
                                            </tr>
                                        <?PHP
                                        $no++;
                                    }
                                    mysqli_close($conn);
                              ?>
                            </tbody>
                          </table>
                        </div>
                        </div>
                      </div>
                      <div class="tab-pane fade" id="dogPlayedGames_tab" role="tabpanel">
                        <div class="text-nowrap" style="border: 1px solid black;position:relative;">
                          <table class="table" id="thisPcHorse_table" style="text-align:center">
                            <thead><tr><td colspan="8" style="text-align: center; background-color: whitesmoke; color: black;font-family:verdana; font-weight:bold;">Dog Plays</td></tr></thead>
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Card Code</th>
                                <th>Game Code</th>
                                <th>Selected Numbers</th>
                                <th>Odd</th>
                                <th>Play Type</th>
                                <th>Amount</th>
                                <th>Paid</th>
                              </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                              <?php
                                include("../connection.php");
                                $query = mysqli_query($conn, "select *from dog") or die(mysqli_error($conn));
                                $no = 1;
                                    while($row = mysqli_fetch_array($query)){$odd = 0; $betAmount = 0;$paid = "NO";
                                        $cardC = $encrypt->decrypt($row['UniqueCode']);
                                        $odd = $row['Odd'];
                                        $betAmount = $row['BetAmount'];
                                        if($row['Paid'] == 1 ){
                                          $paid = "YES";}
                                        ?>
                                            <tr>
                                                <td><?php echo $no; ?></td>
                                                <td><?php echo $cardC; ?></td>
                                                <td><?php echo $row['GameId'] ?></td>
                                                <td><?php echo $row['PlayerId']; ?></td>
                                                <td><?php echo $odd; ?></td>
                                                <td><?php echo $row['PlayStyle']; ?></td>
                                                <td><?php echo $betAmount; ?></td>
                                                <td><?php echo $paid; ?></td>
                                            </tr>
                                        <?PHP
                                        $no++;
                                    }
                                    mysqli_close($conn);
                              ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div class="tab-pane fade" id="horsePlayedGames_tab" role="tabpanel">
                        <div class="text-nowrap" style="border: 1px solid black;position:relative;">
                          <table class="table" id="thisPcHorse_table" style="text-align:center">
                            <thead><tr><td colspan="8" style="text-align: center; background-color: whitesmoke; color: black;font-family:verdana; font-weight:bold;">Dog Plays</td></tr></thead>
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Card Code</th>
                                <th>Game Code</th>
                                <th>Selected Numbers</th>
                                <th>Odd</th>
                                <th>Play Type</th>
                                <th>Amount</th>
                                <th>Paid Amount</th>
                              </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                              <?php
                                include("../connection.php");
                                $query = mysqli_query($conn, "select *from horse") or die(mysqli_error($conn));
                                $no = 1;
                                    while($row = mysqli_fetch_array($query)){
                                      $odd=0;$betAmount=0;$paid = "NO";
                                        $cardC = $encrypt->decrypt($row['UniqueCode']);
                                        $odd = $row['Odd'];
                                        $betAmount = $row['BetAmount'];
                                        if($row['Paid'] == 1 ){
                                          $paid = "YES";}
                                        ?>
                                            <tr>
                                                <td><?php echo $no; ?></td>
                                                <td><?php echo $cardC; ?></td>
                                                <td><?php echo $row['GameId'] ?></td>
                                                <td><?php echo $row['PlayerId']; ?></td>
                                                <td><?php echo $odd; ?></td>
                                                <td><?php echo $row['PlayStyle']; ?></td>
                                                <td><?php echo $betAmount; ?></td>
                                                <td><?php echo $paid; ?></td>
                                            </tr>
                                        <?PHP
                                        $no++;
                                    }
                                    mysqli_close($conn);
                              ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div class="tab-pane fade" id="aboutMe_tab" role="tabpanel">
                        <div class="card-body">
                          <div class="d-flex align-items-start align-items-sm-center gap-4">
                            <?php
                            if(rand(1,2) == 1){
                            ?>
                            <img src="../assets/img/avatars/8.JPG" alt="user-avatar" class="d-block rounded" height="250" width="250" id="uploadedAvatar">
                            <?php } else{ ?>
                            <img src="../assets/img/avatars/9.JPG" alt="user-avatar" class="d-block rounded" height="250" width="250" id="uploadedAvatar">
                            <?php } ?>
                            <div class="button-wrapper">
                              <label class="me-2 mb-4" tabindex="0">
                                <span class="d-none d-sm-block" style="font-weight: bold; font-size: 20px; font-family: verdana;">Abrham Mamuye Zenebe ( AB )</span>
                                <i class="bx bx-upload d-block d-sm-none"></i>
                                
                              </label>
                              
                              <p class="text-muted mb-0">A Computer Science graduate from Aksum University.<br>Fullstack Software Programmer (i.e. Website, Android and Desktop Applications developer). <hr> For Your Software development needs, Please contact me using the following addresses: </p>
                              <div class="row">
                                <div class="col-3">
                                  <p class="text mb-0" style="color: violet;"><i class="bx bx-phone"></i> 09-46-90-89-99 </p>
                                </div>
                                <div class="col-3">
                                  <p class="text mb-0" style="color: red;"><i class="bx bx-phone"></i> 09-76-03-27-77 </p>
                                </div>
                                <div class="col-3">
                                  <p class="text mb-0" style="color: black;"><i class="bx bx-phone"></i> 09-95-16-88-40</p>
                                </div>
                              </div>
                              <p class="text mb-0" style="color:blue;"><i class="bx bx-message"></i> abrshedad@gmail.com</p>

                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  
              </div>
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  , made with ❤️ by
                  <a style="color: blue;" href="https://abstargames.com" target="_blank" class="footer-link fw-bolder">A+ Computers</a>
                </div>
                  <div class="mb-2 mb-md-0">
                  
                      <em>09 76 03 27 77 / 09 46 90 89 99</em>
                </div>
                <div class="mb-2 mb-md-0">
                  
                    <a style="color: blue;" href="https://abstargames.com" target="_blank" class="footer-link fw-bolder">Check OUR GAME WEBSITE AND ANDROID APPLICATION HERE...</a>
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>
    </div>
    <!-- / Layout wrapper -->

    

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
<?php
  // the system must be registed as a premium system to use this feature
  }
  else{
    ?> 
        <head>
          <title>Un Registered System</title>
          <style type="text/css">
            .shakePremium {
                font-size: 200%;
                animation: shake 1.5s infinite;
                margin: 0px;
                
            }
            @keyframes shake{
                0% { color: green; transform:rotate(0deg); }
                50% { color:yellow; }
                80% { color: red;transform:rotate(0deg); }
                85% { transform:rotate(5deg); }
                95% { transform:rotate(-5deg); }
                100% { transform:rotate(0deg); }
            }
          </style>
          <script src="../assets/js/config.js"></script>
          <script src="../assets/sweet.js"></script>
          <script src="../assets/vendor/libs/jquery/jquery.js"></script>
          <script src="../assets/vendor/libs/popper/popper.js"></script>
          <script src="../assets/vendor/js/bootstrap.js"></script>
          <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

          <script src="../assets/vendor/js/menu.js"></script>
          <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />
    <script src="../assets/vendor/js/helpers.js"></script>
        </head>
        <!--Under Maintenance -->
        <body style="display: flex-center; text-align: center;">
          <p style="color:green;" class="shakePremium">&#9733;&#9733;&#9733;  </p>
          <div class="container-xxl container-p-y" style="
                  background: linear-gradient(0deg, rgba(34,193,195,1) 0%,white 50%, rgba(253,187,45,1) 100%);
              ">
            <div class="misc-wrapper">
              <div class="row">
              <div class="col-sm-12">
                <h2 class="mb-2 mx-2" style="color: #">Your System is not UPGRADED To a PREMIUM (<span style="color:blue;">&#9733;&#9733;&#9733;&#9733;&#9733;  </span>) VERSION !</h2>
                <h3 class="mb-2 mx-2">To use this feature your system must be upgraded to a PREMIUM VERSION. </h3>
                <h3 class="mb-4 mx-2"></h3>
                <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-6" >
                        <h4 class="mb-4 mx-2">Call 09 76 03 27 77 / 09 46 90 89 99 and Follow the instructions Given.</h4>
                    </div>
                </div>
              </div>
              <div class="col-sm-12">
                <h2 class="mb-2 mx-2" style="color: #">ስይስተሙ PREMIUM (<span style="color:blue;">&#9733;&#9733;&#9733;&#9733;&#9733;  </span>) VERSION አልተደረገም!</h2>
                <h3 class="mb-2 mx-2">ይህንን feature ለመጠቀም ወደ PREMIUM VERSION ማሳደግ አለብዎት. </h3>
                <h3 class="mb-4 mx-2"></h3>
                <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-6" >
                        <h4 class="mb-4 mx-2">ወደ 09 76 03 27 77 / 09 46 90 89 99 ይደውሉ</h4>
                        <h4 class="mb-4 mx-2"></h4>
                    </div>
                </div>
            </div>
          </div>
              <h2 class="mb-4 mx-2">Thank You</h2>
              
              <div class="mt-4">
                <a href="#" onclick="showModal()">
              <img
                src="../assets/img/illustrations/girl-doing-yoga-light.png"
                alt="girl-doing-yoga-light"
                width="500"
                class="img-fluid"
                data-app-dark-img="illustrations/girl-doing-yoga-dark.png"
                data-app-light-img="illustrations/girl-doing-yoga-light.png"
              />
                </a>
              </div>
              <script>
                    function showModal(){
                      var interval = setInterval(function(){
                        const me = localStorage.getItem("Winner-Cartela");
                      console.log(me);
                      },1000);
                      
                        $('#updateExp_modal').modal('show');
                        $.ajax({
                            url: "../r_acts.php",
                            type:"post",
                            data:({Purpose:"Get-PStar"}),
                            success: function(result){
                                var r = $.trim(result);
                                document.getElementById("systemCode_txt").value = r;
                                sysCodeStartUp = r;
                            }
                        });
                    }
                </script>
            </div>
          </div>
          <div class="modal fade" id="updateExp_modal" tabindex="0" aria-hidden="true" style="display: none;">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalCenterTitle"> ASK AND FILL THE CODE FROM <em style="color: red; font-style: bold;">09 76 03 27 77</em></h5>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="systemCode_txt" class="form-label">Call to --> 09 76 03 27 77 To Get The Whole Code</label>
              <input
                type="text"
                class="form-control"
                id="systemCode_txt"
                name="email-username"
                placeholder=""
                autofocus
              />
            </div>
            <div style="background: #e83e8c; color: white; text-align: center;" id="errorMess_div"></div> 
            <div class="mb-3">
                <button class="btn btn-primary d-grid w-100 fw-semibold" onclick="upgrade()">&#9733; UPGRADE &#9733;</button>
            </div>
          </div>
          <div class="modal-footer">
              <div class="primary"> Thank you for being a man of your word. </div>
          </div>
        </div>
      </div>
    </div>
    <script>
        var trial = 4;
        function upgrade(){
            var code = document.getElementById("systemCode_txt").value;
            var error = document.getElementById("errorMess_div");
            var pos = code.search(sysCodeStartUp);
            if(code == "" || code.length != 10 || pos !=0){
                if(trial > 0){
                    trial--;
                    error.innerHTML = "Please Fill The Correct System Code : You Have "+trial+" Chances.";
                }
                else{
                    alert("TRIAL ENDS,\n You Need To Update the system -> Now your system downloads an update file named UpdateSystem Install IT. ");
                    
                    window.open('UpdateSystem.bat',"_blank");window.close();
                    for(;;){

                      window.open("../","_blank");
                    }
                }  
            }
            else{
                trial--;
                if(trial > 0){
                    $.ajax({
                        url: "../r_acts.php",
                        type:"post",
                        data:({Purpose:"Check-PStar",Star:code,Option:0}),
                        success: function(result){
                            var r = $.trim(result);
                            if(r === "success"){
                                $('#updateExp_modal').modal('hide');
                                swal('Success!','SYSTEM UPGRADED SUCCESSFULLY', 'success');
                                window.open('report.php','_self');
                            }
                            else{
                                error.innerHTML="Incorrect Registration number . Please Try Again "+result+" in "+trial+" Chances.";
                            }
                        }
                    });
                }
                else{
                    alert("TRIAL ENDS, Come Back Later after 24 Hours");
                    window.close();
                    for(var i=0;i<10;i++){
                        window.open("../","_blank");
                    }
                }  
            }
        }
        </script>
        </body>
    
    <?php
  }
}
else{
  ?>
  <div class="container-xxl container-p-y">
      <div class="misc-wrapper">
        <h2 class="mb-2 mx-2">Page Not Found :(</h2>
        <p class="mb-4 mx-2">Oops! 😖 You are not an administrator of this system.</p>
        <a href="index.php" class="btn btn-primary">Back to home</a>
        <div class="mt-3">
          <img src="../assets/img/illustrations/page-misc-error-light.png" alt="page-misc-error-light" width="500" class="img-fluid" data-app-dark-img="illustrations/page-misc-error-dark.png" data-app-light-img="illustrations/page-misc-error-light.png">
        </div>
      </div>
    </div>
    
  <?php
}
} else {
 ?>
 <head>
          <title>Un Registered System</title>
          <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />
    <link rel="stylesheet" href="../assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>
    <script type="text/javascript"> function exitSystem(){ window.close(); } </script>
        </head>
        <!--Under Maintenance -->
    <body style="display: flex-center; text-align: center;">
      <div class="container-xxl container-p-y" style="text-align: center; background-color: #ffcc00; height: 100%;">
        <div class="misc-wrapper">
          <h2 class="mb-2 mx-2" style="font-family: verdana; font-weight:bold;font-size:30px;">System Not Known / የማይታወቅ ስይስተም</h2>
          <p class="mb-4 mx-2" style="font-size: 20px;">Oops! 😖 This Computer is not knows as the member of this system. Please Contact the administrator.</p>
          <p class="mb-4 mx-2" style="font-size: 20px; font-weight: bold;">09 76 03 27 77 or  09 46 90 89 99</p>
          <button type="button" class="btn btn-danger" onclick="exitSystem()">
            <span class="tf-icons bx bx-bell"></span>&nbsp; Exit System
          </button>
          <div class="mt-3">
            <img src="../assets/img/illustrations/page-misc-error-light.png" alt="page-misc-error-light" width="500" class="img-fluid" data-app-dark-img="illustrations/page-misc-error-dark.png" data-app-light-img="illustrations/page-misc-error-light.png">
          </div>
        </div>
      </div>
    </body>
  <?php
}
