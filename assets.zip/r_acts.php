<?php
    
    include_once("encryption.php");
    $purpose = $_POST['Purpose'];
    $encrypt = new encryption();
    session_start();
    if($purpose == "Get-Star"){
        include_once 'connecton.php';
        $rand = rand(1,4904);
        $query = mysqli_query($conn, "select *from test where ID='$rand'") or die(mysqli_error($conn));
        $row = mysqli_fetch_array($query);
        $p = substr($encrypt->decrypt($encrypt->decrypt($row['Data'])),0,8);
        echo $p;
        mysqli_close($conn);
    }
    else if($purpose == "Check-Star"){
        include("connecton.php");
        $code = $_POST['Option'];
        $s = $encrypt->encrypt($encrypt->encrypt($_POST['Star']));
        $query = mysqli_query($conn, "select *from test where Data='$s'") or die(mysqli_error($conn));
        if(mysqli_num_rows($query) > 0){
            
            mysqli_close($conn);
            include("connection.php");
            mysqli_query($conn, "delete from SUPER") or die(mysqli_error($conn));
            $query = mysqli_query($conn, "insert into super(SuperCode) values('$s')") or die(mysqli_error($conn));

            $n = time();
            $h3 = date('Y-m-d H:i:s',$n);
            //echo "<br>".$y." : ".$h3."<br>";

                if($code == 4 ){
                    $y = $n+60*60*24*3;
                }
                else{
                    $code == 0 ? $y = $n+60*60*24*33 : $y = $n+60*60*24*33*$code;
                }
           mysqli_query($conn, "delete from exp") or die(mysqli_error($conn));
           mysqli_query($conn, "insert into exp(T,E,A) values($n,$y,$code)") or die(mysqli_error($conn));
           if($code == 0){
                mysqli_close($conn);
                $conn = mysqli_connect("localhost", "root", "", "test");
                mysqli_query($conn, "delete from test") or die(mysqli_error($conn));
                mysqli_query($conn,"insert into test(Data) values('$s')") or die(mysqli_error($conn));
           }
           mysqli_close($conn);
           echo "success";
        }
        else{
            
            echo "exit";
        }
    }
    else if($purpose == "Add-Admin"){
        $superCode = $encrypt->encrypt($_POST['SuperCode']);
        $pwd = $encrypt->encrypt($_POST['PWD']);
        
        $shopName = $encrypt->encrypt($_POST['ShopName']);
        include("connection.php");
        $query = mysqli_query($conn, "insert into admin(SuperCode,Password,ShopName) values('$superCode','$pwd','$shopName')") or die(mysqli_error($conn));
        mysqli_query($conn,"insert into cashier(Id,Name,Collected,Paid) values('$superCode','$shopName','0','0')" ) or die(mysqli_error($conn));
        echo "success";
        mysqli_close($conn);
    }
    else if($purpose == "Get-PStar"){
        include_once 'connecton.php';
        $rand = rand(1,8000);
        $query = mysqli_query($conn, "select *from uc where ID='$rand'") or die(mysqli_error($conn));
        $row = mysqli_fetch_array($query);
        $p = substr($encrypt->decrypt($encrypt->decrypt($row['uc'])),0,5);
        echo $p;
        mysqli_close($conn);
    }
    else if($purpose == "Check-PStar"){
        include("connecton.php");
        $code = $_POST['Option'];
        $s = $encrypt->encrypt($encrypt->encrypt($_POST['Star']));
        $query = mysqli_query($conn, "select *from uc where uc='$s'") or die(mysqli_error($conn));
        if(mysqli_num_rows($query) > 0){
            mysqli_query($conn, "delete from uc") or die(mysqli_error($conn));
            mysqli_query($conn,"insert into uc(uc) values('$s')") or die(mysqli_error($conn));
            mysqli_close($conn);
            include("connection.php");
            $query = mysqli_query($conn, "update super set PremiumCode='$s'") or die(mysqli_error($conn));
           mysqli_close($conn);
           echo "success";
        }
        else{
            mysqli_close($conn);
            echo "exit";
        }
    }
?>

