<!DOCTYPE html>
<?php
  include_once("connection.php");
  ?>
<html
  lang="en"
  class="light-style"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Bingo</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />


    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
      <style>
    .shuffle-container-wrapper {
      position: relative;
      display: inline-flex;
      align-items: center;
      perspective: 1000px;
    }

    .container {
      position: relative;
      width: 800px;
      height: 250px;
      transform-style: preserve-3d;
      animation: none;
    }

    @keyframes spinX {
      0% { transform: rotateX(0deg); }
      100% { transform: rotateX(360deg); }
    }

    .face {
      position: absolute;
      width: 100%;
      height: 100%;
      display: grid;
      grid-template-columns: repeat(8, 1fr);
      grid-template-rows: repeat(4, 1fr);
      justify-items: stretch;
      align-items: stretch;
      backface-visibility: hidden;
      transform-style: preserve-3d;
      border-radius: 20px;
      padding: 0;
      padding-top: 50px;
      gap: 0;
      background-color: gray;
    }

    .inner-face {
      width: 100%;
      height: 100%;
      display: contents;
    }

    .back .inner-face { transform: rotateY(180deg); }
    .top .inner-face { transform: rotateX(-90deg); }
    .bottom .inner-face { transform: rotateX(90deg); }

    .front  { transform: rotateY(0deg)     translateZ(125px); }
    .back   { transform: rotateY(180deg)   translateZ(125px); }
    .top    { transform: rotateX(90deg)    translateZ(125px); }
    .bottom { transform: rotateX(-90deg)   translateZ(125px); }
    .left   { transform: rotateY(-90deg)   translateZ(125px); }
    .right  { transform: rotateY(90deg)    translateZ(125px); }

    .cord {
      width: 120px;
      height: 120px;
      background: linear-gradient(180deg, #666, #333);
      border-radius: 0 10px 10px 0;
      box-shadow: inset 0 0 5px #999;
    }

    .rotator {
      width: 100px;
      height: 100px;
      border: 3px solid #333;
      border-radius: 50%;
      background-color: #ff6600;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 85px;
      font-weight: bold;
      margin-left: -15px;
      user-select: none;
    }

    .spinGear {
      animation: spinGear 1s linear infinite;
    }

    @keyframes spinGear {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .bingo-btn {
      width: 100%;
      height: 100%;
      border: 1px solid #333;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 35px;
      color: white;
      box-sizing: border-box;
      user-select: none;
      transition: background-color 0.3s, color 0.3s;
    }

    .B { background-color: #ff5733; }
    .I { background-color: #33a2ff; }
    .N { background-color: #33ff57; }
    .G { background-color: #ff33d0; }
    .O { background-color: #ffff33; color: #000; }

    button {
      margin-top: 35px;
      padding: 10px 15px;
      font-size: 16px;
      background-color: #ff6600;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    @media (max-width: 400px) {
      .container {
        width: 250px;
        height: 250px;
      }
      .rotator {
        width: 80px;
        height: 80px;
        font-size: 18px;
      }
    }
  </style>
    <style type="text/css">
    	#loading_i {
            position: relative;
            top: 50%;
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            transform: translateY(-50%);
        }
        body{
            background: linear-gradient(0deg, rgba(34,193,195,1) 0%,red 50%, rgba(253,187,45,1) 100%);;
            padding: 10px;
        }
        .card{
            
        }
        thead{
            background: #c6f1af;
            font-weight: bold;
            color: black;
            font-size: 35px;
        }
        tr{
            color: black;
        }
        td{
            color: black;
            font-size: 100%;
            font-weight: bold;
        }
        .td{
            font-size: 18px;
            color: red;
        }
        th{
            background-color: gold;
            font-size: 20px;
        }
        #numberContainer{
            font-size: 90px;  /* Large font size for numbers */
            font-family: 'Arial', sans-serif;
            font-weight: bold;
            color: #ff6347;  /* Tomato color */
            text-align: center;
            padding: 20px;
            background-color: #f0f8ff;  /* Light blue background */
            width: 150px;
            margin-left: 50px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }
        .numberContainer{
            font-size: 90px;  /* Large font size for numbers */
            font-family: 'Arial', sans-serif;
            font-weight: bold;
            color: #ff6347;  /* Tomato color */
            text-align: center;
            padding: 20px;
            background-color: #f0f8ff;  /* Light blue background */
            width: 150px;
            margin-left: 0px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }
        .greenButton{
            color: green;
        }   
    </style>
    <link rel="stylesheet" href="assets/css/styles.css"/>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const host = window.location.hostname;
            const socket = new WebSocket(`ws://${host}:8999`);
            var timerDiv = document.getElementById('timer_div');
            var gameCode = document.getElementById('gameCode_div');
            var showTable = document.getElementById("winnerShow_tbl");
            const winnerDiv = document.getElementById("winnerTable_div");
            const information = document.getElementById("information_div");
            const shuffler = document.getElementById("shufller_div");
            const informationTitle = document.getElementById("informationDiv_title");
            const informationBody = document.getElementById("takenCartelasInfo_div");
            const onProressDiv = document.getElementById("onProgressCartelasInfo_div");
            const hostId = document.getElementById("winnerHost_div");
            const img = document.getElementById('bingoResult_img');
            const cells = showTable.querySelectorAll('td');
            let storedImage,goodBingoIsFound,cartelaNo;
            var currentActivity, winnerNos;
            var percent, betAmount=1, noOfTakenCartelas;

            const gameStatusDiv = document.getElementById("gameStatus_div");
            const statusDiv = document.getElementById("status");

            let lastWinnerNo = 0;
            let running = false;
            let myCard = {}; // number → cell
            let myNumbers = [];

         
            socket.onopen = () => {
              gameStatusDiv.innerHTML = "Connected ✅";
            };

            socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                console.log("Server Message:", data);

                if (data.type === "status") {
                    running = data.running;
                    if (data.all) {console.log(data.all);
                      data.all.forEach(n => setColorToCalledNumbers(n));         
                    }
                    gameStatusDiv.style.display = "block";
                    gameStatusDiv.innerHTML = running ? "Game running..." : "Game stopped.";
                    if(running){
                        information.style.display = "none";
                        winnerDiv.style.display = "block";
                        showTable.style.display = "block";
                    }
                    if(data.paused){
                        if(paused == 0 ){
                            playAudio('assets/audio/bingo.mp3');
                            img.src = "";
                        }
                        informationTitle.innerHTML = "ካርቴላ ቸክ በመደረግ ላይ ";
                        informationBody.style.display = "none";
                        informationBody.innerHTML = "";
                        displayOngoing = true;
                        window.clearTimeout(displayInterval);
                        information.style.display = "block";
                        winnerDiv.style.display = "none";
                        tableClear = false;
                        stopDice();
                        if(intervalId === null) toggleAnimation(true);
                        paused =1;
                        checkingCartela = true;
                        goodOrBadBingoIsFound();
                    } else {
                        information.style.display = "none";
                        winnerDiv.style.display = "block";
                        showTable.style.display = "block";
                        startUpActivities();
                    }
                } else if(data.type === "refresh"){
                    img.src = "";
                    //if(counter > 10 ) window.open("d.php",'_self');
                    winnerShown = false; paused = 0;
                    displayOngoing = false;
                    bingoCartelas = JSON.parse(localStorage.getItem("bingoSelectedData") || "[]");
                    $('#message_div').html("PLAY TIME");document.getElementById("winerNos_div").innerHTML='';
                    document.getElementById("playTime_div").style.display="block";
                    startUpActivities();
                    information.style.display = "none";
                    if (localStorage.getItem("Shuffle") === "true") {
                        winnerDiv.style.display = "none";
                        shuffler.style.display = "block";
                        if(!shuffleRotating){ startShuffling();}
                    } else {
                        shuffler.style.display = "none";
                        winnerDiv.style.display = "block";
                    }                          
                    checkingCartela = false;
                    window.clearTimeout(interval);interval=0;MyVar=0;
                    //console.log("after -> Interval - "+interval + " : MyVar - "+MyVar);
                    hostId.innerHTML = "&#128065;";
                    document.getElementById("winerNos_div").innerHTML='';
                    hostId.style.display = "block";
                    document.getElementById("lowerWinnerShow_div").style.visibility = "visible";
                    hostId.classList.remove("glowAndGreen");
                    hostId.classList.add("winnerHost_div");
                    if(!tableClear){
                        tableClear = true;
                        cells.forEach(cell => { cell.style.backgroundColor = "white"; cell.style.color = "black";});
                    }
                    if(intervalId) toggleAnimation(false);
                    if (bingoCartelas && bingoCartelas.length !== 0) {
                        showTable.style.display = "none";
                        onProressDiv.style.display = "block";
                        onProressDiv.innerHTML = "";
                        bingoCartelas.sort(function(a, b) {
                            return a - b;  // Sorting numerically in ascending order
                        });
                        let i=0;
                        bingoCartelas.forEach(function(value) {
                            const newButton = document.createElement('button');
                            newButton.textContent = value;  // Set the number as the button's text
                            newButton.classList.add('numberContainer');
                            newButton.classList.add('round-button');
                            if(i%2 == 0)
                                newButton.classList.add("greenButton");
                            newButton.classList.add('btn');
                            newButton.classList.add('btn-success-outline');
                            onProressDiv.append(newButton);
                            i++;
                        });
                    }
                    else{     
                        showTable.style.display = "block";
                        onProressDiv.style.display = "none";
                    }
                }

                if (data.type === "number" && running) {
                    if (data.value) {
                        hostId.style.display = "block";
                        document.getElementById("lowerWinnerShow_div").style.visibility = "hidden";
                        //console.log("Your Counter restarted at : "+counter+" == Your next char : "+currentWinnerNos.substr(counter,2));
                        winnerShowTime(data.value);
                        paused =0;
                    }
                    gameStatusDiv.style.display = "none";
                }

                if (data.type === "welcome") {
                    alert(data.value);
                }

                if (data.type === "stopped") {
                    running = false;
                    gameStatusDiv.textContent = data.message;
                }

                if (data.type === "paused") {
                    running = false;
                    if(paused == 0 ){
                        playAudio('assets/audio/bingo.mp3');
                        img.src = "";
                    }
                    informationTitle.innerHTML = "ካርቴላ ቸክ በመደረግ ላይ ";
                    informationBody.style.display = "none";
                    informationBody.innerHTML = "";
                    displayOngoing = true;
                    window.clearTimeout(displayInterval);
                    information.style.display = "block";
                    winnerDiv.style.display = "none";
                    tableClear = false;
                    stopDice();
                    if(intervalId === null) toggleAnimation(true);
                    paused =1;
                    checkingCartela = true;
                    goodOrBadBingoIsFound();
                }

                if (data.type === "resumed") {
                    running = true;

                    playAudio('assets/audio/bingoRestarted.mp3');
                    displayOngoing = true;
                    information.style.display = "none";
                    checkingCartela = false;
                    winnerDiv.style.display = "block";
                    showTable.style.display = "block";
                    onProressDiv.style.display = "none";
                    shuffler.style.display = "none";
                    if(intervalId) toggleAnimation(false);
                }

                if (data.type === "start") {
                    running = true;
                    displayOngoing = true;
                    information.style.display = "none";
                    checkingCartela = false;
                    winnerDiv.style.display = "block";
                    showTable.style.display = "block";
                    onProressDiv.style.display = "none";
                    shuffler.style.display = "none";
                    if(intervalId) toggleAnimation(false);
                }
                if (data.type === "restart") {
                    running = true;
                    displayOngoing = true;
                    information.style.display = "none";
                    checkingCartela = false;
                    winnerDiv.style.display = "block";
                    showTable.style.display = "block";
                    onProressDiv.style.display = "none";
                    shuffler.style.display = "none";
                    if(intervalId) toggleAnimation(false);
                    startUpActivities();
                }
                if(data.type === "goodBingo"){
                    gameStatusDiv.style.display = "block";
                    gameStatusDiv.textContent = "✅ Good Bingo is found ✅";
                    document.getElementById("lastThreeWinners").innerHTML = "";
                    winnerNumberSpan.innerHTML = "&#128526;";
                }

                if(data.type === "multipleGoodBingo"){
                    gameStatusDiv.style.display = "block";
                    gameStatusDiv.textContent = "ከ 3 በላይ አሸናፊ ስለተገኘ ጨዋታው አይነቱ ተቀይሮ እንደገና ይጀምራል";
                    document.getElementById("lastThreeWinners").innerHTML = "";
                    winnerNumberSpan.innerHTML = "&#128526;";
                }
            };

            socket.onerror = () => {
                gameStatusDiv.style.display = "block";
                gameStatusDiv.textContent = "Connection error ❌";
            };

            socket.onclose = () => {
                gameStatusDiv.style.display = "block";
                gameStatusDiv.textContent = "Disconnected from server";
            };
        });

        function setColorToCalledNumbers(value){
            let x = parseInt(value);
            var showTable = document.getElementById("winnerShow_tbl");

            if (value <= 15) {
                row = 0;
                col = x;
            } else if (value > 15 && value <= 30) {
                row = 1;
                col = x - 15;
            } else if (value > 30 && value <= 45) {
                row = 2;
                col = x - 30;
            } else if (value > 45 && value <= 60) {
                row = 3;
                col = x - 45;
            } else if (value > 60 && value <= 75) {
                row = 4;
                col = x - 60;
            }

            showTable.rows[row].cells.item(col).style.backgroundColor = "green";
            showTable.rows[row].cells.item(col).style.color = "white";
        }
    </script>
    <script type="text/javascript">
        var winnerShown = false;
        let arr = JSON.parse(localStorage.getItem('myArray')) || [];
        localStorage.setItem("noOfWinnerNumbersShown",0);

        window.addEventListener('load',function(){
            //window.addEventListener('contextmenu',function(e){e.preventDefault();},false);
            document.getElementById('advertDisp_div').style.display='block';
            document.getElementById('mainDisplay_div').style.display='none';
            document.getElementById('exDisp_div').style.display='none';
            setTimeout(() => {
                document.getElementById('advertDisp_div').style.display='none';
                checkForEx();
            },4000);
            console.log("working on");
        });
        function checkForEx(){
            $.ajax({
                url: "differentFunctions.php",
                type: "post",
                data:({Purpose:"Check-System"}),
                success: function(result){
                    //console.log("result : "+result);
                    var r = $.trim(result);                   
                    if(r == 'not'){
                        document.getElementById('mainDisplay_div').style.display='none';document.getElementById('exDisp_div').style.display='block';document.getElementById('expirayMessage_div').innerHTML='YOUR SYSTEM IS NOT REGISTERED.';
                    }
                    else if(r=="exp"){
                        document.getElementById('mainDisplay_div').style.display='none';document.getElementById('exDisp_div').style.display='block';document.getElementById('expirayMessage_div').innerHTML='YOUR SYSTEM IS EXPIRED.';
                    }
                    else if(r == "error"){
                        document.getElementById('mainDisplay_div').style.display='none';document.getElementById('exDisp_div').style.display='block';document.getElementById('expirayMessage_div').innerHTML='YOUR SYSTEM DATE IS INCORRECT.';
                    }
                    else{
                        document.getElementById('exDisp_div').style.display='none';
                        document.getElementById('mainDisplay_div').style.display='block';
                    }
                }
            });
        }
        var showtimer = 3.5;
        var MyVar= 0,interval=0,timeoutVar = 0, counter = 0,paused = 0,displayInterval,tableClear = true, checkingCartela = false, displayOngoing = false;
        var currentWinnerNos;
        shuffleRotating = false;
        let mainInterval;
        var bingoCartelas = {};
        let intervalId = null;
        let large = true;
        function startUpActivities(){
            var timerDiv = document.getElementById('timer_div');
            var gameCode = document.getElementById('gameCode_div');
            mainInterval = setInterval(function(){
                $.ajax({
                    url: "differentFunctions.php",
                    type: "post",
                    data:({Purpose:"Detail"}),
                    success: function(result){
                        showtimer = parseFloat(localStorage.getItem("soundSpeed"));
                        var res = JSON.parse(result);
                        $.each(res,function(key,val){
                          switch(key){
                            case "betAmount":
                                betAmount = parseInt(val); break;
                            case "noOfTakenCartelas": 
                                noOfTakenCartelas = val;
                                //console.log("bet amount : "+betAmount);
                                break;
                            case "percent":
                                percent = parseFloat(parseInt(100-val)/100).toFixed(2);
                                timerDiv.innerHTML = "መጫወቻ : "+betAmount+" ብር <br> የተያዙ ካርቴላዎች :   "+noOfTakenCartelas; gameCode.innerHTML = (parseInt(noOfTakenCartelas*betAmount*percent)) +" ብር";
                                getTypeOfPlayMessage();
                                break;
                            
                            default:
                          }
                        });
                    }
                });
            },1000);
        }
        function toggleAnimation(order) {
            if(order && !intervalId){
                intervalId = setInterval(() => {
                    hostId.style.fontSize = large ? "220px" : "280px";
                    large = !large;
                }, 500);
            } else if (!order && intervalId) {
                clearInterval(intervalId);
                intervalId = null;
                hostId.style.fontSize = "220px";
            }
        }
        function goodOrBadBingoIsFound(){
            var checkInterval = setInterval(function(){
                if(checkingCartela == true){
                    const img = document.getElementById('bingoResult_img');
                    if(localStorage.getItem("storedImage") !== "") {
                        storedImage = localStorage.getItem('storedImage') || "";
                        goodBingoIsFound = localStorage.getItem('goodBingoIsFound');
                        cartelaNo = localStorage.getItem('cartelaNo');
                        if (storedImage != "") {
                            img.src = storedImage;
                            img.style.display = 'block';
                            //alert(goodBingoIsFound);
                            if(goodBingoIsFound == "true"){
                                var n = (randomNumber = Math.floor(Math.random() * 3) + 1);
                                n=2;
                                var winAudioPath = 'assets/audio/wins/win'+ n + ".mp3";
                                var winNumberPath = 'assets/audio/calls/'+ cartelaNo+ ".mp3";
                                
                                //var audioUrl = path + n + ".mp3";
                                //console.log(winNumberPath + " : "+winAudioPath);
                                if(n == 2){                                   
                                        callNumber(winAudioPath);
                                        setTimeout(function() {
                                            callNumber(winNumberPath);
                                        }, 2500);
                                    setTimeout(function(){
                                        callNumber(winAudioPath,1);
                                        setTimeout(function() {
                                            callNumber(winNumberPath);
                                        }, 2500);
                                    },3500);
                                }
                                else{
                                    callNumber(winNumberPath);
                                    setTimeout(function() {
                                        callNumber(winAudioPath);
                                    }, 900); 
                                }
                        
                                localStorage.setItem('goodBingoIsFound', false);
                                localStorage.setItem('cartelaNo', "");
                            }
                            else if(goodBingoIsFound == "false" && cartelaNo !=""){
                                localStorage.setItem('cartelaNo', "");
                            }
                        }
                    }
                    else{
                        img.style.display = 'none';
                    }
                }
                else{
                    clearInterval(checkInterval);
                }
            },1000);
        }
        let currentAudio = null;  // Global variable to keep track of the current audio
        let currentAudioTime = 0; // Store the current playback time of the music audio

        function starter(){
            var btn = document.getElementById("autoClickSoundStarter_btn");
            btn.style.display = "none";
        }
        // Function to call the number and pause any existing audio
        async function callNumber(audioUrl) {
                // If there's already an audio playing, pause it
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudioTime = currentAudio.currentTime;  // Save the playback position of the music
                }

                // Open the cache for the number audio
                const cache = await caches.open('audio-cache-v1');
                const cachedResponse = await cache.match(audioUrl);

                let numberAudio;
                if (cachedResponse) {
                    // Playing audio from cache
                    const audioBlob = await cachedResponse.blob();
                    const audioUrlObject = URL.createObjectURL(audioBlob);
                    numberAudio = new Audio(audioUrlObject);
                } else {
                    // Fetching audio from network
                    numberAudio = new Audio(audioUrl);
                }

                // Play the number audio
                numberAudio.play();
        }
        //playing the audio file
        async function playAudio(audioUrl) {
          // Open the cache
          const cache = await caches.open('audio-cache-v1');
          const cachedResponse = await cache.match(audioUrl);

          if (cachedResponse) {
            //console.log('Playing audio from cache:', audioUrl);
            const audioBlob = await cachedResponse.blob();
            const audioUrlObject = URL.createObjectURL(audioBlob);
            const audio = new Audio(audioUrlObject);
            audio.play();
          } else {
            //console.log('Fetching and playing audio from network:', audioUrl);
            const audio = new Audio(audioUrl);
            audio.play();
          }
        }

        function winnerShowTime(number) {
            console.log("called ");
            var parentDiv = document.getElementById("winerNos_div");

            const hostId = document.getElementById("winnerHost_div");
            var showTable = document.getElementById("winnerShow_tbl");
            hostId.innerHTML = "0 0";

            let showtimer = parseFloat(localStorage.getItem("soundSpeed")) || 3.5;
            let x, soundToRead;
            showtimer = parseFloat(localStorage.getItem("soundSpeed")) || showtimer;
            var value = number;
            hostId.innerHTML = value;
            hostId.classList.remove("winnerHost_div");
            hostId.classList.add("glowAndGreen");

            x = parseInt(number);

            if (value <= 15) {
                row = 0;
                col = x;
                soundToRead = "B " + x;
                hostId.style.backgroundColor = "blue";
                hostId.style.color = "white";
            } else if (value > 15 && value <= 30) {
                row = 1;
                col = x - 15;
                soundToRead = "I " + x;
                hostId.style.backgroundColor = "white";
                hostId.style.color = "black";
            } else if (value > 30 && value <= 45) {
                row = 2;
                col = x - 30;
                soundToRead = "N " + x;
                hostId.style.backgroundColor = "red";
                hostId.style.color = "gold";
            } else if (value > 45 && value <= 60) {
                row = 3;
                col = x - 45;
                soundToRead = "G " + x;
                hostId.style.backgroundColor = "black";
                hostId.style.color = "white";
            } else if (value > 60 && value <= 75) {
                row = 4;
                col = x - 60;
                soundToRead = "O " + x;
                hostId.classList.add("glowAndGreen");
            }
            var path = "assets/audio/" + localStorage.getItem("Gender") + "/";
            let audioPath = path + x + ".mp3";
            //console.log("Current Value : " + audioPath);
            playAudio(audioPath);

            showTable.rows[row].cells.item(col).style.backgroundColor = "green";
            showTable.rows[row].cells.item(col).style.color = "white";

            updateArray(x);     
        }

        var row,col;
      
        // store last three winners 
        function updateArray(newValue) {
          if (arr.length >= 3) {
            arr.shift(); // Remove the oldest value
          }
          arr.push(newValue); // Add the new value

          // Save updated array to localStorage
          localStorage.setItem('myArray', JSON.stringify(arr));
        }

        function stopDice(){clearInterval(MyVar);window.clearTimeout(MyVar);window.clearTimeout(timeoutVar);}

        function getTypeOfPlayMessage(){
            var row,col,diag,type = "",lines = 0;
            const div = document.getElementById("playType_div");
            let linesValue = localStorage.getItem("linesSelected");

            let anyNumbers = parseInt(localStorage.getItem("AnyNumbers"));
            //console.log("Items: " + anyNumbers);

            if (anyNumbers !=0 && anyNumbers > 0) {
                div.innerHTML = "የጨዋታ ዓይነት ➡️ ANY " + anyNumbers + " መስመር";
            }
            else if(linesValue != "0"){
                if(linesValue=="4" || linesValue == 4){
                    div.innerHTML = "የጨዋታ ዓይነት  ፡ 4 Corners";
                }
                else {
                    div.innerHTML = "የጨዋታ ዓይነት ➡️ "+localStorage.getItem("linesSelected");
                }              
            }
            else if(localStorage.getItem("noOfAllLines") == 0 ){
                col = localStorage.getItem("noOfCols");
                lines=lines+parseInt(row);
                if(col != 0 )
                    type = col+" ቋሚ ፡ ".concat(type);
                row = localStorage.getItem("noOfRows");
                lines=lines+parseInt(col);
                if(row != 0 )
                    type = type.concat(row+" አግዳሚ ፡ ");
                diag = localStorage.getItem("noOfDiagonals");
                lines=lines+parseInt(diag);
                if(diag != 0 )
                    type = type.concat(diag+" ዲያጎናል");
                //console.log("No of lines : "+parseInt(lines));
                if(lines == 12 )
                    type = "ሙሉ ዝግ / አስራ ሁለት [ 12 ] መስመር"
                div.innerHTML = "የጨዋታ ዓይነት ➡️ "+type;
            }
            else{
                switch(parseInt(localStorage.getItem("noOfAllLines"))){
                    case 1: type = "አንድ [ 1 ]"; break;
                    case 2: type = "ሁለት [ 2 ] ";break;
                    case 3: type = "ሶስት [ 3 ]";break;
                    case 4: type = "አራት [ 4 ]";break;
                    case 5: type = "አምስት [ 5 ]";break;
                    case 6: type = "ስድስት [ 6 ]";break;
                    case 7: type = "ሰባት [ 7 ]";break;
                    case 8: type = "ስምንት [ 8 ]";break;
                    case 9: type = "ዘጠኝ [ 9 ]";break;
                    case 10: type = "አስር [ 10 ]";break;
                    case 11: type = "አስራ አንድ [ 11 ]";break;
                    case 12: type = "ሙሉ ዝግ / አስራ ሁለት [ 12 ] መስመር";break;
                }

                if(type == "ሙሉ ዝግ / አስራ ሁለት [ 12 ] መስመር")
                    div.innerHTML = "የጨዋታ ዓይነት ➡️ "+type;
                else
                    div.innerHTML =  "የጨዋታ ዓይነት ➡️ በማንኛውም   "+type+"   መስመር  "
            }
        } 
    </script>
  </head>
  <body>
    <!-- Content -->
    
    <!-- Basic Layout & Basic with Icons -->
    <div class="row" id="mainDisplay_div" style="display: none;"> 
                <!-- Basic Layout -->
                <div class="row" id="playTime_div" >
                    <div class="row" >
                        <div style="width:98%; margin-left: 3%;text-align: center; background-color: #d70d00; color: gold; font-size: 50px; font-weight: bold; font-family: 'New Century Schoolbook', serif; filter: drop-shadow(8px 8px 4px white); ">BINGO WINNER NUMBERS
                        </div>
                        <div id="winerNos_div"style="margin-top: 0.3%;"></div>
                        <style type="text/css">
                            #winnerShow_tbl td{
                                border-radius: 50%;
                                font-style: italic;
                                font-family: monospace;
                                background-color: white;
                                font-size: 140%;

                                font-weight: bold;
                                border: none;
                                border-bottom: 3px solid black;
                                border-right: 3px solid red;
                                border-left: 3px solid gold;
                                border-bottom-right-radius: 50%;
                            }

                            #winnerShow_tbl th{
                                border-radius: 50%;
                                font-style: italic;
                                font-family: monospace;
                                background-color: white;
                                font-size: 25px;
                                border: none;
                                background-color: black;
                                color: gold;
                            }
                        </style>
                        <div id="winnerTable_div" style="width:100%;"><center>
                             <center><button class="btn btn-info btn-lg" id="autoClickSoundStarter_btn" onclick="starter()" type="button">Start Sound</button>
                                    <div class="row">
                                        <div id="playType_div" class="card timer_div col-md-12s" style=" font-family: Arial, sans-serif;; margin-bottom:0.5%;background: black;color : white;">
                                       የጨዋታ ዓይነት ፡ 
                                        </div>
                                    </div>
                            <table id="winnerShow_tbl" class="table table-bordered" style="row-height:2px;text-align: center; width: 100%; margin-left: 2rem; width: 100%;">
                               
                                    
                                </center>
                                <tr class="td"><th>B</th><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td></tr>
                                <tr class="td"><th>I</th><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td><td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td></tr>
                                <tr class="td"><th>N</th><td>31</td><td>32</td><td>33</td><td>34</td><td>35</td><td>36</td><td>37</td><td>38</td><td>39</td><td>40</td><td>41</td><td>42</td><td>43</td><td>44</td><td>45</td></tr>
                                <tr class="td"><th>G</th><td>46</td><td>47</td><td>48</td><td>49</td><td>50</td><td>51</td><td>52</td><td>53</td><td>54</td><td>55</td><td>56</td><td>57</td><td>58</td><td>59</td><td>60</td></tr>
                                <tr class="td"><th>O</th><td>61</td><td>62</td><td>63</td><td>64</td><td>65</td><td>66</td><td>67</td><td>68</td><td>69</td><td>70</td><td>71</td><td>72</td><td>73</td><td>74</td><td>75</td> </tr>                   
                            </table></center>
                            <center><div id="onProgressCartelasInfo_div" class="card" style="justify-content: center;display: none; width:100%;">Strong record</div></center>

                        </div>
                        <div id="information_div"  style="display: none; align-content: center; justify-content: center;">
                            <center>
                            <div class="card h-20">

                                <div class="card-body" style="justify-content: center; align-items: center;">
                                  <h1 class="card-title" id="informationDiv_title" style=" font-family: Arial, sans-serif; margin-left: 3%e; margin-bottom:0.5%;background: black;color : white;">ካርቴላ ቸክ በመደረግ ላይ</h1>
                                  <p style="margin-top: -40px;"> <span style="font-size: 80px; width: 200px;"> &#128064;</span></p>
                                  <center><div id="takenCartelasInfo_div" style="justify-content: center;">Strong record</div></center>
                                  <img id="bingoResult_img" alt="Bingo Cartela Result" height="auto" width="100%"  style="display:none;" />
                                </div>
                              </div></center>
                        </div>
                        <div id="shufller_div" style="display:none; margin-left: 5%; margin-top: 3%; margin-bottom: 3%;">
                          <div class="shuffle-container-wrapper">
                            <div class="container" id="container">
                              <div class="face front" id="front"><div class="inner-face"></div></div>
                              <div class="face back" id="back"><div class="inner-face"></div></div>
                              <div class="face top" id="top"><div class="inner-face"></div></div>
                              <div class="face bottom" id="bottom"><div class="inner-face"></div></div>
                              <div class="face left" id="left"><div class="inner-face"></div></div>
                              <div class="face right" id="right"><div class="inner-face"></div></div>
                            </div>
                            <div class="cord"></div>
                            <div class="rotator" id="rotator">⚙️</div>
                          </div>

                              <audio id="shuffleSound" src="shuffle.mp3"></audio>

                              <script>
                                const numbers = Array.from({ length: 75 }, (_, i) => i + 1);
                                const shuffleSound = document.getElementById("shuffleSound");
                                const container = document.getElementById("container");
                                const rotator = document.getElementById("rotator");
                                const faces = ["front", "back", "top", "bottom", "left", "right"];
                                let shuffleInterval;
                                let allButtons = [];

                                function getBingoClass(num) {
                                  if (num <= 15) return "B";
                                  if (num <= 30) return "I";
                                  if (num <= 45) return "N";
                                  if (num <= 60) return "G";
                                  return "O";
                                }

                                function generateButtons() {
                                  let shuffled = [...numbers].sort(() => Math.random() - 0.5);
                                  let index = 0;
                                  allButtons = [];
                                  faces.forEach(faceId => {
                                    const face = document.getElementById(faceId).querySelector(".inner-face");
                                    face.innerHTML = "";
                                    for (let i = 0; i < 20 && index < shuffled.length; i++, index++) {
                                      const num = shuffled[index];
                                      const btn = document.createElement("div");
                                      btn.className = "bingo-btn " + getBingoClass(num);
                                      btn.innerText = num;
                                      face.appendChild(btn);
                                      allButtons.push(btn);
                                    }
                                  });
                                }

                                function shuffleNumbers() {
                                  const shuffledNums = [...numbers].sort(() => Math.random() - 0.5).slice(0, allButtons.length);
                                  for (let i = 0; i < allButtons.length; i++) {
                                    const btn = allButtons[i];
                                    const num = shuffledNums[i];
                                    btn.innerText = num;
                                    btn.className = "bingo-btn " + getBingoClass(num);
                                  }
                                }

                                function startShuffling() {
                                  container.style.animation = "spinX 8s linear infinite";
                                  rotator.classList.add("spinGear");
                                  shuffleSound.loop = true;
                                  shuffleSound.play();
                                  shuffleInterval = setInterval(shuffleNumbers, 500);
                                  setTimeout(stopShuffle, 10000);
                                  shuffleRotating = true;
                                }

                                function stopShuffle() {
                                  clearInterval(shuffleInterval);
                                  container.style.animation = "none";
                                  rotator.classList.remove("spinGear");
                                  shuffleSound.pause();
                                  shuffleSound.currentTime = 0;

                                  localStorage.setItem("Shuffle",false);
                                  shuffleRotating = false;
                                }

                                generateButtons();
                              </script>
                        </div>
                    </div>
                </div>
                
                <div class="row" style="justify-content: center;">
                    <div class="col-md-6 winnerHost_div"  id="winnerHost_div">0 0</div>
                    <div class="col-md-4">
                        <div class="message_div" id="message_div">
                            PLAY TIME
                        </div>
                        <div id="timer_div" class="card timer_div" style="background: black;">
                            
                        </div>
                        <div class="gameCode_div timer_div card" id="gameCode_div">
                           
                        </div>
                        <div class="center-div">AB-STAR GAMES</div>
                    </div>
                    
                    
                </div>
                <!-- Basic with Icons -->
                <div class="col-x1" id="lowerWinnerShow_div">
                  <div class="card mb-2">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <div class="display_texts">
                            WINNERS 
                        </div>
                        <div  id="winners_div">

                        </div> 
                    </div>
                  </div>
                </div>
                <div class="col-md">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="mb-0">AB STAR GAME CENTER</h5>
                      <h5>visit => <a href="#">www.abstargames.com</a></h5>
                      <small class=" float-end" style="color: black; font-weight: bold;">A PLACE WHERE YOU CAN ENJOY AND WIN REAL AMOUNTS</small>
                      <div class="col-md-1" id="gameStatus_div"> X </div>
                    </div>
                  </div>
                </div>
              </div>
    <div class="row timer_div" id="exDisp_div" style="display: none;">
        <div class="col-md mb-4 mb-md-0" >
            <div class="center-div" id="expirayMessage_div">YOUR SYSTEM ALREADY EXPIRED</div>
            
        </div>
        <center><div class=" card display_texts" style="width: 50%; border-bottom: 5px solid black;  background: linear-gradient(90deg, rgba(131,58,180,1) 0%, rgba(62,29,253,1) 19%);border-radius: 25px 10px;">CONTACT US ==> 09 - 76 - 03 - 27 - 77</div></center>
    </div>

    <style>
       
        .advert-container {
            width: 80%;
            max-width: 600px;
            padding: 30px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            color: white;
            justify-self: center;
            font-family: Arial, sans-serif;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            border: 2px solid rgba(255, 255, 255, 0.5);
            animation: fadeIn 1.5s ease-in-out;
        }
        .advert-container p {
            font-size: 18px;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.8); }
            to { opacity: 1; transform: scale(1); }
        }
        .loading-bar {
            width: 100%;
            height: 5px;
            background: rgba(255, 255, 255, 0.2);
            margin-top: 15px;
            border-radius: 5px;
            overflow: hidden;
            position: relative;
        }
        .loading-bar::before {
            content: "";
            display: block;
            width: 0;
            height: 100%;
            background: #00ffcc;
            animation: load 3s linear forwards;
        }
        @keyframes load {
            from { width: 0; }
            to { width: 100%; }
        }
    </style>
    <div  id="advertDisp_div" class="advert-container row timer_div" style="display:none;">
        <center><div class="col-md mb-4 mb-md-0" >
            <h1 style="color: white;">ወደ ቢንጎ ጨዋታ እንኳን በደሕና መጡ</h1>
            <hr>
            <h1> በ AB-STAR GAMES ተዘጋጅቶ የቀረበ </h1>
            <p>Loading the best experience for you...</p>
            <div class="loading-bar"></div>
        </div></center>
    </div>
    <!-- / Content -->
    
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <script src="assets/js/audio-worker.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
  </body>
</html>
<div class="modal fade" id="informationModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Check Cartela</h5>
        <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
          onclick="restartGame()" 
        ></button>
      </div>
      <div class="modal-body" id="">
            <div id="topRowCheckCartela_div"></div>
            <div id="checkCartelaModalBody_div"></div>
      </div>
      <h3 style="background-color: red; color: white; font-style: bold; text-align: center; display: none;" id="badBingo_message"> የተሟላ መስመር ስላልሰራ ይህ ካርቴላ ተሰርዟል </h3>
      <hr>
        <button type="button" class="form-control btn btn-success" style="display: none;" id="goodBingo_btn" onclick="goodBingo()" >Good Bingo
        </button>
        
      <div class="modal-footer">
        <button type="button" class="form-control btn btn-danger" style="display: none;" id="exitBingo_btn" data-bs-dismiss="modal" onclick="exitGame()" >Exit Game
        </button>
        <button type="button" class="form-control btn btn-outline-secondary" onclick="restartGame()"  data-bs-dismiss="modal">
          Close
        </button>
        <input type="number" id="totalReward_txt" disabled value="0" />
      </div>
    </div>
  </div>
</div>
