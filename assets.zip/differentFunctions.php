<?php
    include_once 'connection.php';
    include_once 'encryption.php';
    $purpose = $_POST['Purpose'];
    $encrypt = new encryption();
    if($purpose == "Detail"){
        $res = mysqli_fetch_array(mysqli_query($conn, "select *from currentactivity")) or die(mysqli_error($conn));
        $playing = $res['Playing'];
        $noOfCartelas = $res['NoOfTakenCartelas'];
        $betAmount = $res['BetAmount'];
        $percent = $res['Percent'];
        $gameType = $res['PlayType'];
        $data  = array('betAmount'=>$betAmount,'noOfTakenCartelas' => $noOfCartelas,'playing'=>$playing,'percent'=>$percent,'playType'=>$gameType);
        //echo date('s',$now)." : ".date('s',$time)." : ".date('s',$now)."<br>";
        //echo date('H',$time)." : ".date('i',$time)." : ".date('s',$time);
        //echo "<br> Now : ".$now." TIME : ".$time. " Diff : ".($time-$now);
        echo json_encode($data);  
          
    }
    else if($purpose == "WinnerNos"){
       $query = mysqli_fetch_array(mysqli_query($conn, "select * from winner order by No DESC LIMIT 1")) or die(mysqli_error($conn));
       $winners = $encrypt->decrypt($query['Winners']);
       echo $winners;
    }
    else if($purpose == "Check-System"){
        include_once("connection.php");

        try {
            // Fetch data from the 'super' table
            $querySuper = mysqli_query($conn, "SELECT * FROM super") or die(mysqli_error($conn));
            $nos = mysqli_num_rows($querySuper);

            if ($nos > 0) {
                $resSuper = mysqli_fetch_assoc($querySuper);
                $data = $resSuper['SuperCode'];
            } else {
                throw new Exception("No records found in the 'super' table.");
            }
            mysqli_close($conn);
            include_once 'connecton.php';
            // Fetch data from the 'test' table
            $queryTest = mysqli_query($conn, "SELECT * FROM test WHERE Data='$data'") or die(mysqli_error($conn));
            $nos2 = mysqli_num_rows($queryTest);
            mysqli_close($conn);

            if ($nos2 > 0) {
                include 'connection.php';
                // Fetch expiration data
                $queryExp = mysqli_query($conn, "SELECT * FROM exp") or die(mysqli_error($conn));
                $expData = mysqli_fetch_array($queryExp);

                $currentTime = time();
                $t = $expData['T'];
                $e = $expData['E'];
                $a = $expData['A'];

                // Calculate remaining time using DateTime
                $currentDate = new DateTime('@' . $currentTime); // Current time
                $expiryDate = new DateTime('@' . $e);            // Expiry time



                //echo "Current Date: " . $currentDate->format('Y-m-d H:i:s') . "\n";
                //echo "Expiry Date: " . $expiryDate->format('Y-m-d H:i:s') . "\n";
                $interval = $currentDate->diff($expiryDate); // Difference between dates

                $yearsRemaining = $interval->y;
                $monthsRemaining = $interval->m;
                $daysRemaining = $interval->d;
                $hoursRemaining = $interval->h;
                $minutesRemaining = $interval->i;
                $secondsRemaining = $interval->s;

                // Check expiration status
                if ($a != 0) {
                    if ($currentTime <= $t) {
                        echo "error";
                    } else {
                        if ($expiryDate < $currentDate) { // Check if the expiry date is in the past
                            echo "exp";
                        } else {
                            echo "good"; // Valid
                            //echo "<br>Remaining Time: $yearsRemaining years, $monthsRemaining months, $daysRemaining days, $hoursRemaining hours, $minutesRemaining minutes, $secondsRemaining seconds.";
                        }
                    }
                } else {
                    echo "good"; // Valid
                }
            } else {
                echo "not"; // Data mismatch or missing
            }
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        } finally {
            // Close the database connection
            mysqli_close($conn);
        }
    }
    else if($purpose == "Taken-Cartelas"){
        $query = mysqli_query($conn,"select No from bingo where Taken=1") or die(mysqli_error($conn));
        ?><div class="nav nav-tabs" style="margin-left: px; display: grid; 
                grid-template-columns: repeat(auto-fill, 130px);
                grid-gap: 10px;
                width: 100%;
                justify-items: center;
                align-items: center;
                ">
            <?php
                $odd = 1;
                while($row = mysqli_fetch_array($query))
                {   
                    $code = $row['No'];
                    if($odd == 1){
                        $odd = 0;
                    ?> <button id="numberContainer" class="btn rounded-pill btn-outline-success greenButton"><?php echo $code; ?></button><?php
                } else{
                    $odd = 1;
                    ?> <button id="numberContainer" class="btn rounded-pill btn-outline-danger"><?php echo $code; ?></button><?php
                }
                }
            ?>
        </div>
        <?php
    }
    function resetTime($conn){
        $y = $now+60*1;
        mysqli_query($conn, "delete from timer") or die(mysqli_error($conn));
        //mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','4')") or die(mysqli_error($conn));
        mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','0')") or die(mysqli_error($conn));
    }
    function updateTime($conn,$showTime,$gameCode){
        $now = time();
        mysqli_query($conn,"update exp set T=$now") or die(mysqli_error($conn));
        $encrypt = new encryption();
        if($showTime == 0 ){
            $y = $now+60*1;
            
            generateWinner($conn, $gameCode);
            mysqli_query($conn, "delete from timer") or die(mysqli_error($conn));
            //mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','4')") or die(mysqli_error($conn));
            mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','4')") or die(mysqli_error($conn));
        }
        else{
            $y = $now+60*3;
            mysqli_query($conn, "delete from timer") or die(mysqli_error($conn));
            //mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','4')") or die(mysqli_error($conn));
            mysqli_query($conn, "insert into timer(Time,ShowTime) values('$y','0')") or die(mysqli_error($conn));
            label:
            $id = $encrypt->encrypt(generateGameCode());
	           $q = mysqli_query($conn,"select *from gamecode") or die(mysqli_error($conn));
            $res = mysqli_fetch_array($q);
            $code = $res['code'];
            $code < 1000 ? $newC=$code+1000+1:$newC = $code+1;
            mysqli_query($conn, "delete from ongoinggames") or die(mysqli_error($conn));
            if(mysqli_query($conn, "insert into ongoinggames(GameCode) values('$id')")){
                mysqli_query($conn, "delete from gamecode") or die(mysqli_error($conn));
		          mysqli_query($conn, "insert into gamecode(code) values('$newC')")	;																									
            }else{
                goto label;
            }
        }
    }
    function generateWinner($conn,$gameCode){
        //$query = mysqli_query($conn, "select *from plays where GameCode='$gameCode'") or die(mysqli_error($conn));
        //$nos = mysqli_num_rows($query);
        //if($nos > 0){
            $encrypt = new encryption();
            $winner = "";
            $winArray = array();
            for($i=1;$i<=20;$i++){
                $x = rand(1,80);
                $x < 10 ? $val = "0".$x : $val = $x;
                if(in_array($x, $winArray)){
                    $i--;
                }
                else{
                    $winArray[$i] = $val;
                    $winner = $winner.$val;
                }
            }
            $winner = $encrypt->encrypt($winner);
            mysqli_query($conn, "insert into winners(GameCode,Winners) values('$gameCode','$winner')") or die(mysqli_error($conn));
       // }
    }
    function checkWinnerNos($conn,$gameCode,$winnerNos){
        /*$getQuery = mysqli_query($conn, "select PlayNos from winners where GameCode = '$gameCode'") or die(mysqli_error($conn));
        $maxPlays = '';
        if(mysqli_num_rows($getQuery) > 0)
            while($res = mysqli_fetch_array($getQuery)){

            }
        }*/
    }
    function generateGameCode(){
        $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $charLength = strlen($characters);
        $id = '';
        for ($i=0; $i < 6; $i++) { 
            $id .= $characters[rand(0,$charLength-1)];
        }
        return preg_replace("/\s*/m", '', $id);
    }
?>