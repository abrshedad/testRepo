const CACHE_NAME = 'audio-cache-v1';
const audioFiles = [
  '/audio/1.mp3',
  '/audio/2.mp3',
  '/audio/3.mp3',
  '/audio/4.mp3',
  '/audio/5.mp3',
  '/audio/6.mp3',
  '/audio/7.mp3',
  '/audio/8.mp3',
  '/audio/9.mp3',
  '/audio/10.mp3',
  '/audio/11.mp3',
  '/audio/12.mp3',
  '/audio/13.mp3',
  '/audio/14.mp3',
  '/audio/15.mp3',
  '/audio/16.mp3',
  '/audio/17.mp3',
  '/audio/18.mp3',
  '/audio/19.mp3',
  '/audio/20.mp3',
  '/audio/21.mp3',
  '/audio/22.mp3',
  '/audio/23.mp3',
  '/audio/24.mp3',
  '/audio/25.mp3',
  '/audio/26.mp3',
  '/audio/27.mp3',
  '/audio/28.mp3',
  '/audio/29.mp3',
  '/audio/30.mp3',
  '/audio/31.mp3',
  '/audio/32.mp3',
  '/audio/33.mp3',
  '/audio/34.mp3',
  '/audio/35.mp3',
  '/audio/36.mp3',
  '/audio/37.mp3',
  '/audio/38.mp3',
  '/audio/39.mp3',
  '/audio/40.mp3',
  '/audio/41.mp3',
  '/audio/42.mp3',
  '/audio/43.mp3',
  '/audio/44.mp3',
  '/audio/45.mp3',
  '/audio/46.mp3',
  '/audio/47.mp3',
  '/audio/48.mp3',
  '/audio/49.mp3',
  '/audio/50.mp3',
  '/audio/51.mp3',
  '/audio/52.mp3',
  '/audio/53.mp3',
  '/audio/54.mp3',
  '/audio/55.mp3',
  '/audio/56.mp3',
  '/audio/57.mp3',
  '/audio/58.mp3',
  '/audio/59.mp3',
  '/audio/60.mp3',
  '/audio/61.mp3',
  '/audio/62.mp3',
  '/audio/63.mp3',
  '/audio/64.mp3',
  '/audio/65.mp3',
  '/audio/66.mp3',
  '/audio/67.mp3',
  '/audio/68.mp3',
  '/audio/69.mp3',
  '/audio/70.mp3',
  '/audio/71.mp3',
  '/audio/72.mp3',
  '/audio/73.mp3',
  '/audio/74.mp3',
  '/audio/75.mp3'
  // Add more audio files here
];

// Install event: cache all audio files
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Opened cache and caching audio files');
      return cache.addAll(audioFiles); // Cache all audio files
    })
  );
});

// Fetch event: Serve audio files from cache
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      // If the file is in cache, return it; otherwise, fetch from network
      return response || fetch(event.request);
    })
  );
});
