FUCK YOU MEN

<?php
	$sql = file_get_contents("F:\Code\Developers Room\Final Sys\Play With Installer - 6 Dogs - Final\Apps\winners.sql");
	$mysqli = new mysqli("localhost","root","","newwinnersdb");
	$mysqli->multi_query($sql);
	
?>