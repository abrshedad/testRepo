<?php
	class encryption{
		public function __construct() {
		}
		
		public function encrypt($data){
			 $ciphering = "AES-128-CTR";
			 // Use OpenSSl Encryption method
			$iv_length = openssl_cipher_iv_length($ciphering);
			$options = 0;
			  
			// Non-NULL Initialization Vector for encryption
			$encryption_iv = '0976032777964410';
			  
			// Store the encryption key
			$encryption_key = "PlayWithMe";
			 
			// Use openssl_encrypt() function to encrypt the data
			$cryptedText = openssl_encrypt($data, $ciphering,$encryption_key, $options, $encryption_iv);
			return $cryptedText;
		}
                
		public function decrypt($data){
			$ciphering = "AES-128-CTR";
			 // Use OpenSSl Encryption method
			$iv_length = openssl_cipher_iv_length($ciphering);
			$options = 0;
			  
			// Non-NULL Initialization Vector for encryption
			$decryption_iv = '0976032777964410';
			  
			// Store the encryption key
			$decryption_key = "PlayWithMe";
			$decryptedText=openssl_decrypt ($data, $ciphering, $decryption_key, $options, $decryption_iv);

			return $decryptedText;
		}

		
	}
?>