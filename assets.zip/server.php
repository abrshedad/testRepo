<?php
require __DIR__ . '/vendor/autoload.php';
require "connection.php";  // this file must set up a mysqli connection, e.g. $conn = new mysqli(...);

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use React\EventLoop\Factory as LoopFactory;
use React\Socket\Server as ReactServer;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

class GameServer implements MessageComponentInterface {
    protected $clients;
    protected $loop;
    protected $timer;
    protected $running = false;
    protected $paused = false;
    protected $refresh = false;
    protected $sentNumbers = [];
    protected $conn;
    protected $gameSpeed = 3.5;

    public function __construct($loop, $dbConn) {
        $this->clients = new \SplObjectStorage;
        $this->loop = $loop;
        $this->conn = $dbConn;

        echo "GameServer initialized.\n";

        $this->loop->addPeriodicTimer(5, function () {
            if (!$this->running && !$this->paused && $this->refresh) {
                $refreshMessage = json_encode([
                    'type' => 'refresh',
                    'message' => 'Betting is started... &#128523;'
                ]);

                foreach ($this->clients as $client) {
                    $client->send($refreshMessage);
                }

                echo "Refresh message sent to all clients due to inactivity.\n";
            }
        });

    }

    public function startGame() {
        // Cancel existing timer if present
        if ($this->timer) {
            $this->loop->cancelTimer($this->timer);
        }

        $this->timer = $this->loop->addPeriodicTimer($this->gameSpeed, function () {
            if (!$this->running || $this->paused) {
                return;
            }

            // Fetch current data
            $query = mysqli_query($this->conn, "SELECT * FROM winner LIMIT 1");
            if (!$query || mysqli_num_rows($query) === 0) {
                echo "No winner record found.\n".$query;
                return;
            }
            $row = mysqli_fetch_assoc($query);
            $res = $row["Winners"];
            $cpos = (int)$row["NoOfWinnersShown"];

            echo "Current position: $cpos\n";

            if ($cpos >= strlen($res)) {
                
                echo "All numbers shown. Stopping.\n";
                return;
            }

            $numStr = substr($res, $cpos, 2);
            $random = (int)$numStr;

            $this->sentNumbers[] = $random;

            $message = json_encode([
                'type' => 'number',
                'value' => $random,
                'all' => $this->sentNumbers
            ]);

            echo "Sending number: {$random}\n";
            foreach ($this->clients as $client) {
                $client->send($message);
            }

            // Update DB
            $newPos = $cpos + 2;
            $upd = mysqli_query($this->conn, "UPDATE winner SET NoOfWinnersShown = $newPos");
            if (!$upd) {
                echo "DB update failed: " . mysqli_error($this->conn) . "\n";
            }
        });
    }

    public function onOpen(ConnectionInterface $clientConn) {
        $this->clients->attach($clientConn);
        echo "New connection: {$clientConn->resourceId}\n";

        // Send status
        $clientConn->send(json_encode([
            'type' => 'status',
            'running' => $this->running,
            'paused' => $this->paused,
            'all' => $this->sentNumbers
        ]));
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        if (!isset($data['type'])) return;

        switch ($data['type']) {
            case 'pause':
                if ($this->running && !$this->paused) {
                    $this->paused = true;
                    $this->refresh = false;
                    $pauseMsg = json_encode([
                        'type' => 'paused',
                        'message' => 'Game paused for checking cards'
                    ]);
                    foreach ($this->clients as $c) {
                        $c->send($pauseMsg);
                    }
                    echo "Paused by client {$from->resourceId}\n";
                    echo "Client Phone no is : {$data['phone']}\n";
                }
                break;

            case 'resume':
                if ($this->running && $this->paused) {
                    $this->paused = false;
                    $this->refresh = false;
                    $resumeMsg = json_encode([
                        'type' => 'resumed',
                        'message' => 'Game resumed'
                    ]);
                    foreach ($this->clients as $c) {
                        $c->send($resumeMsg);
                    }
                    echo "Resumed by client {$from->resourceId}\n";
                }
                else{
                    $this->paused = false;
                    $this->refresh = false;
                    $this->running = true;
                    $this->startGame();
                    echo "old game restarted";
                }
                break;

            case 'startGame':
                $this->running = true;
                $this->paused = false;
                $this->refresh = false;
                $sentNumbers = [];
                $this->sentNumbers = [];
                $startMessage = json_encode(['type' => 'start']);
                foreach ($this->clients as $c) {
                    $c->send($startMessage);
                }
                $this->startGame();
                break;
            case 'restart':
                $this->running = true;
                $this->paused = false;
                $this->refresh = false;
                $sentNumbers = [];
                $this->sentNumbers = [];
                $startMessage = json_encode(['type' => 'restart']);
                foreach ($this->clients as $c) {
                    $c->send($startMessage);
                }
                $this->startGame();
                break;
            case 'goodBingo':
                $this->running = false;
                $this->paused = false;
                $this->refresh = false;
                $message = json_encode(['type' => 'goodBingo']);
                foreach ($this->clients as $c) {
                    $c->send($message);
                }
                break;
            case 'multipleGoodBingo':
                $this->running = false;
                $this->paused = false;
                $this->refresh = false;
                $message = json_encode(['type' => 'multipleGoodBingo']);
                foreach ($this->clients as $c) {
                    $c->send($message);
                }
                break;
            case 'startBetting':
                $this->running = false;
                $this->paused = false;
                $this->refresh = true;
                break;
            case 'gameSpeed':
                if (isset($data['GameSpeed']) && is_numeric($data['GameSpeed'])) {
                    $this->gameSpeed = (float)$data['GameSpeed'];
                    echo "Game speed updated to: {$this->gameSpeed} seconds\n";

                    // Restart the timer with the new speed if the game is running
                    if ($this->running && !$this->paused) {
                        if ($this->timer) {
                            $this->loop->cancelTimer($this->timer);
                        }
                        $this->startGame();
                    }
                }
                break;

        }
    }

    public function onClose(ConnectionInterface $clientConn) {
        $this->clients->detach($clientConn);
        echo "Connection {$clientConn->resourceId} closed\n";
    }

    public function onError(ConnectionInterface $clientConn, \Exception $e) {
        echo "Error: {$e->getMessage()}\n";
        $clientConn->close();
    }
}

// Boot up server
$loop = LoopFactory::create();
require "connection.php";  // ensures $conn is defined
$gameServer = new GameServer($loop, $conn);

$webSocket = new WsServer($gameServer);
$httpServer = new HttpServer($webSocket);

$socket = new ReactServer('0.0.0.0:8999', $loop);
$server = new IoServer($httpServer, $socket, $loop);

echo "Server started on ws://localhost:8999\n";
$loop->run();
