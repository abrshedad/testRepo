<?php
// Database connection parameters
include("connection.php");
require_once 'encryption.php';  // Use require_once to avoid multiple inclusions

// Instantiate the encryption class
$encrypt = new encryption();

// Query to fetch all rows ordered by date
$sql = "SELECT 
            DATE(DateTime) AS date, 
            DateTime,
            NoofCartelas, 
            BetAmount, 
            Percent
        FROM report
        ORDER BY DATE(DateTime)";

// Execute the query and store the result
$result = $conn->query($sql);

// Initialize variables for storing chart data
$dates = [];
$totalsNoOfCartelas = [];
$totalsBetAmount = [];
$totalsCalculation = [];
$totalsBetAmountNoOfCartelas = [];

if ($result->num_rows > 0) {
    // Initialize variables for totals per date group
    $currentDate = '';
    $totalCartelas = 0;
    $totalBetAmount = 0;
    $totalPercent = 0;
    $totalCalculation = 0;
    $totalBetAmountNoOfCartelas = 0;
    $countPercent = 0;  // For calculating average percent

    // Loop through each row in the result
    while($row = $result->fetch_assoc()) {
        // Decrypt values for the current row
        $noOfCartelas = $encrypt->decrypt($row["NoofCartelas"]);
        $betAmount = $encrypt->decrypt($row["BetAmount"]);
        $percent = $encrypt->decrypt($row["Percent"]);
        
        // Calculate BetAmount * NoOfCartelas
        $betAmountNoOfCartelas = $betAmount * $noOfCartelas;
        
        // Calculate NoOfCartelas * BetAmount * Percent
        $calculation = $noOfCartelas * $betAmount * ($percent / 100);  // Percent needs to be converted to decimal

        // If we encounter a new date, store the totals and reset counters
        if ($currentDate != $row["date"] && $currentDate != '') {
            // Store the totals for the previous date
            $dates[] = $currentDate;
            $totalsNoOfCartelas[] = $totalCartelas;
            $totalsBetAmount[] = $totalBetAmount;
            $totalsCalculation[] = $totalCalculation;
            $totalsBetAmountNoOfCartelas[] = $totalBetAmountNoOfCartelas;

            // Reset totals for the next date group
            $totalCartelas = 0;
            $totalBetAmount = 0;
            $totalPercent = 0;
            $totalCalculation = 0;
            $totalBetAmountNoOfCartelas = 0;
            $countPercent = 0;
        }

        // Update the current date and totals for the current date group
        $currentDate = $row["date"];
        $totalCartelas += $noOfCartelas;
        $totalBetAmount += $betAmount;
        $totalPercent += $percent;
        $totalCalculation += $calculation;
        $totalBetAmountNoOfCartelas += $betAmountNoOfCartelas;
        $countPercent++;  // Increment count for averaging percent
    }

    // Store the final totals for the last date group
    $dates[] = $currentDate;
    $totalsNoOfCartelas[] = $totalCartelas;
    $totalsBetAmount[] = $totalBetAmount;
    $totalsCalculation[] = $totalCalculation;
    $totalsBetAmountNoOfCartelas[] = $totalBetAmountNoOfCartelas;

} else {
    echo "0 results";
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table and Chart Display</title>
    <!-- Include the Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Simple CSS to make the table and chart side by side */
        .container {
            display: flex;
            justify-content: space-between;
            padding: 20px;
        }

        .table-container {
            flex: 1;
            margin-right: 20px;
            overflow-x: auto;
        }

        .chart-container {
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        td {
            vertical-align: middle;
        }
    </style>
</head>
<body>

    <div class="container">
        <!-- Table Container -->
        <div class="table-container">
            <h2>Report Data</h2>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Date</th>
                        <th>No of Cartelas</th>
                        <th>Bet Amount</th>
                        <th>Percent</th>
                        <th>BetAmount * NoOfCartelas</th>
                        <th>NoOfCartelas * BetAmount * Percent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Reconnect to the database to fetch the result again for table display
                    $conn = new mysqli('localhost', 'root', '', 'bingoresults');
                    $result = $conn->query($sql);

                    $i = 1; // Row index
                    // Loop through the result to output table data
                    while($row = $result->fetch_assoc()) {
                        // Decrypt values for the current row
                        $noOfCartelas = $encrypt->decrypt($row["NoofCartelas"]);
                        $betAmount = $encrypt->decrypt($row["BetAmount"]);
                        $percent = $encrypt->decrypt($row["Percent"]);

                        // Calculate BetAmount * NoOfCartelas
                        $betAmountNoOfCartelas = $betAmount * $noOfCartelas;

                        // Calculate NoOfCartelas * BetAmount * Percent
                        $calculation = $noOfCartelas * $betAmount * ($percent / 100);

                        // Output row data in the table
                        echo "<tr>
                                <td>" . $i . "</td>
                                <td>" . $row["DateTime"] . "</td>
                                <td>" . $noOfCartelas . "</td>
                                <td>" . $betAmount . "</td>
                                <td>" . number_format($percent, 2) . "%</td>
                                <td>" . number_format($betAmountNoOfCartelas, 2) . "</td>
                                <td>" . number_format($calculation, 2) . "</td>
                              </tr>";
                        $i++;
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Chart Container -->
        <div class="chart-container">
            <h2>Report Summary Chart</h2>
            <canvas id="myChart" width="400" height="200"></canvas>
        </div>
    </div>

    <script>
        // Prepare the data from PHP arrays for chart.js
        var dates = <?php echo json_encode($dates); ?>;
        var totalsNoOfCartelas = <?php echo json_encode($totalsNoOfCartelas); ?>;
        var totalsBetAmount = <?php echo json_encode($totalsBetAmount); ?>;
        var totalsCalculation = <?php echo json_encode($totalsCalculation); ?>;

        // Create the bar chart
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: dates,  // Dates as labels
                datasets: [{
                    label: 'Total No of Cartelas',
                    data: totalsNoOfCartelas,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',  // Blue bars
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }, {
                    label: 'Total Bet Amount',
                    data: totalsBetAmount,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',  // Red bars
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }, {
                    label: 'Total NoOfCartelas * BetAmount * Percent',
                    data: totalsCalculation,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',  // Green bars
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>
</html>
